<?php
require_once '../auth.php';
require_once '../../config/db.php';

$officer_id = $_SESSION['user_id'];

// Handle company deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $delete_query = "DELETE FROM companies WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: list.php?msg=deleted");
    exit();
}

// Fetch companies
$query = "SELECT * FROM companies ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies | GLA University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Same sidebar and base styles as students page */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }
        
        /* Copy all sidebar styles from students page */
        .sidebar { /* same as students page */ }
        
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px;
            max-width: calc(100vw - 280px);
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
        }
        .page-title .breadcrumb {
            color: #64748b;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        .page-title .breadcrumb a { color: #2563eb; text-decoration: none; }

        .action-btn {
            background: #2563eb;
            color: white;
            padding: 14px 28px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
        }
        .action-btn:hover { background: #1d4ed8; transform: translateY(-2px); }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }
        .stat-card .label { color: #64748b; font-size: 0.9rem; }
        .stat-card .value { font-size: 1.8rem; font-weight: 700; color: #0f172a; }

        /* Companies Grid */
        .companies-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 24px;
        }

        .company-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .company-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 30px -10px rgba(37, 99, 235, 0.1);
        }

        .company-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #2563eb, #60a5fa);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .company-card:hover::before {
            opacity: 1;
        }

        .company-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .company-logo {
            width: 64px;
            height: 64px;
            background: #eef2ff;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2563eb;
            font-size: 1.8rem;
            font-weight: 600;
        }

        .company-info h3 {
            font-size: 1.2rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }

        .company-info .industry {
            color: #64748b;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .company-details {
            margin-bottom: 20px;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .detail-item i {
            width: 20px;
            color: #2563eb;
        }

        .detail-item .label {
            color: #64748b;
            font-size: 0.9rem;
        }

        .detail-item .value {
            font-weight: 600;
            color: #0f172a;
            margin-left: auto;
        }

        .company-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-active { background: #d1fae5; color: #059669; }
        .status-inactive { background: #fee2e2; color: #ef4444; }

        .action-menu {
            display: flex;
            gap: 8px;
        }
        .action-btn-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            text-decoration: none;
            transition: all 0.2s;
            border: 1px solid #e2e8f0;
        }
        .action-btn-icon:hover {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }

        .alert {
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success { background: #d1fae5; color: #065f46; }
    </style>
</head>
<body>
    <!-- Sidebar (same structure) -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon"><i class="fas fa-briefcase"></i></div>
            <div class="logo-text"><h2>PlacePro</h2><span>GLA University</span></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="../dashboard.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="../students/index.php"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="list.php" class="active"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="../drives/index.php"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="../applications/list.php"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="../placements/list.php"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
        </ul>
        <!-- Sidebar footer same as before -->
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1>Companies</h1>
                <div class="breadcrumb">
                    <a href="../dashboard.php">Dashboard</a> <i class="fas fa-chevron-right" style="margin: 0 8px;"></i> Companies
                </div>
            </div>
            <a href="add.php" class="action-btn">
                <i class="fas fa-plus"></i> Add Company
            </a>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php if($_GET['msg'] == 'added') echo 'Company added successfully!'; ?>
                <?php if($_GET['msg'] == 'updated') echo 'Company updated successfully!'; ?>
                <?php if($_GET['msg'] == 'deleted') echo 'Company deleted successfully!'; ?>
            </div>
        <?php endif; ?>

        <!-- Stats -->
        <?php
        $total = $result->num_rows;
        $active = mysqli_query($conn, "SELECT COUNT(*) as count FROM companies WHERE status = 'active'")->fetch_assoc()['count'];
        $inactive = $total - $active;
        ?>
        <div class="stats-grid">
            <div class="stat-card"><div class="label">Total Companies</div><div class="value"><?= $total ?></div></div>
            <div class="stat-card"><div class="label">Active</div><div class="value"><?= $active ?></div></div>
            <div class="stat-card"><div class="label">Inactive</div><div class="value"><?= $inactive ?></div></div>
            <div class="stat-card"><div class="label">This Month</div><div class="value">5</div></div>
        </div>

        <!-- Companies Grid -->
        <div class="companies-grid">
            <?php if($result->num_rows > 0): ?>
                <?php while($company = $result->fetch_assoc()): ?>
                    <div class="company-card">
                        <div class="company-header">
                            <div class="company-logo">
                                <?= strtoupper(substr($company['company_name'], 0, 2)) ?>
                            </div>
                            <div class="company-info">
                                <h3><?= htmlspecialchars($company['company_name']) ?></h3>
                                <div class="industry">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($company['industry'] ?? 'Technology') ?>
                                </div>
                            </div>
                        </div>

                        <div class="company-details">
                            <div class="detail-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <span class="label">Location</span>
                                <span class="value"><?= htmlspecialchars($company['location'] ?? 'N/A') ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-globe"></i>
                                <span class="label">Website</span>
                                <span class="value"><?= htmlspecialchars($company['website'] ?? 'N/A') ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-envelope"></i>
                                <span class="label">Email</span>
                                <span class="value"><?= htmlspecialchars($company['email'] ?? 'N/A') ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-phone"></i>
                                <span class="label">Phone</span>
                                <span class="value"><?= htmlspecialchars($company['phone'] ?? 'N/A') ?></span>
                            </div>
                        </div>

                        <div class="company-footer">
                            <?php
                            $status = $company['status'] ?? 'active';
                            $statusClass = $status == 'active' ? 'status-active' : 'status-inactive';
                            ?>
                            <span class="status-badge <?= $statusClass ?>"><?= ucfirst($status) ?></span>
                            
                            <div class="action-menu">
                                <a href="view.php?id=<?= $company['id'] ?>" class="action-btn-icon" title="View"><i class="fas fa-eye"></i></a>
                                <a href="edit.php?id=<?= $company['id'] ?>" class="action-btn-icon" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $company['id'] ?>" class="action-btn-icon" title="Delete" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 60px; background: white; border-radius: 24px;">
                    <i class="fas fa-building" style="font-size: 3rem; color: #94a3b8; margin-bottom: 16px;"></i>
                    <h3 style="color: #1e293b;">No companies yet</h3>
                    <p style="color: #64748b; margin: 16px 0;">Add your first company to get started</p>
                    <a href="add.php" style="background: #2563eb; color: white; padding: 12px 24px; border-radius: 14px; text-decoration: none; display: inline-block;">Add Company</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>