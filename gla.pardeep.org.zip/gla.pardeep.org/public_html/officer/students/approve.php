<?php
require_once '../auth.php';
require_once '../../config/db.php';
require_once '../../config/mail.php';

$id=(int)$_GET['id'];

$stmt=$conn->prepare(
"SELECT full_name,email FROM students WHERE id=?"
);
$stmt->bind_param("i",$id);
$stmt->execute();
$user=$stmt->get_result()->fetch_assoc();

$conn->query(
"UPDATE students SET status='approved' WHERE id=$id"
);

/* MAIL */
sendMail(
$user['email'],
$user['full_name'],
"Account Approved",
"Your placement portal account is approved."
);

header("Location: pending.php");