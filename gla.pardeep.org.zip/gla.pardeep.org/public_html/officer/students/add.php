<?php
require_once '../../config/session.php';
require_once '../../config/db.php';

// Check if user is logged in as placement officer
if(!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'placement') {
    header("Location: ../login.php");
    exit;
}

$message = '';
$message_type = '';

// Handle form submission
if($_POST) {
    $errors = [];
    
    // Sanitize and validate inputs
    $enrollment = mysqli_real_escape_string($conn, $_POST['enrollment']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $batch = mysqli_real_escape_string($conn, $_POST['batch']);
    $semester = (int)$_POST['semester'];
    $cgpa = (float)$_POST['cgpa'];
    $backlogs = (int)$_POST['backlogs'];
    $resume = mysqli_real_escape_string($conn, $_POST['resume']);
    
    // Validate required fields
    if(empty($enrollment)) $errors[] = "Enrollment number is required";
    if(empty($name)) $errors[] = "Student name is required";
    if(empty($email)) $errors[] = "Email is required";
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";
    if(empty($phone)) $errors[] = "Phone number is required";
    
    // Check if enrollment already exists
    $check = $conn->prepare("SELECT id FROM students WHERE enrollment_no = ?");
    $check->bind_param("s", $enrollment);
    $check->execute();
    $check->store_result();
    
    if($check->num_rows > 0) {
        $errors[] = "Student with this enrollment number already exists";
    }
    $check->close();
    
    // If no errors, insert student
    if(empty($errors)) {
        $stmt = $conn->prepare("
            INSERT INTO students (
                enrollment_no, name, email, phone, course, 
                batch, semester, cgpa, backlogs, resume_link, 
                created_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $created_by = $_SESSION['user_id'];
        $stmt->bind_param(
            "ssssssiidss", 
            $enrollment, $name, $email, $phone, $course,
            $batch, $semester, $cgpa, $backlogs, $resume,
            $created_by
        );
        
        if($stmt->execute()) {
            $student_id = $stmt->insert_id;
            $message = "Student added successfully! ID: " . $student_id;
            $message_type = "success";
            
            // Clear form data after successful submission
            $_POST = [];
        } else {
            $errors[] = "Database error: " . $conn->error;
        }
        $stmt->close();
    }
    
    if(!empty($errors)) {
        $message = implode("<br>", $errors);
        $message_type = "error";
    }
}

// Fetch courses for dropdown (if you have courses table)
$courses = [];
$course_query = "SELECT id, name FROM courses ORDER BY name";
$course_result = $conn->query($course_query);
if($course_result) {
    while($row = $course_result->fetch_assoc()) {
        $courses[] = $row;
    }
}

// Fetch batches for dropdown
$batches = [];
$batch_query = "SELECT DISTINCT batch FROM students ORDER BY batch DESC";
$batch_result = $conn->query($batch_query);
if($batch_result) {
    while($row = $batch_result->fetch_assoc()) {
        $batches[] = $row['batch'];
    }
}
// Add current year if no batches
if(empty($batches)) {
    $batches = [date('Y'), date('Y')+1, date('Y')+2];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student · Placement Officer</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #0b1120 0%, #19223c 100%);
            min-height: 100vh;
            color: white;
        }

        /* Navigation Bar */
        .navbar {
            background: rgba(18, 25, 45, 0.8);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-logo i {
            font-size: 1.8rem;
            color: #10b981;
        }

        .nav-logo span {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 600;
            font-size: 1.3rem;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-link {
            color: #b7c7e9;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 30px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
        }

        .nav-link i {
            font-size: 1rem;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            color: #b7c7e9;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: #10b981;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* Header */
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-header h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 2.2rem;
            color: white;
        }

        .page-header .badge {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 40px;
            padding: 8px 20px;
            color: #10b981;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Message */
        .message {
            border-radius: 40px;
            padding: 16px 24px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            backdrop-filter: blur(6px);
        }
        
        .message.success {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.4);
            color: #a7f3d0;
        }
        
        .message.error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #ffb3b3;
        }

        /* Form Card */
        .form-card {
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 48px;
            padding: 44px 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.6);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 24px 30px;
        }

        .form-group {
            margin-bottom: 5px;
        }

        .form-group.full-width {
            grid-column: span 2;
        }

        .form-label {
            display: block;
            color: #cfdfff;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-label i {
            margin-right: 6px;
            color: #10b981;
        }

        .input-wrapper {
            position: relative;
        }

        .form-control {
            width: 100%;
            background: rgba(8, 16, 30, 0.6);
            border: 1.5px solid rgba(255, 255, 255, 0.06);
            border-radius: 24px;
            padding: 14px 20px;
            font-size: 1rem;
            color: white;
            font-family: 'Inter', sans-serif;
            outline: none;
            transition: all 0.25s ease;
        }

        .form-control:focus {
            border-color: #10b981;
            background: rgba(10, 20, 40, 0.7);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15);
        }

        .form-control::placeholder {
            color: #5d6f94;
        }

        select.form-control {
            cursor: pointer;
        }

        select.form-control option {
            background: #1a2538;
            color: white;
        }

        /* Helper text */
        .helper-text {
            font-size: 0.8rem;
            color: #5d6f94;
            margin-top: 6px;
            margin-left: 16px;
        }

        /* Button Group */
        .button-group {
            grid-column: span 2;
            display: flex;
            gap: 20px;
            margin-top: 30px;
        }

        .btn {
            padding: 16px 32px;
            border-radius: 40px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            box-shadow: 0 12px 30px -8px rgba(16, 185, 129, 0.4);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #0da271 0%, #047857 100%);
            transform: translateY(-2px);
            box-shadow: 0 16px 35px -6px #10b98180;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            border: 1.5px solid rgba(255, 255, 255, 0.1);
            color: white;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: #10b981;
            transform: translateY(-2px);
        }

        /* Preview Section */
        .preview-section {
            margin-top: 40px;
            padding: 30px;
            background: rgba(8, 16, 30, 0.4);
            border-radius: 32px;
            border: 1px solid rgba(255, 255, 255, 0.03);
        }

        .preview-title {
            font-size: 1.2rem;
            color: #b7c7e9;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .preview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }

        .preview-item {
            background: rgba(255, 255, 255, 0.02);
            padding: 15px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.03);
        }

        .preview-label {
            font-size: 0.8rem;
            color: #5d6f94;
            margin-bottom: 5px;
        }

        .preview-value {
            font-weight: 600;
            color: white;
            word-break: break-word;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .form-group.full-width {
                grid-column: span 1;
            }
            
            .button-group {
                grid-column: span 1;
                flex-direction: column;
            }
            
            .form-card {
                padding: 30px 20px;
            }
            
            .nav-links {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-briefcase"></i>
                <span>Placement Cell</span>
            </div>
            <div class="nav-links">
                <a href="../dashboard.php" class="nav-link">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
                <a href="index.php" class="nav-link active">
                    <i class="fas fa-users"></i> Students
                </a>
                <a href="../companies/index.php" class="nav-link">
                    <i class="fas fa-building"></i> Companies
                </a>
                <a href="../placements/index.php" class="nav-link">
                    <i class="fas fa-handshake"></i> Placements
                </a>
            </div>
            <div class="user-menu">
                <i class="fas fa-bell"></i>
                <div class="user-avatar">
                    PO
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1>Add New Student</h1>
                <p style="color: #b7c7e9; margin-top: 5px;">
                    <i class="fas fa-university"></i> Register a student for placement drive
                </p>
            </div>
            <div class="badge">
                <i class="fas fa-user-plus"></i> New Registration
            </div>
        </div>

        <!-- Message Display -->
        <?php if($message): ?>
            <div class="message <?= $message_type ?>">
                <i class="fas <?= $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i>
                <?= $message ?>
            </div>
        <?php endif; ?>

        <!-- Add Student Form -->
        <div class="form-card">
            <form method="POST" id="studentForm" onsubmit="updatePreview(event)">
                <div class="form-grid">
                    <!-- Enrollment Number -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-qrcode"></i> Enrollment Number *
                        </label>
                        <div class="input-wrapper">
                            <input type="text" class="form-control" name="enrollment" 
                                   value="<?= htmlspecialchars($_POST['enrollment'] ?? '') ?>"
                                   placeholder="GLA2024CS001" required
                                   onkeyup="updatePreview()">
                        </div>
                        <div class="helper-text">Unique university enrollment ID</div>
                    </div>

                    <!-- Full Name -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-user"></i> Full Name *
                        </label>
                        <div class="input-wrapper">
                            <input type="text" class="form-control" name="name" 
                                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                                   placeholder="John Doe" required
                                   onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-envelope"></i> Email Address *
                        </label>
                        <div class="input-wrapper">
                            <input type="email" class="form-control" name="email" 
                                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                                   placeholder="student@university.edu" required
                                   onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-phone"></i> Phone Number *
                        </label>
                        <div class="input-wrapper">
                            <input type="tel" class="form-control" name="phone" 
                                   value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                                   placeholder="+91 98765 43210" required
                                   onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- Course -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-graduation-cap"></i> Course
                        </label>
                        <div class="input-wrapper">
                            <select class="form-control" name="course" onchange="updatePreview()">
                                <option value="">Select Course</option>
                                <?php if(!empty($courses)): ?>
                                    <?php foreach($courses as $course): ?>
                                        <option value="<?= htmlspecialchars($course['name']) ?>" 
                                            <?= (($_POST['course'] ?? '') == $course['name']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($course['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <option value="B.Tech CSE">B.Tech CSE</option>
                                    <option value="B.Tech IT">B.Tech IT</option>
                                    <option value="MCA">MCA</option>
                                    <option value="MBA">MBA</option>
                                    <option value="BBA">BBA</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Batch -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-calendar-alt"></i> Batch
                        </label>
                        <div class="input-wrapper">
                            <select class="form-control" name="batch" onchange="updatePreview()">
                                <option value="">Select Batch</option>
                                <?php foreach($batches as $batch): ?>
                                    <option value="<?= htmlspecialchars($batch) ?>" 
                                        <?= (($_POST['batch'] ?? '') == $batch) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($batch) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Semester -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-layer-group"></i> Current Semester
                        </label>
                        <div class="input-wrapper">
                            <input type="number" class="form-control" name="semester" 
                                   value="<?= htmlspecialchars($_POST['semester'] ?? '6') ?>"
                                   min="1" max="10" onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- CGPA -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-star"></i> CGPA
                        </label>
                        <div class="input-wrapper">
                            <input type="number" step="0.01" class="form-control" name="cgpa" 
                                   value="<?= htmlspecialchars($_POST['cgpa'] ?? '') ?>"
                                   min="0" max="10" placeholder="8.5" onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- Backlogs -->
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-exclamation-triangle"></i> Active Backlogs
                        </label>
                        <div class="input-wrapper">
                            <input type="number" class="form-control" name="backlogs" 
                                   value="<?= htmlspecialchars($_POST['backlogs'] ?? '0') ?>"
                                   min="0" max="10" onkeyup="updatePreview()">
                        </div>
                    </div>

                    <!-- Resume Link -->
                    <div class="form-group full-width">
                        <label class="form-label">
                            <i class="fas fa-file-pdf"></i> Resume Link (Drive/URL)
                        </label>
                        <div class="input-wrapper">
                            <input type="url" class="form-control" name="resume" 
                                   value="<?= htmlspecialchars($_POST['resume'] ?? '') ?>"
                                   placeholder="https://drive.google.com/..." onkeyup="updatePreview()">
                        </div>
                        <div class="helper-text">Google Drive, Dropbox, or direct PDF link</div>
                    </div>

                    <!-- Buttons -->
                    <div class="button-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Student
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='index.php'">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Live Preview -->
        <div class="preview-section">
            <div class="preview-title">
                <i class="fas fa-eye"></i> Live Preview
            </div>
            <div class="preview-grid" id="livePreview">
                <!-- Preview will be updated via JavaScript -->
            </div>
        </div>
    </div>

    <script>
        // Live preview function
        function updatePreview(event) {
            if(event) event.preventDefault();
            
            const form = document.getElementById('studentForm');
            const formData = new FormData(form);
            const preview = document.getElementById('livePreview');
            
            let html = '';
            
            // Define fields to show in preview
            const fields = [
                {name: 'enrollment', label: 'Enrollment No.', icon: 'fa-qrcode'},
                {name: 'name', label: 'Name', icon: 'fa-user'},
                {name: 'email', label: 'Email', icon: 'fa-envelope'},
                {name: 'phone', label: 'Phone', icon: 'fa-phone'},
                {name: 'course', label: 'Course', icon: 'fa-graduation-cap'},
                {name: 'batch', label: 'Batch', icon: 'fa-calendar'},
                {name: 'semester', label: 'Semester', icon: 'fa-layer-group'},
                {name: 'cgpa', label: 'CGPA', icon: 'fa-star'},
                {name: 'backlogs', label: 'Backlogs', icon: 'fa-exclamation-triangle'}
            ];
            
            fields.forEach(field => {
                let value = formData.get(field.name) || '—';
                if(field.name === 'cgpa' && value) value = parseFloat(value).toFixed(2);
                if(field.name === 'backlogs' && value === '0') value = 'None';
                
                html += `
                    <div class="preview-item">
                        <div class="preview-label">
                            <i class="fas ${field.icon}"></i> ${field.label}
                        </div>
                        <div class="preview-value">${escapeHtml(value)}</div>
                    </div>
                `;
            });
            
            preview.innerHTML = html;
        }

        // Helper to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Initialize preview on page load
        document.addEventListener('DOMContentLoaded', function() {
            updatePreview();
        });
    </script>
</body>
</html>