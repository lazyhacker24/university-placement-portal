<?php
require_once '../auth.php';
require_once '../../config/db.php';

$res=$conn->query(
"SELECT * FROM students WHERE status='pending'"
);
?>

<h2>Pending Students</h2>

<?php while($s=$res->fetch_assoc()): ?>

<p>
<?= $s['full_name'] ?> —
<?= $s['roll_no'] ?>

<a href="approve.php?id=<?= $s['id'] ?>">Approve</a>
<a href="reject.php?id=<?= $s['id'] ?>">Reject</a>
</p>

<?php endwhile; ?>