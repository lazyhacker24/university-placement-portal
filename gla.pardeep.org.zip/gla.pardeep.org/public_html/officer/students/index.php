<?php
require_once '../auth.php';
require_once '../../config/db.php';

$officer_id = $_SESSION['user_id'];

// Handle student deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $delete_query = "DELETE FROM students WHERE id = ? AND created_by = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("ii", $id, $officer_id);
    $stmt->execute();
    header("Location: index.php?msg=deleted");
    exit();
}

// Fetch students
$query = "SELECT * FROM students WHERE created_by = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$students = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management | GLA University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }
        
        /* Sidebar styles (same as dashboard) */
        .sidebar {
            width: 280px;
            background: white;
            border-right: 1px solid rgba(0,0,0,0.05);
            padding: 32px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            box-shadow: 4px 0 20px rgba(0,0,0,0.02);
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            padding-left: 8px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
        }

        .logo-text h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
        }

        .logo-text span {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 500;
        }

        .sidebar-menu {
            list-style: none;
        }

        .menu-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #94a3b8;
            font-weight: 600;
            padding: 20px 16px 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 12px 16px;
            color: #475569;
            text-decoration: none;
            border-radius: 14px;
            transition: all 0.2s ease;
            font-weight: 500;
        }

        .sidebar-menu a i { width: 24px; color: #94a3b8; }
        .sidebar-menu a:hover { background: #f1f5f9; color: #2563eb; }
        .sidebar-menu a:hover i { color: #2563eb; }
        .sidebar-menu a.active { background: #eef2ff; color: #2563eb; font-weight: 600; }
        .sidebar-menu a.active i { color: #2563eb; }

        .sidebar-footer {
            position: absolute;
            bottom: 32px;
            left: 20px;
            right: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            padding: 8px 12px;
            background: #f8fafc;
            border-radius: 16px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .user-details { flex: 1; }
        .user-name { font-weight: 700; color: #0f172a; font-size: 0.95rem; }
        .user-email { font-size: 0.7rem; color: #64748b; }

        .logout-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: #fef2f2;
            border-radius: 14px;
            color: #ef4444;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .logout-btn:hover { background: #ef4444; color: white; }
        .logout-btn:hover i { color: white; }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px;
            max-width: calc(100vw - 280px);
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
        }
        .page-title .breadcrumb {
            color: #64748b;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        .page-title .breadcrumb a { color: #2563eb; text-decoration: none; }

        .action-btn {
            background: #2563eb;
            color: white;
            padding: 14px 28px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
        }
        .action-btn:hover { background: #1d4ed8; transform: translateY(-2px); }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }
        .stat-card .label { color: #64748b; font-size: 0.9rem; }
        .stat-card .value { font-size: 1.8rem; font-weight: 700; color: #0f172a; }

        /* Filters */
        .filters-section {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 24px;
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }
        .search-box {
            flex: 1;
            display: flex;
            align-items: center;
            background: #f8fafc;
            border-radius: 14px;
            padding: 0 16px;
            border: 1px solid #e2e8f0;
        }
        .search-box i { color: #94a3b8; }
        .search-box input {
            border: none;
            background: none;
            padding: 14px;
            width: 100%;
            outline: none;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .filter-select {
            padding: 14px 24px;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: #f8fafc;
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: #1e293b;
            outline: none;
        }

        /* Students Table */
        .table-container {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 16px 12px;
            color: #64748b;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #f1f5f9;
        }

        td {
            padding: 16px 12px;
            border-bottom: 1px solid #f1f5f9;
            color: #1e293b;
        }

        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .student-avatar {
            width: 40px;
            height: 40px;
            background: #eef2ff;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2563eb;
            font-weight: 600;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-active { background: #d1fae5; color: #059669; }
        .status-pending { background: #fef3c7; color: #d97706; }
        .status-placed { background: #dbeafe; color: #2563eb; }

        .action-menu {
            display: flex;
            gap: 8px;
        }
        .action-btn-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            text-decoration: none;
            transition: all 0.2s;
            border: 1px solid #e2e8f0;
        }
        .action-btn-icon:hover {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }
        .delete-btn:hover { background: #ef4444; border-color: #ef4444; }

        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 24px;
        }
        .page-btn {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            background: white;
            color: #64748b;
            cursor: pointer;
            transition: all 0.2s;
        }
        .page-btn.active {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }

        .alert {
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success { background: #d1fae5; color: #065f46; }
        .alert-error { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <!-- Sidebar (same structure) -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon"><i class="fas fa-briefcase"></i></div>
            <div class="logo-text"><h2>PlacePro</h2><span>GLA University</span></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="../dashboard.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="index.php" class="active"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="../companies/list.php"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="../drives/index.php"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="../applications/list.php"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="../placements/list.php"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
            <li class="menu-label"><span>ANALYTICS</span></li>
            <li><a href="../reports/index.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
        </ul>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?= strtoupper(substr($_SESSION['name'] ?? 'PO', 0, 2)) ?></div>
                <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($_SESSION['name'] ?? 'Officer') ?></div>
                    <div class="user-email"><?= htmlspecialchars($_SESSION['email'] ?? '') ?></div>
                </div>
            </div>
            <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h1>Students Management</h1>
                <div class="breadcrumb">
                    <a href="../dashboard.php">Dashboard</a> <i class="fas fa-chevron-right" style="margin: 0 8px; font-size: 0.7rem;"></i> Students
                </div>
            </div>
            <a href="add.php" class="action-btn">
                <i class="fas fa-plus"></i> Add New Student
            </a>
        </div>

        <!-- Success Message -->
        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php if($_GET['msg'] == 'added') echo 'Student added successfully!'; ?>
                <?php if($_GET['msg'] == 'updated') echo 'Student updated successfully!'; ?>
                <?php if($_GET['msg'] == 'deleted') echo 'Student deleted successfully!'; ?>
            </div>
        <?php endif; ?>

        <!-- Stats -->
        <?php
        $total = $students->num_rows;
        $placed = mysqli_query($conn, "SELECT COUNT(*) as count FROM students WHERE created_by = $officer_id AND status = 'placed'")->fetch_assoc()['count'];
        $pending = mysqli_query($conn, "SELECT COUNT(*) as count FROM students WHERE created_by = $officer_id AND status = 'pending'")->fetch_assoc()['count'];
        $active = $total - $placed - $pending;
        ?>
        <div class="stats-grid">
            <div class="stat-card"><div class="label">Total Students</div><div class="value"><?= $total ?></div></div>
            <div class="stat-card"><div class="label">Active</div><div class="value"><?= $active ?></div></div>
            <div class="stat-card"><div class="label">Placed</div><div class="value"><?= $placed ?></div></div>
            <div class="stat-card"><div class="label">Pending</div><div class="value"><?= $pending ?></div></div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Search by name, email, roll number...">
            </div>
            <select class="filter-select" id="statusFilter">
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="placed">Placed</option>
            </select>
            <select class="filter-select" id="batchFilter">
                <option value="">All Batches</option>
                <option value="2024">2024</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
            </select>
        </div>

        <!-- Students Table -->
        <div class="table-container">
            <table id="studentsTable">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Roll No.</th>
                        <th>Course</th>
                        <th>Batch</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($students->num_rows > 0): ?>
                        <?php while($student = $students->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="student-info">
                                        <div class="student-avatar"><?= strtoupper(substr($student['full_name'], 0, 2)) ?></div>
                                        <div>
                                            <div style="font-weight: 600;"><?= htmlspecialchars($student['full_name'] ?? '') ?></div>
                                            <div style="font-size: 0.8rem; color: #64748b;"><?= htmlspecialchars($student['email'] ?? '') ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($student['roll_number'] ?? '') ?></td>
                                <td><?= htmlspecialchars($student['course'] ?? '') ?></td>
                                <td><?= htmlspecialchars($student['batch_year'] ?? '') ?></td>
                                <td><?= htmlspecialchars($student['phone'] ?? '') ?></td>
                                <td>
                                    <?php
                                    $status = $student['status'] ?? 'active';
                                    $statusClass = '';
                                    if($status == 'active') $statusClass = 'status-active';
                                    elseif($status == 'pending') $statusClass = 'status-pending';
                                    elseif($status == 'placed') $statusClass = 'status-placed';
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>"><?= ucfirst($status) ?></span>
                                </td>
                                <td>
                                    <div class="action-menu">
                                        <a href="view.php?id=<?= $student['id'] ?>" class="action-btn-icon" title="View"><i class="fas fa-eye"></i></a>
                                        <a href="edit.php?id=<?= $student['id'] ?>" class="action-btn-icon" title="Edit"><i class="fas fa-edit"></i></a>
                                        <a href="?delete=<?= $student['id'] ?>" class="action-btn-icon delete-btn" title="Delete" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" style="text-align: center; padding: 40px;">No students found. <a href="add.php" style="color: #2563eb;">Add your first student</a></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="pagination">
                <button class="page-btn"><i class="fas fa-chevron-left"></i></button>
                <button class="page-btn active">1</button>
                <button class="page-btn">2</button>
                <button class="page-btn">3</button>
                <button class="page-btn"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </div>

    <script>
        // Simple search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let tableRows = document.querySelectorAll('#studentsTable tbody tr');
            
            tableRows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Status filter
        document.getElementById('statusFilter').addEventListener('change', function() {
            let status = this.value.toLowerCase();
            let tableRows = document.querySelectorAll('#studentsTable tbody tr');
            
            tableRows.forEach(row => {
                if(!status) {
                    row.style.display = '';
                    return;
                }
                let rowStatus = row.querySelector('.status-badge')?.textContent.toLowerCase() || '';
                row.style.display = rowStatus.includes(status) ? '' : 'none';
            });
        });
    </script>
</body>
</html>