<?php
require_once '../auth.php';
require_once '../../config/db.php';

$officer_id = $_SESSION['user_id'];

// Handle drive deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $delete_query = "DELETE FROM placement_drives WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: index.php?msg=deleted");
    exit();
}

// Fetch upcoming drives
$upcoming_query = "SELECT d.*, c.company_name, c.location 
                   FROM placement_drives d
                   JOIN companies c ON d.company_id = c.id
                   WHERE d.date >= CURDATE()
                   ORDER BY d.date ASC";
$upcoming = $conn->query($upcoming_query);

// Fetch past drives
$past_query = "SELECT d.*, c.company_name, c.location 
               FROM placement_drives d
               JOIN companies c ON d.company_id = c.id
               WHERE d.date < CURDATE()
               ORDER BY d.date DESC
               LIMIT 5";
$past = $conn->query($past_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Drives | GLA University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Same base styles */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }
        
        /* ===== SIDEBAR - MODERN MINIMAL (SAME AS DASHBOARD) ===== */
.sidebar {
    width: 280px;
    background: white;
    border-right: 1px solid rgba(0,0,0,0.05);
    padding: 32px 20px;
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    z-index: 100;
    box-shadow: 4px 0 20px rgba(0,0,0,0.02);
}

.sidebar-logo {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 40px;
    padding-left: 8px;
}

.logo-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
    box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
}

.logo-text h2 {
    font-size: 1.5rem;
    font-weight: 700;
    color: #0f172a;
    line-height: 1.2;
}

.logo-text span {
    font-size: 0.75rem;
    color: #64748b;
    font-weight: 500;
    letter-spacing: 0.3px;
}

.sidebar-menu {
    list-style: none;
}

.menu-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #94a3b8;
    font-weight: 600;
    padding: 20px 16px 8px;
}

.sidebar-menu li {
    margin-bottom: 4px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 12px 16px;
    color: #475569;
    text-decoration: none;
    border-radius: 14px;
    transition: all 0.2s ease;
    font-weight: 500;
    font-size: 0.95rem;
}

.sidebar-menu a i {
    width: 24px;
    font-size: 1.2rem;
    color: #94a3b8;
    transition: all 0.2s ease;
}

.sidebar-menu a:hover {
    background: #f1f5f9;
    color: #2563eb;
}

.sidebar-menu a:hover i {
    color: #2563eb;
}

.sidebar-menu a.active {
    background: #eef2ff;
    color: #2563eb;
    font-weight: 600;
}

.sidebar-menu a.active i {
    color: #2563eb;
}

/* ===== MAIN CONTENT SHIFT ===== */
.main-content {
    flex: 1;
    margin-left: 280px;
    padding: 32px;
    max-width: calc(100vw - 280px);
}

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
        }

        .action-btn {
            background: #2563eb;
            color: white;
            padding: 14px 28px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Calendar View */
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .calendar-nav {
            display: flex;
            gap: 12px;
        }

        .nav-btn {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            background: white;
            color: #64748b;
            cursor: pointer;
            transition: all 0.2s;
        }
        .nav-btn:hover {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }

        .current-month {
            font-size: 1.3rem;
            font-weight: 600;
            color: #0f172a;
        }

        /* Drives Grid */
        .drives-section {
            margin-bottom: 40px;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }
        .section-title h2 {
            font-size: 1.3rem;
            font-weight: 600;
            color: #0f172a;
        }
        .section-title .badge {
            background: #eef2ff;
            color: #2563eb;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .drives-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 24px;
        }

        .drive-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .drive-card.upcoming::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #10b981, #34d399);
        }

        .drive-card.past {
            opacity: 0.8;
        }

        .drive-date {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .date-box {
            width: 70px;
            height: 70px;
            background: #eef2ff;
            border-radius: 18px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .date-box .day {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2563eb;
            line-height: 1;
        }
        .date-box .month {
            font-size: 0.8rem;
            color: #64748b;
            text-transform: uppercase;
        }

        .drive-info h3 {
            font-size: 1.2rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .drive-info .company {
            color: #2563eb;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .drive-details {
            margin: 20px 0;
        }

        .detail-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .detail-row i {
            width: 20px;
            color: #2563eb;
        }
        .detail-row .label {
            color: #64748b;
            font-size: 0.9rem;
        }
        .detail-row .value {
            font-weight: 600;
            color: #0f172a;
            margin-left: auto;
        }

        .drive-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-upcoming { background: #dbeafe; color: #2563eb; }
        .status-ongoing { background: #d1fae5; color: #059669; }
        .status-completed { background: #e2e8f0; color: #475569; }

        .action-menu {
            display: flex;
            gap: 8px;
        }
        .action-btn-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            text-decoration: none;
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
        }
        .action-btn-icon:hover {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }

        /* Timeline View */
        .timeline-view {
            background: white;
            border-radius: 24px;
            padding: 24px;
            margin-top: 32px;
        }

        .timeline-item {
            display: flex;
            gap: 24px;
            padding: 20px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .timeline-item:last-child { border-bottom: none; }

        .timeline-time {
            min-width: 100px;
        }
        .timeline-time .time {
            font-weight: 600;
            color: #2563eb;
        }
        .timeline-time .date {
            font-size: 0.8rem;
            color: #64748b;
        }

        .timeline-content {
            flex: 1;
        }
        .timeline-content h4 {
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 6px;
        }
        .timeline-content p {
            color: #64748b;
            font-size: 0.9rem;
        }

        .alert {
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success { background: #d1fae5; color: #065f46; }
    </style>
</head>
<body>
    <!-- Sidebar (same structure) -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon"><i class="fas fa-briefcase"></i></div>
            <div class="logo-text"><h2>Placement Officers</h2><span>GLA University</span></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="../dashboard.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="../students/index.php"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="../companies/index.php"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="index.php" class="active"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="../applications/index.php"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="../placements/index.php"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1>Placement Drives</h1>
                <div class="breadcrumb">
                    <a href="../dashboard.php">Dashboard</a> <i class="fas fa-chevron-right" style="margin: 0 8px;"></i> Drives
                </div>
            </div>
            <a href="add.php" class="action-btn">
                <i class="fas fa-plus"></i> Schedule Drive
            </a>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php if($_GET['msg'] == 'added') echo 'Drive scheduled successfully!'; ?>
                <?php if($_GET['msg'] == 'updated') echo 'Drive updated successfully!'; ?>
                <?php if($_GET['msg'] == 'deleted') echo 'Drive deleted successfully!'; ?>
            </div>
        <?php endif; ?>

        <!-- Calendar Navigation -->
        <div class="calendar-header">
            <div class="current-month">
                <i class="fas fa-calendar-alt" style="color: #2563eb; margin-right: 12px;"></i>
                <?= date('F Y') ?>
            </div>
            <div class="calendar-nav">
                <button class="nav-btn"><i class="fas fa-chevron-left"></i></button>
                <button class="nav-btn"><i class="fas fa-chevron-right"></i></button>
                <button class="nav-btn"><i class="fas fa-calendar-week"></i></button>
            </div>
        </div>

        <!-- Upcoming Drives -->
        <div class="drives-section">
            <div class="section-title">
                <h2>Upcoming Drives</h2>
                <span class="badge"><?= $upcoming->num_rows ?> Scheduled</span>
            </div>

            <div class="drives-grid">
                <?php if($upcoming->num_rows > 0): ?>
                    <?php while($drive = $upcoming->fetch_assoc()): ?>
                        <div class="drive-card upcoming">
                            <div class="drive-date">
                                <div class="date-box">
                                    <span class="day"><?= date('d', strtotime($drive['date'])) ?></span>
                                    <span class="month"><?= date('M', strtotime($drive['date'])) ?></span>
                                </div>
                                <div class="drive-info">
                                    <h3><?= htmlspecialchars($drive['company_name']) ?></h3>
                                    <div class="company">
                                        <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($drive['location'] ?? 'Online') ?>
                                    </div>
                                </div>
                            </div>

                            <div class="drive-details">
                                <div class="detail-row">
                                    <i class="fas fa-clock"></i>
                                    <span class="label">Time</span>
                                    <span class="value"><?= htmlspecialchars($drive['drive_time'] ?? '10:00 AM') ?></span>
                                </div>
                                <div class="detail-row">
                                    <i class="fas fa-map-pin"></i>
                                    <span class="label">Venue</span>
                                    <span class="value"><?= htmlspecialchars($drive['venue'] ?? 'Online') ?></span>
                                </div>
                                <div class="detail-row">
                                    <i class="fas fa-users"></i>
                                    <span class="label">Positions</span>
                                    <span class="value"><?= htmlspecialchars($drive['positions'] ?? 'Multiple') ?></span>
                                </div>
                            </div>

                            <div class="drive-footer">
                                <span class="status-badge status-upcoming">Upcoming</span>
                                <div class="action-menu">
                                    <a href="view.php?id=<?= $drive['id'] ?>" class="action-btn-icon"><i class="fas fa-eye"></i></a>
                                    <a href="edit.php?id=<?= $drive['id'] ?>" class="action-btn-icon"><i class="fas fa-edit"></i></a>
                                    <a href="?delete=<?= $drive['id'] ?>" class="action-btn-icon" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="grid-column: 1/-1; text-align: center; padding: 60px; background: white; border-radius: 24px;">
                        <i class="fas fa-calendar-times" style="font-size: 3rem; color: #94a3b8; margin-bottom: 16px;"></i>
                        <h3 style="color: #1e293b;">No upcoming drives</h3>
                        <p style="color: #64748b; margin: 16px 0;">Schedule your first placement drive</p>
                        <a href="add.php" style="background: #2563eb; color: white; padding: 12px 24px; border-radius: 14px; text-decoration: none;">Schedule Drive</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Past Drives Timeline -->
        <?php if($past->num_rows > 0): ?>
        <div class="timeline-view">
            <div class="section-title">
                <h2>Past Drives</h2>
                <span class="badge">Recent Activity</span>
            </div>

            <?php while($drive = $past->fetch_assoc()): ?>
                <div class="timeline-item">
                    <div class="timeline-time">
                        <div class="time"><?= date('h:i A', strtotime($drive['drive_time'] ?? '10:00')) ?></div>
                        <div class="date"><?= date('d M Y', strtotime($drive['date'])) ?></div>
                    </div>
                    <div class="timeline-content">
                        <h4><?= htmlspecialchars($drive['company_name']) ?> Placement Drive</h4>
                        <p><?= htmlspecialchars($drive['venue'] ?? 'Online') ?> • <?= htmlspecialchars($drive['positions'] ?? 'Multiple') ?> positions</p>
                    </div>
                    <div style="margin-left: auto;">
                        <span class="status-badge status-completed">Completed</span>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>