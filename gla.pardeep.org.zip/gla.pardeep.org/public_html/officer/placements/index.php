<?php
require_once '../auth.php';
require_once '../../config/db.php';

$officer_id = $_SESSION['user_id'];

// Fetch placements
$query = "SELECT p.*, s.full_name as student_name, s.roll_number, s.course,
                 c.company_name, c.industry
          FROM placements p
          JOIN students s ON p.student_id = s.id
          JOIN companies c ON p.company_id = c.id
          WHERE s.created_by = ?
          ORDER BY p.placement_date DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$placements = $stmt->get_result();

// Statistics
$total_placed = $placements->num_rows;
$avg_package = mysqli_query($conn, "SELECT AVG(package) as avg FROM placements p JOIN students s ON p.student_id = s.id WHERE s.created_by = $officer_id")->fetch_assoc()['avg'];
$highest_package = mysqli_query($conn, "SELECT MAX(package) as max FROM placements p JOIN students s ON p.student_id = s.id WHERE s.created_by = $officer_id")->fetch_assoc()['max'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placements | GLA University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Same base styles */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }
        
        .sidebar { /* same as before */ }
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }
        .stat-card .label { color: #64748b; font-size: 0.9rem; }
        .stat-card .value { font-size: 2rem; font-weight: 700; color: #0f172a; }
        .stat-card .sub { color: #2563eb; font-size: 0.9rem; margin-top: 8px; }

        /* Placements Grid */
        .placements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }

        .placement-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .placement-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 30px -10px rgba(37, 99, 235, 0.1);
        }

        .placement-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(180deg, #2563eb, #60a5fa);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .student-info h3 {
            font-size: 1.2rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .student-info .course {
            color: #64748b;
            font-size: 0.85rem;
        }

        .package-badge {
            background: #dbeafe;
            color: #2563eb;
            padding: 6px 14px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1rem;
        }

        .company-details {
            margin: 16px 0;
            padding: 16px 0;
            border-top: 1px solid #f1f5f9;
            border-bottom: 1px solid #f1f5f9;
        }

        .company-name {
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .company-name i { color: #2563eb; }

        .company-meta {
            display: flex;
            gap: 16px;
            color: #64748b;
            font-size: 0.85rem;
        }

        .placement-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
        }

        .placement-date {
            color: #94a3b8;
            font-size: 0.85rem;
        }

        .action-btns {
            display: flex;
            gap: 8px;
        }
        .action-btn-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            text-decoration: none;
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
        }
        .action-btn-icon:hover {
            background: #2563eb;
            color: white;
            border-color: #2563eb;
        }

        /* Achievements Section */
        .achievements-section {
            background: white;
            border-radius: 24px;
            padding: 24px;
            margin-top: 32px;
        }

        .achievement-badges {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .achievement-badge {
            background: #f1f5f9;
            border-radius: 16px;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .achievement-badge i {
            font-size: 2rem;
            color: #2563eb;
        }
        .achievement-badge .count {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
        }
        .achievement-badge .label {
            color: #64748b;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon"><i class="fas fa-briefcase"></i></div>
            <div class="logo-text"><h2>PlacePro</h2><span>GLA University</span></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="../dashboard.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="../students/index.php"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="../companies/list.php"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="../drives/index.php"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="../applications/list.php"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="list.php" class="active"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1>Placements</h1>
                <div class="breadcrumb">
                    <a href="../dashboard.php">Dashboard</a> <i class="fas fa-chevron-right" style="margin: 0 8px;"></i> Placements
                </div>
            </div>
            <a href="add.php" class="action-btn">
                <i class="fas fa-plus"></i> Add Placement
            </a>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="label">Total Placed</div>
                <div class="value"><?= $total_placed ?></div>
                <div class="sub">students</div>
            </div>
            <div class="stat-card">
                <div class="label">Average Package</div>
                <div class="value">₹<?= number_format($avg_package ?? 0, 1) ?>L</div>
                <div class="sub">per annum</div>
            </div>
            <div class="stat-card">
                <div class="label">Highest Package</div>
                <div class="value">₹<?= number_format($highest_package ?? 0, 1) ?>L</div>
                <div class="sub">this year</div>
            </div>
            <div class="stat-card">
                <div class="label">Placement %</div>
                <?php
                $total_students = mysqli_query($conn, "SELECT COUNT(*) as count FROM students WHERE created_by = $officer_id")->fetch_assoc()['count'];
                $percentage = $total_students > 0 ? round(($total_placed / $total_students) * 100) : 0;
                ?>
                <div class="value"><?= $percentage ?>%</div>
                <div class="sub">placement rate</div>
            </div>
        </div>

        <!-- Placements Grid -->
        <div class="placements-grid">
            <?php if($placements->num_rows > 0): ?>
                <?php while($placement = $placements->fetch_assoc()): ?>
                    <div class="placement-card">
                        <div class="card-header">
                            <div class="student-info">
                                <h3><?= htmlspecialchars($placement['student_name']) ?></h3>
                                <div class="course"><?= htmlspecialchars($placement['course']) ?> • <?= htmlspecialchars($placement['roll_number']) ?></div>
                            </div>
                            <?php if(isset($placement['package'])): ?>
                                <span class="package-badge">₹<?= number_format($placement['package'], 1) ?>L</span>
                            <?php endif; ?>
                        </div>

                        <div class="company-details">
                            <div class="company-name">
                                <i class="fas fa-building"></i> <?= htmlspecialchars($placement['company_name']) ?>
                            </div>
                            <div class="company-meta">
                                <span><i class="fas fa-tag"></i> <?= htmlspecialchars($placement['industry'] ?? 'Technology') ?></span>
                            </div>
                        </div>

                        <div class="placement-footer">
                            <span class="placement-date">
                                <i class="far fa-calendar-alt"></i> <?= date('d M Y', strtotime($placement['placement_date'])) ?>
                            </span>
                            <div class="action-btns">
                                <a href="view.php?id=<?= $placement['id'] ?>" class="action-btn-icon" title="View Details"><i class="fas fa-eye"></i></a>
                                <a href="edit.php?id=<?= $placement['id'] ?>" class="action-btn-icon" title="Edit"><i class="fas fa-edit"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 60px; background: white; border-radius: 24px;">
                    <i class="fas fa-handshake" style="font-size: 3rem; color: #94a3b8; margin-bottom: 16px;"></i>
                    <h3 style="color: #1e293b;">No placements yet</h3>
                    <p style="color: #64748b; margin: 16px 0;">Start adding placements to track student success</p>
                    <a href="add.php" style="background: #2563eb; color: white; padding: 12px 24px; border-radius: 14px; text-decoration: none;">Add Placement</a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Achievements -->
        <div class="achievements-section">
            <h3 style="font-size: 1.2rem; margin-bottom: 20px;">🎉 Placement Achievements</h3>
            <div class="achievement-badges">
                <div class="achievement-badge">
                    <i class="fas fa-trophy"></i>
                    <div>
                        <div class="count"><?= $total_placed ?></div>
                        <div class="label">Total Placements</div>
                    </div>
                </div>
                <div class="achievement-badge">
                    <i class="fas fa-star"></i>
                    <div>
                        <div class="count">₹<?= number_format($highest_package ?? 0, 1) ?>L</div>
                        <div class="label">Highest Package</div>
                    </div>
                </div>
                <div class="achievement-badge">
                    <i class="fas fa-chart-line"></i>
                    <div>
                        <div class="count"><?= $percentage ?>%</div>
                        <div class="label">Placement Rate</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>