<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'auth.php';
require_once '../config/db.php';

// Get real data from database
$officer_id = (int) $_SESSION['user_id'];

// Pending approvals (students waiting for verification)
$pending_query = "SELECT COUNT(*) as count FROM students WHERE status = 'pending' AND created_by = ?";
$stmt = $conn->prepare($pending_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$pending_result = $stmt->get_result()->fetch_assoc();
$pending = $pending_result['count'] ?? 0;

// Total active jobs/companies
$jobs_query = "SELECT COUNT(*) as count FROM companies WHERE status = 'active'";
$jobs_result = $conn->query($jobs_query);
$jobs = $jobs_result->fetch_assoc()['count'] ?? 0;

// Total applications received
$apps_query = "SELECT COUNT(*) as count FROM applications WHERE placement_officer_id = ?";
$stmt = $conn->prepare($apps_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$apps_result = $stmt->get_result()->fetch_assoc();
$applications = $apps_result['count'] ?? 0;

// Total students under this officer
$students_query = "SELECT COUNT(*) as count FROM students WHERE created_by = ?";
$stmt = $conn->prepare($students_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$students_result = $stmt->get_result()->fetch_assoc();
$total_students = $students_result['count'] ?? 0;

// Placement statistics
$placed_query = "SELECT COUNT(*) as count FROM placements p JOIN students s ON p.student_id = s.id WHERE s.created_by = ?";
$stmt = $conn->prepare($placed_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$placed_result = $stmt->get_result()->fetch_assoc();
$placed_students = $placed_result['count'] ?? 0;

// Recent placements
$recent_query = "
SELECT s.full_name as student_name,
c.company_name as company_name,
c.logo as company_logo,
p.placement_date,
p.package
FROM placements p
JOIN students s ON p.student_id = s.id
JOIN companies c ON p.company_id = c.id
WHERE s.created_by = ?
ORDER BY p.placement_date DESC
LIMIT 5
";
$stmt = $conn->prepare($recent_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$recent_placements = $stmt->get_result();

// Upcoming drives
$drives_query = "
SELECT company_name, date, drive_time, venue, positions
FROM placement_drives 
WHERE date >= CURDATE() 
AND drive_status = 'active' 
ORDER BY date ASC 
LIMIT 3
";
$drives_result = $conn->query($drives_query);

// Get officer name
$officer_query = "SELECT name, email, profile_pic FROM placement_officers WHERE id = ?";
$stmt = $conn->prepare($officer_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$officer_result = $stmt->get_result()->fetch_assoc();
$officer_name = $officer_result['name'] ?? 'Placement Officer';
$officer_email = $officer_result['email'] ?? '';
$profile_pic   = $officer_result['profile_pic'] ?? '';

// Monthly placement data for chart
$monthly_query = "
SELECT MONTH(placement_date) as month, COUNT(*) as count
FROM placements p
JOIN students s ON p.student_id = s.id
WHERE s.created_by = ? AND YEAR(placement_date) = YEAR(CURDATE())
GROUP BY MONTH(placement_date)
ORDER BY month
";
$stmt = $conn->prepare($monthly_query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$monthly_data = $stmt->get_result();
$months = array_fill(0, 12, 0);
while ($row = $monthly_data->fetch_assoc()) {
    $months[$row['month']-1] = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Officer Dashboard | GLA University</title>
    
    <!-- Fonts & Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }

        /* ===== SIDEBAR - MODERN MINIMAL ===== */
        .sidebar {
            width: 280px;
            background: white;
            border-right: 1px solid rgba(0,0,0,0.05);
            padding: 32px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            box-shadow: 4px 0 20px rgba(0,0,0,0.02);
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            padding-left: 8px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
        }

        .logo-text h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
        }

        .logo-text span {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 500;
            letter-spacing: 0.3px;
        }

        .sidebar-menu {
            list-style: none;
        }

        .menu-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #94a3b8;
            font-weight: 600;
            padding: 20px 16px 8px;
        }

        .sidebar-menu li {
            margin-bottom: 4px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 12px 16px;
            color: #475569;
            text-decoration: none;
            border-radius: 14px;
            transition: all 0.2s ease;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .sidebar-menu a i {
            width: 24px;
            font-size: 1.2rem;
            color: #94a3b8;
            transition: all 0.2s ease;
        }

        .sidebar-menu a:hover {
            background: #f1f5f9;
            color: #2563eb;
        }

        .sidebar-menu a:hover i {
            color: #2563eb;
        }

        .sidebar-menu a.active {
            background: #eef2ff;
            color: #2563eb;
            font-weight: 600;
        }

        .sidebar-menu a.active i {
            color: #2563eb;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 32px;
            left: 20px;
            right: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            padding: 8px 12px;
            background: #f8fafc;
            border-radius: 16px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1.2rem;
            color: white;
            box-shadow: 0 8px 12px -4px rgba(37, 99, 235, 0.2);
        }

        .user-details {
            flex: 1;
        }

        .user-name {
            font-weight: 700;
            color: #0f172a;
            font-size: 0.95rem;
        }

        .user-email {
            font-size: 0.7rem;
            color: #64748b;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: #fef2f2;
            border-radius: 14px;
            color: #ef4444;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }

        .logout-btn:hover {
            background: #ef4444;
            color: white;
        }

        .logout-btn:hover i {
            color: white;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px;
            max-width: calc(100vw - 280px);
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }

        .greeting h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .greeting .subtitle {
            color: #64748b;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .greeting .subtitle i {
            color: #2563eb;
        }

        .date-badge {
            background: #f1f5f9;
            padding: 12px 20px;
            border-radius: 18px;
            text-align: center;
        }

        .date-badge .day {
            font-weight: 700;
            color: #0f172a;
            font-size: 1.1rem;
        }

        .date-badge .month {
            color: #64748b;
            font-size: 0.9rem;
        }

        /* ===== STATS CARDS ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #2563eb, #60a5fa);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 30px -10px rgba(37, 99, 235, 0.1);
        }

        .stat-card:hover::before {
            opacity: 1;
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .stat-title {
            color: #64748b;
            font-size: 0.9rem;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            background: #eef2ff;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2563eb;
            font-size: 1.4rem;
        }

        .stat-value {
            font-size: 2.2rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 8px;
            line-height: 1;
        }

        .stat-footer {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #64748b;
            font-size: 0.85rem;
        }

        .trend-up {
            color: #10b981;
            background: #d1fae5;
            padding: 4px 8px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.75rem;
        }

        .trend-down {
            color: #ef4444;
            background: #fee2e2;
            padding: 4px 8px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.75rem;
        }

        /* ===== CHARTS SECTION ===== */
        .charts-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 32px;
        }

        .chart-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .chart-title {
            font-weight: 600;
            color: #0f172a;
            font-size: 1.1rem;
        }

        .chart-badge {
            background: #f1f5f9;
            padding: 6px 12px;
            border-radius: 30px;
            color: #475569;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }

        /* ===== ACTIVITY GRID ===== */
        .activity-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 32px;
        }

        .activity-card {
            background: white;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border: 1px solid rgba(0,0,0,0.03);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-header h3 {
            font-size: 1.1rem;
            font-weight: 600;
            color: #0f172a;
        }

        .card-header a {
            color: #2563eb;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .company-logo {
            width: 48px;
            height: 48px;
            background: #eef2ff;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2563eb;
            font-weight: 600;
            font-size: 1.2rem;
        }

        .activity-info {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 4px;
        }

        .activity-meta {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #64748b;
            font-size: 0.8rem;
        }

        .activity-meta i {
            color: #94a3b8;
        }

        .package-badge {
            background: #dbeafe;
            color: #2563eb;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .drive-item {
            display: flex;
            gap: 16px;
            padding: 16px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .drive-date {
            text-align: center;
            min-width: 60px;
        }

        .drive-date .day {
            font-size: 1.5rem;
            font-weight: 700;
            color: #2563eb;
            line-height: 1;
        }

        .drive-date .month {
            font-size: 0.8rem;
            color: #64748b;
            text-transform: uppercase;
        }

        .drive-details h4 {
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .drive-meta {
            display: flex;
            gap: 16px;
            color: #64748b;
            font-size: 0.8rem;
        }

        /* ===== QUICK ACTIONS ===== */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
        }

        .action-btn {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 18px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            background: #2563eb;
            border-color: #2563eb;
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(37, 99, 235, 0.2);
        }

        .action-btn i {
            font-size: 2rem;
            color: #2563eb;
            margin-bottom: 12px;
            transition: all 0.3s ease;
        }

        .action-btn span {
            display: block;
            color: #0f172a;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }

        .action-btn:hover i,
        .action-btn:hover span {
            color: white;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 100px;
                padding: 24px 12px;
            }
            
            .logo-text, .menu-label span, .sidebar-menu a span, 
            .user-details, .logout-btn span {
                display: none;
            }
            
            .sidebar-menu a {
                justify-content: center;
                padding: 16px;
            }
            
            .sidebar-menu a i {
                margin: 0;
                font-size: 1.4rem;
            }
            
            .user-info {
                justify-content: center;
                padding: 12px 8px;
            }
            
            .logout-btn {
                justify-content: center;
                padding: 16px;
            }
            
            .main-content {
                margin-left: 100px;
            }
            
            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .activity-grid {
                grid-template-columns: 1fr;
            }
            
            .top-bar {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="logo-text">
                <h2>Placement Officers</h2>
                <span>GLA University</span>
            </div>
        </div>

        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="dashboard.php" class="active"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="students/index.php"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="companies/index.php"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="drives/index.php"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="applications/index.php"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="placements/index.php"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
            
            <li class="menu-label"><span>ANALYTICS</span></li>
            <li><a href="reports/index.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
            <li><a href="analytics/index.php"><i class="fas fa-analytics"></i> <span>Analytics</span></a></li>
        </ul>

        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar" style="overflow:hidden;">
<?php if(!empty($profile_pic) && file_exists("../uploads/officers/".$profile_pic)): ?>
    <img src="../uploads/officers/<?= htmlspecialchars($profile_pic) ?>" style="width:100%;height:100%;object-fit:cover;">
<?php else: ?>
    <?= strtoupper(substr($officer_name, 0, 2)) ?>
<?php endif; ?>
</div>
                <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars(explode(' ', $officer_name)[0]) ?></div>
                    <div class="user-email"><?= htmlspecialchars($officer_email) ?></div>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="greeting">
                <h1>Welcome back, <?= explode(' ', $officer_name)[0] ?>! 👋</h1>
                <div class="subtitle">
                    <i class="fas fa-university"></i>
                    <span>GLA University, Mathura · Placement Officer</span>
                </div>
            </div>
            <div class="date-badge">
                <div class="day"><?= date('d') ?></div>
                <div class="month"><?= date('M Y') ?></div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Pending Approvals</span>
                    <span class="stat-icon"><i class="fas fa-clock"></i></span>
                </div>
                <div class="stat-value"><?= $pending ?></div>
                <div class="stat-footer">
                    <div class="stat-footer">
    <span><?= $pending ?> awaiting verification</span>
</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Total Students</span>
                    <span class="stat-icon"><i class="fas fa-user-graduate"></i></span>
                </div>
                <div class="stat-value"><?= $total_students ?></div>
                <div class="stat-footer">
                    <span class="trend-up"><i class="fas fa-arrow-up"></i> <?= $placed_students ?></span>
                    <span>placed</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Active Jobs</span>
                    <span class="stat-icon"><i class="fas fa-briefcase"></i></span>
                </div>
                <div class="stat-value"><?= $jobs ?></div>
                <div class="stat-footer">
                    <i class="fas fa-building"></i>
                    <span>open positions</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Applications</span>
                    <span class="stat-icon"><i class="fas fa-file-signature"></i></span>
                </div>
                <div class="stat-value"><?= $applications ?></div>
                <div class="stat-footer">
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-section">
            <div class="chart-card">
                <div class="chart-header">
                    <span class="chart-title">Placement Trends 2026</span>
                    <span class="chart-badge"><i class="fas fa-calendar"></i> Monthly</span>
                </div>
                <div class="chart-container">
                    <canvas id="placementChart"></canvas>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <span class="chart-title">Placement Status</span>
                    <span class="chart-badge"><i class="fas fa-chart-pie"></i> Distribution</span>
                </div>
                <div class="chart-container">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Activity Grid -->
        <div class="activity-grid">
            <!-- Recent Placements -->
            <div class="activity-card">
                <div class="card-header">
                    <h3><i class="fas fa-handshake" style="color: #2563eb; margin-right: 8px;"></i> Recent Placements</h3>
                    <a href="placements/index.php">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <ul class="activity-list">
                    <?php if($recent_placements->num_rows > 0): ?>
                        <?php while($placement = $recent_placements->fetch_assoc()): ?>
                            <li class="activity-item">
                                <div class="company-logo" style="overflow:hidden;">
<?php if(!empty($placement['company_logo']) && file_exists("../uploads/company/".$placement['company_logo'])): ?>
    <img src="../uploads/company/<?= htmlspecialchars($placement['company_logo']) ?>" 
         style="width:100%;height:100%;object-fit:cover;">
<?php else: ?>
    <?= strtoupper(substr($placement['company_name'], 0, 2)) ?>
<?php endif; ?>
</div>
                                <div class="activity-info">
                                    <div class="activity-title">
                                        <?= htmlspecialchars($placement['student_name']) ?>
                                    </div>
                                    <div class="activity-meta">
                                        <span><i class="fas fa-building"></i> <?= htmlspecialchars($placement['company_name']) ?></span>
                                        <span><i class="fas fa-calendar"></i> <?= date('d M Y', strtotime($placement['placement_date'])) ?></span>
                                    </div>
                                </div>
                                <?php if(isset($placement['package'])): ?>
                                    <span class="package-badge">₹<?= number_format($placement['package']) ?>L</span>
                                <?php endif; ?>
                            </li>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <li class="activity-item">
                            <div class="activity-info">
                                <div class="activity-title">No placements yet</div>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Upcoming Drives -->
            <div class="activity-card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-check" style="color: #2563eb; margin-right: 8px;"></i> Upcoming Drives</h3>
                    <a href="drives/add.php">Schedule <i class="fas fa-plus"></i></a>
                </div>
                
                <ul class="activity-list">
                    <?php if($drives_result && $drives_result->num_rows > 0): ?>
                        <?php while($drive = $drives_result->fetch_assoc()): ?>
                            <li class="drive-item">
                                <div class="drive-date">
                                    <div class="day"><?= date('d', strtotime($drive['date'])) ?></div>
                                    <div class="month"><?= date('M', strtotime($drive['date'])) ?></div>
                                </div>
                                <div class="drive-details">
                                    <h4><?= htmlspecialchars($drive['company_name']) ?></h4>
                                    <div class="drive-meta">
                                        <span><i class="fas fa-clock"></i> <?= !empty($drive['drive_time']) ? htmlspecialchars($drive['drive_time']) : 'TBA' ?></span>
                                        <span><i class="fas fa-map-marker-alt"></i> <?= !empty($drive['venue']) ? htmlspecialchars($drive['venue']) : 'TBA' ?></span>
                                    </div>
                                    <?php if(isset($drive['positions'])): ?>
                                        <div style="margin-top: 6px;">
                                            <span class="package-badge"><?= htmlspecialchars($drive['positions']) ?> positions</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <li class="activity-item">
                            <div class="activity-info">
                                <div class="activity-title">No upcoming drives</div>
                                <a href="drives/add.php" style="color: #2563eb; font-size: 0.85rem;">Schedule your first drive →</a>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="students/add.php" class="action-btn">
                <i class="fas fa-user-plus"></i>
                <span>Add Student</span>
            </a>
            <a href="companies/add.php" class="action-btn">
                <i class="fas fa-building"></i>
                <span>Add Company</span>
            </a>
            <a href="drives/add.php" class="action-btn">
                <i class="fas fa-calendar-plus"></i>
                <span>Schedule Drive</span>
            </a>
            <a href="reports/generate.php" class="action-btn">
                <i class="fas fa-download"></i>
                <span>Export Data</span>
            </a>
        </div>
    </div>

    <script>
        // Placement Trends Chart
        const ctx1 = document.getElementById('placementChart').getContext('2d');
        new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Placements',
                    data: <?= json_encode($months) ?>,
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    borderWidth: 3,
                    pointBackgroundColor: '#2563eb',
                    pointBorderColor: 'white',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#e2e8f0',
                            drawBorder: false
                        },
                        ticks: {
                            stepSize: 2,
                            color: '#64748b'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#64748b'
                        }
                    }
                }
            }
        });

        // Student Status Chart
        const ctx2 = document.getElementById('statusChart').getContext('2d');
        new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: ['Placed', 'Applied', 'Registered', 'Not Applied'],
                datasets: [{
                    data: [<?= $placed_students ?>, <?= $applications ?>, <?= $total_students - $placed_students - $applications ?>, 0],
                    backgroundColor: ['#2563eb', '#60a5fa', '#93c5fd', '#e2e8f0'],
                    borderWidth: 0,
                    borderRadius: 10,
                    spacing: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            color: '#475569',
                            font: {
                                size: 12,
                                weight: 500
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>