<?php
require_once '../config/db.php';
require_once '../config/mail.php';

$id=(int)$_GET['id'];

$stmt=$conn->prepare(
"SELECT full_name,email FROM students WHERE id=?"
);
$stmt->bind_param("i",$id);
$stmt->execute();
$res=$stmt->get_result();
$user=$res->fetch_assoc();

/* reject */
$stmt=$conn->prepare(
"UPDATE students SET status='rejected' WHERE id=?"
);
$stmt->bind_param("i",$id);
$stmt->execute();

/* rejection mail */

$subject="GLA Placement Registration Update";

$message="
<h3>Dear {$user['full_name']},</h3>

<p>Your registration could not be approved.</p>

<p>Please contact placement cell.</p>

GLA Placement Team
";

sendMail($user['email'],$user['full_name'],$subject,$message);

header("Location: students.php");
exit;