<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);


require_once '../config/session.php';
require_once '../config/db.php';
require_once '../api/mail/mailer.php';

$step = 'forgot';
$message = '';
$message_type = '';

/* =========================
   REQUEST RESET
========================= */

if(isset($_POST['action']) && $_POST['action']=='request_reset'){

$email_or_id = trim($_POST['email_or_id']);

if(filter_var($email_or_id,FILTER_VALIDATE_EMAIL)){
$stmt=$conn->prepare("SELECT * FROM placement_officers WHERE email=?");
}else{
$stmt=$conn->prepare("SELECT * FROM placement_officers WHERE staff_id=?");
}

$stmt->bind_param("s",$email_or_id);
$stmt->execute();
$user=$stmt->get_result()->fetch_assoc();

if($user && !empty($user['email'])){

/* ===== LIMIT RESET REQUESTS (2 PER HOUR) ===== */

$limit_stmt=$conn->prepare("SELECT reset_expiry FROM placement_officers WHERE id=?");
$limit_stmt->bind_param("i",$user['id']);
$limit_stmt->execute();
$limit=$limit_stmt->get_result()->fetch_assoc();

if($limit && $limit['reset_expiry'] && strtotime($limit['reset_expiry']) > time()-3600){

$message="Password reset already requested recently. Please wait before requesting again.";
$message_type="error";

}else{

/* ===== GENERATE TOKEN ===== */

$token = bin2hex(random_bytes(32));
$token_hash = hash('sha256',$token);

$expiry = date('Y-m-d H:i:s',strtotime('+30 minutes'));

/* ===== STORE TOKEN HASH ===== */

$update=$conn->prepare("UPDATE placement_officers SET reset_token=?, reset_expiry=? WHERE id=?");
$update->bind_param("ssi",$token_hash,$expiry,$user['id']);
$update->execute();

/* ===== RESET LINK ===== */

$reset_link="https://gla.pardeep.org/officer/forgot.php?action=reset&token=".$token;

/* ===== EMAIL CONTENT ===== */

$subject="Password Reset - Placement Portal";

$body="

<h3>Password Reset Request</h3>

<p>You requested to reset your password.</p>

<p>
<a href='$reset_link'
style='padding:12px 20px;background:#10b981;color:white;text-decoration:none;border-radius:6px'>
Reset Password
</a>
</p>

<p>This link will expire in <b>30 minutes</b>.</p>

<p>If you did not request this, ignore this email.</p>

";

/* ===== SEND EMAIL USING CENTRAL MAILER ===== */

$mailSent = sendMail($user['email'],$subject,$body);

if($mailSent){
$message="Password reset link sent to your email.";
$message_type="success";
}else{
$message="Failed to send reset email.";
$message_type="error";
}

}

}else{

$message="No account found with that Staff ID or Email.";
$message_type="error";

}

}

/* =========================
   VERIFY TOKEN
========================= */

if(isset($_GET['action']) && $_GET['action']=='reset' && isset($_GET['token'])){

$token=trim($_GET['token']);
$token_hash=hash('sha256',$token);

$stmt=$conn->prepare("SELECT * FROM placement_officers WHERE reset_token=? AND reset_expiry>NOW()");
$stmt->bind_param("s",$token_hash);
$stmt->execute();
$user=$stmt->get_result()->fetch_assoc();

if($user){

$step='reset';
$reset_token=$token;

}else{

$message="Invalid or expired reset link.";
$message_type="error";

}

}

/* =========================
   RESET PASSWORD
========================= */

if(isset($_POST['action']) && $_POST['action']=='reset_password'){

$token=trim($_POST['token']);
$token_hash=hash('sha256',$token);

$new_password=trim($_POST['new_password']);
$confirm_password=trim($_POST['confirm_password']);

if($new_password!==$confirm_password){

$message="Passwords do not match.";
$message_type="error";
$step="reset";
$reset_token=$token;

}elseif(strlen($new_password)<8){

$message="Password must be at least 8 characters.";
$message_type="error";
$step="reset";
$reset_token=$token;

}else{

$stmt=$conn->prepare("SELECT * FROM placement_officers WHERE reset_token=? AND reset_expiry>NOW()");
$stmt->bind_param("s",$token_hash);
$stmt->execute();
$user=$stmt->get_result()->fetch_assoc();

if($user){

$hashed_password=password_hash($new_password,PASSWORD_DEFAULT);

$update=$conn->prepare("UPDATE placement_officers SET password=?, reset_token=NULL, reset_expiry=NULL WHERE id=?");
$update->bind_param("si",$hashed_password,$user['id']);
$update->execute();

$message="Password reset successful. You can now login.";
$message_type="success";
$step="forgot";

}else{

$message="Invalid or expired reset link.";
$message_type="error";

}

}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password · Placement Cell</title>
    <!-- Font Awesome 6 (free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Inter + Space Grotesk -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #0b1120 0%, #19223c 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }

        /* abstract animated shapes */
        .shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(90px);
            opacity: 0.4;
            z-index: 0;
        }
        .shape-1 {
            background: #3b82f6;
            width: 300px;
            height: 300px;
            top: -100px;
            left: -100px;
            animation: float 18s ease-in-out infinite;
        }
        .shape-2 {
            background: #8b5cf6;
            width: 400px;
            height: 400px;
            bottom: -150px;
            right: -100px;
            animation: float 22s ease-in-out infinite reverse;
        }
        .shape-3 {
            background: #10b981;
            width: 200px;
            height: 200px;
            bottom: 30%;
            left: 10%;
            animation: float 14s ease-in-out infinite 2s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            33% { transform: translateY(-30px) translateX(20px); }
            66% { transform: translateY(20px) translateX(-20px); }
        }

        .container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 480px;
            margin: 20px;
        }

        /* card with glassmorphism */
        .card {
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 48px;
            padding: 44px 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.6), inset 0 1px 1px rgba(255, 255, 255, 0.05);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.01);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 40px;
            padding: 6px 16px 6px 12px;
            margin-bottom: 28px;
            color: #10b981;
            font-weight: 500;
            font-size: 0.85rem;
            letter-spacing: 0.3px;
        }
        .badge i {
            font-size: 1rem;
            margin-right: 8px;
        }

        h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 600;
            font-size: 2.2rem;
            color: white;
            letter-spacing: -0.5px;
            line-height: 1.2;
            margin-bottom: 8px;
        }
        
        .subtitle {
            color: #a0b3d9;
            font-size: 0.95rem;
            margin-bottom: 32px;
            border-left: 3px solid #3b82f6;
            padding-left: 16px;
            background: linear-gradient(90deg, rgba(59,130,246,0.1) 0%, rgba(255,255,255,0) 80%);
            border-radius: 0 4px 4px 0;
        }

        /* message styles */
        .message {
            border-radius: 40px;
            padding: 14px 20px;
            margin-bottom: 24px;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .message.success {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.4);
            color: #a7f3d0;
        }
        
        .message.error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #ffb3b3;
        }
        
        .message i {
            font-size: 1.2rem;
        }

        .input-group {
            margin-bottom: 24px;
        }

        .input-label {
            display: block;
            color: #cfdfff;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 8px;
            letter-spacing: 0.2px;
        }

        .input-field {
            width: 100%;
            background: rgba(8, 16, 30, 0.6);
            border: 1.5px solid rgba(255, 255, 255, 0.06);
            border-radius: 24px;
            padding: 16px 22px;
            font-size: 1rem;
            color: white;
            font-family: 'Inter', sans-serif;
            outline: none;
            transition: all 0.25s ease;
        }

        .input-field:focus {
            border-color: #10b981;
            background: rgba(10, 20, 40, 0.7);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15);
        }

        .input-field::placeholder {
            color: #5d6f94;
            opacity: 0.7;
        }

        .icon-input {
            position: relative;
        }
        .icon-input i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #3f5575;
            font-size: 1.2rem;
            pointer-events: none;
            transition: color 0.2s;
        }
        .input-field:focus ~ i {
            color: #10b981;
        }

        .btn {
            width: 100%;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            border-radius: 40px;
            padding: 16px 20px;
            color: white;
            font-weight: 600;
            font-size: 1.1rem;
            letter-spacing: 0.5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.3s;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 12px 30px -8px rgba(16, 185, 129, 0.4);
        }

        .btn i {
            font-size: 1.2rem;
            transition: transform 0.3s;
        }

        .btn:hover {
            background: linear-gradient(135deg, #0da271 0%, #047857 100%);
            box-shadow: 0 16px 35px -6px #10b98180;
            transform: translateY(-2px);
        }

        .btn:hover i {
            transform: translateX(5px);
        }

        .btn-secondary {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1.5px solid rgba(255, 255, 255, 0.1);
            border-radius: 40px;
            padding: 16px 20px;
            color: white;
            font-weight: 500;
            font-size: 1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.3s;
            margin-top: 16px;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: #10b981;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #88a1d0;
            text-decoration: none;
            margin-bottom: 20px;
            font-size: 0.95rem;
            transition: 0.2s;
        }
        .back-link:hover {
            color: #10b981;
            gap: 12px;
        }

        .info-text {
            color: #5d6f94;
            font-size: 0.85rem;
            margin-top: 8px;
            margin-left: 16px;
        }
        .info-text i {
            margin-right: 6px;
        }

        .strength-meter {
            margin-top: 8px;
            height: 4px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            overflow: hidden;
        }
        
        .strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s, background-color 0.3s;
        }
        
        .strength-bar.weak { width: 33.33%; background: #ef4444; }
        .strength-bar.medium { width: 66.66%; background: #f59e0b; }
        .strength-bar.strong { width: 100%; background: #10b981; }

        .login-link {
            text-align: center;
            margin-top: 28px;
            color: #5b729b;
            font-size: 0.9rem;
        }
        .login-link a {
            color: #98b1e6;
            text-decoration: none;
            font-weight: 500;
            border-bottom: 1px dotted;
        }
        .login-link a:hover {
            color: #10b981;
        }

        @media (max-width: 500px) {
            .card {
                padding: 32px 24px;
                border-radius: 36px;
            }
            h1 {
                font-size: 1.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="shape shape-3"></div>

    <div class="container">
        <div class="card">
            <div class="badge">
                <i class="fas fa-briefcase"></i> 
                <span>PLACEMENT OFFICER · PASSWORD RESET</span>
            </div>

            <?php if($step == 'forgot'): ?>
                <!-- FORGOT PASSWORD FORM -->
                <h1>Reset password</h1>
                <div class="subtitle">
                    <i class="fas fa-envelope" style="margin-right: 8px;"></i> Enter your details to recover access
                </div>

                <?php if($message): ?>
                    <div class="message <?= $message_type ?>">
                        <i class="fas <?= $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                        <?php if(isset($demo_reset_link) && $message_type == 'success'): ?>
                            <br><small style="margin-top: 8px; display: block;">Demo link: <a href="<?= $demo_reset_link ?>" style="color: #10b981;">click here to reset</a></small>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="action" value="request_reset">
                    
                    <div class="input-group">
                        <label class="input-label" for="email_or_id">
                            <i class="fas fa-id-card" style="margin-right: 6px;"></i> Staff ID or University Email
                        </label>
                        <div class="icon-input">
                            <input type="text" class="input-field" id="email_or_id" name="email_or_id" 
                                   placeholder="staff_id or email@university.edu" required>
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="info-text">
                            <i class="fas fa-info-circle"></i> We'll send reset instructions to your registered email
                        </div>
                    </div>

                    <button type="submit" class="btn">
                        <span>Send Reset Instructions</span>
                        <i class="fas fa-paper-plane"></i>
                    </button>

                    <a href="index.php" class="btn-secondary">
                        <i class="fas fa-times"></i>
                        <span>Back to Login</span>
                    </a>
                </form>

            <?php elseif($step == 'reset'): ?>
                <!-- RESET PASSWORD FORM -->
                <a href="forgot.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Back to reset
                </a>
                
                <h1>Create new password</h1>
                <div class="subtitle">
                    <i class="fas fa-lock" style="margin-right: 8px;"></i> Choose a strong password
                </div>

                <?php if($message): ?>
                    <div class="message <?= $message_type ?>">
                        <i class="fas <?= $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" id="resetForm">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($reset_token) ?>">
                    
                    <div class="input-group">
                        <label class="input-label" for="new_password">
                            <i class="fas fa-lock" style="margin-right: 6px;"></i> New Password
                        </label>
                        <div class="icon-input">
                            <input type="password" class="input-field" id="new_password" name="new_password" 
                                   placeholder="············" required minlength="8"
                                   onkeyup="checkPasswordStrength(this.value)">
                            <i class="fas fa-key"></i>
                        </div>
                        <div class="strength-meter">
                            <div class="strength-bar" id="strengthBar"></div>
                        </div>
                        <div class="info-text">
                            <i class="fas fa-info-circle"></i> Minimum 8 characters with mixed case & numbers
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label" for="confirm_password">
                            <i class="fas fa-lock" style="margin-right: 6px;"></i> Confirm Password
                        </label>
                        <div class="icon-input">
                            <input type="password" class="input-field" id="confirm_password" name="confirm_password" 
                                   placeholder="············" required minlength="8">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn">
                        <span>Reset Password</span>
                        <i class="fas fa-sync-alt"></i>
                    </button>

                    <a href="index.php" class="btn-secondary">
                        <i class="fas fa-times"></i>
                        <span>Back to Login</span>
                    </a>
                </form>
            <?php endif; ?>

            <div class="login-link">
                <i class="fas fa-shield-alt" style="margin-right: 6px;"></i> 
                Remember your password? <a href="index.php">Login here</a>
            </div>
        </div>
    </div>