<?php

require_once '../config/db.php';

$token = $_GET['token'] ?? '';

if(!$token){
    die("Invalid link");
}

/* CHECK TOKEN */

$stmt = $conn->prepare("
SELECT officer_id,expires_at 
FROM officer_password_tokens 
WHERE token=?
");

$stmt->bind_param("s",$token);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows == 0){
    die("Invalid or expired link");
}

$row = $result->fetch_assoc();

if(strtotime($row['expires_at']) < time()){
    die("Link expired. Please contact admin.");
}

$officer_id = $row['officer_id'];

?>

<!DOCTYPE html>
<html>
<head>
<title>Set Password</title>

<style>

body{
font-family: Arial;
background:#f5f5f5;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.box{
background:white;
padding:40px;
border-radius:10px;
width:350px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

input{
width:100%;
padding:10px;
margin:10px 0;
border:1px solid #ccc;
border-radius:5px;
}

button{
width:100%;
padding:12px;
background:#1e3c72;
color:white;
border:none;
border-radius:5px;
cursor:pointer;
}

</style>

</head>

<body>

<div class="box">

<h2>Set Your Password</h2>

<form method="POST">

<input type="password" name="password" placeholder="New Password" required>

<input type="password" name="confirm" placeholder="Confirm Password" required>

<button type="submit">Set Password</button>

</form>

</div>

</body>

</html>


<?php

if($_SERVER['REQUEST_METHOD'] == "POST"){

$password = $_POST['password'];
$confirm = $_POST['confirm'];

if($password !== $confirm){
die("Passwords do not match");
}

$hash = password_hash($password,PASSWORD_DEFAULT);

/* UPDATE PASSWORD */

$stmt = $conn->prepare("
UPDATE placement_officers 
SET password=? 
WHERE id=?
");

$stmt->bind_param("si",$hash,$officer_id);
$stmt->execute();

/* DELETE TOKEN */

$stmt = $conn->prepare("
DELETE FROM officer_password_tokens 
WHERE officer_id=?
");

$stmt->bind_param("i",$officer_id);
$stmt->execute();

echo "<script>
alert('Password set successfully. Now login.');
window.location='../officer';
</script>";

}

?>