<?php
session_start();

if(!isset($_SESSION['user_role']) ||
   $_SESSION['user_role']!=="placement"){
    header("Location: /placement/login.php");
    exit;
}