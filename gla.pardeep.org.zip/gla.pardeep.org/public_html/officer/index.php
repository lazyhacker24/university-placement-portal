<?php
require_once '../config/session.php';
require_once '../config/db.php';

if($_POST){
    $id=$_POST['staff_id'];
    $pass=$_POST['password'];

    $stmt=$conn->prepare("SELECT * FROM placement_officers WHERE staff_id=?");
    $stmt->bind_param("s",$id);
    $stmt->execute();

    $user=$stmt->get_result()->fetch_assoc();

    if($user && password_verify($pass,$user['password'])){
        session_regenerate_id(true);
        $_SESSION['user_id']=$user['id'];
        $_SESSION['user_role']="placement";
        header("Location: dashboard.php");
        exit;
    }
    $error = "Invalid Staff ID or Password";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Officer Login · University Placement Cell</title>
    <!-- Font Awesome 6 (free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Inter + Space Grotesk for modern look -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #0b1120 0%, #19223c 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }

        /* abstract animated shapes (separate from admin old style) */
        .shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(90px);
            opacity: 0.4;
            z-index: 0;
        }
        .shape-1 {
            background: #3b82f6;
            width: 300px;
            height: 300px;
            top: -100px;
            left: -100px;
            animation: float 18s ease-in-out infinite;
        }
        .shape-2 {
            background: #8b5cf6;
            width: 400px;
            height: 400px;
            bottom: -150px;
            right: -100px;
            animation: float 22s ease-in-out infinite reverse;
        }
        .shape-3 {
            background: #10b981;
            width: 200px;
            height: 200px;
            bottom: 30%;
            left: 10%;
            animation: float 14s ease-in-out infinite 2s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            33% { transform: translateY(-30px) translateX(20px); }
            66% { transform: translateY(20px) translateX(-20px); }
        }

        .login-container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 460px;
            margin: 20px;
        }

        /* card with glassmorphism + subtle border */
        .login-card {
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 48px;
            padding: 44px 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.6), inset 0 1px 1px rgba(255, 255, 255, 0.05);
            transition: transform 0.3s ease;
        }

        .login-card:hover {
            transform: scale(1.01);
            box-shadow: 0 35px 70px -15px #00000080;
        }

        /* header with distinct placement identity */
        .badge {
            display: inline-flex;
            align-items: center;
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 40px;
            padding: 6px 16px 6px 12px;
            margin-bottom: 28px;
            color: #10b981;
            font-weight: 500;
            font-size: 0.85rem;
            letter-spacing: 0.3px;
            backdrop-filter: blur(4px);
        }
        .badge i {
            font-size: 1rem;
            margin-right: 8px;
        }

        h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 600;
            font-size: 2.2rem;
            color: white;
            letter-spacing: -0.5px;
            line-height: 1.2;
            margin-bottom: 8px;
        }
        .university-tag {
            color: #a0b3d9;
            font-size: 0.95rem;
            margin-bottom: 32px;
            border-left: 3px solid #3b82f6;
            padding-left: 16px;
            background: linear-gradient(90deg, rgba(59,130,246,0.1) 0%, rgba(255,255,255,0) 80%);
            border-radius: 0 4px 4px 0;
        }

        /* form elements */
        .input-group {
            margin-bottom: 24px;
        }

        .input-label {
            display: block;
            color: #cfdfff;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 8px;
            letter-spacing: 0.2px;
        }

        .input-field {
            width: 100%;
            background: rgba(8, 16, 30, 0.6);
            border: 1.5px solid rgba(255, 255, 255, 0.06);
            border-radius: 24px;
            padding: 16px 22px;
            font-size: 1rem;
            color: white;
            font-family: 'Inter', sans-serif;
            outline: none;
            transition: all 0.25s ease;
            backdrop-filter: blur(5px);
        }

        .input-field:focus {
            border-color: #10b981;
            background: rgba(10, 20, 40, 0.7);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15);
        }

        .input-field::placeholder {
            color: #5d6f94;
            font-weight: 400;
            opacity: 0.7;
        }

        /* staff id icon / subtle adornment (we can do inline with background) */
        .icon-input {
            position: relative;
        }
        .icon-input i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #3f5575;
            font-size: 1.2rem;
            pointer-events: none;
            transition: color 0.2s;
        }
        .input-field:focus ~ i {
            color: #10b981;
        }

        /* options row (remember & forgot) */
        .options-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 16px 0 28px;
            font-size: 0.9rem;
        }
        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #b7c7e9;
            cursor: pointer;
        }
        .remember input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #10b981;
            border-radius: 4px;
            cursor: pointer;
        }
        .forgot-link {
            color: #88a1d0;
            text-decoration: none;
            border-bottom: 1px dashed #3f5575;
            transition: 0.2s;
        }
        .forgot-link:hover {
            color: #10b981;
            border-bottom-color: #10b981;
        }

        /* primary login button */
        .login-btn {
            width: 100%;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            border-radius: 40px;
            padding: 16px 20px;
            color: white;
            font-weight: 600;
            font-size: 1.1rem;
            letter-spacing: 0.5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.3s;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 12px 30px -8px rgba(16, 185, 129, 0.4);
        }

        .login-btn i {
            font-size: 1.2rem;
            transition: transform 0.3s;
        }

        .login-btn:hover {
            background: linear-gradient(135deg, #0da271 0%, #047857 100%);
            box-shadow: 0 16px 35px -6px #10b98180;
            transform: translateY(-2px);
        }

        .login-btn:hover i {
            transform: translateX(5px);
        }

        /* error message */
        .error-message {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            border-radius: 40px;
            padding: 14px 20px;
            margin-bottom: 24px;
            color: #ffb3b3;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 12px;
            backdrop-filter: blur(6px);
        }
        .error-message i {
            font-size: 1.2rem;
            color: #ef4444;
        }

        /* footer / help text */
        .help-footer {
            text-align: center;
            margin-top: 28px;
            color: #5b729b;
            font-size: 0.9rem;
        }
        .help-footer a {
            color: #98b1e6;
            text-decoration: none;
            font-weight: 500;
            border-bottom: 1px dotted;
        }
        .help-footer a:hover {
            color: #10b981;
        }

        /* unique placement pattern: small dots grid (separate from old) */
        .pattern-dots {
            position: absolute;
            top: 20px;
            right: 30px;
            width: 120px;
            height: 120px;
            background-image: radial-gradient(rgba(16, 185, 129, 0.2) 2px, transparent 2px);
            background-size: 20px 20px;
            z-index: 5;
            pointer-events: none;
            opacity: 0.4;
        }

        /* responsive */
        @media (max-width: 500px) {
            .login-card {
                padding: 32px 24px;
                border-radius: 36px;
            }
            h1 {
                font-size: 1.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- abstract background shapes -->
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="shape shape-3"></div>
    
    <!-- placement pattern hint -->
    <div class="pattern-dots"></div>

    <div class="login-container">
        <div class="login-card">
            <!-- distinct placement badge -->
            <div class="badge">
                <i class="fas fa-briefcase"></i> 
                <span>PLACEMENT OFFICER · CAREER CELL</span>
            </div>

            <h1>Welcome back,</h1>
            <div class="university-tag">
                <i class="fas fa-university" style="margin-right: 8px;"></i> University Training & Placement
            </div>

            <?php if(isset($error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <!-- staff id field with subtle icon -->
                <div class="input-group">
                    <label class="input-label" for="staff_id">
                        <i class="far fa-id-card" style="margin-right: 6px;"></i> Staff ID
                    </label>
                    <div class="icon-input">
                        <input type="text" class="input-field" id="staff_id" name="staff_id" 
                               placeholder="GLA0000" autocomplete="off" required>
                        <i class="fas fa-user-tie"></i>
                    </div>
                </div>

                <!-- password field -->
                <div class="input-group">
                    <label class="input-label" for="password">
                        <i class="fas fa-lock" style="margin-right: 6px;"></i> Password
                    </label>
                    <div class="icon-input">
                        <input type="password" class="input-field" id="password" name="password" 
                               placeholder="············" required>
                        <i class="fas fa-key"></i>
                    </div>
                </div>

                <!-- extra row: remember + forgot (demo: no function, but adds richness) -->
                <div class="options-row">
                    <label class="remember">
                        <input type="checkbox" name="remember"> Keep me signed in
                    </label>
                    <a href="https://www.gla.pardeep.org/officer/forgot.php" class="forgot-link">Forgot passkey?</a>
                </div>

                <button type="submit" class="login-btn">
                    <span>Access Placement Dashboard</span>
                    <i class="fas fa-arrow-right"></i>
                </button>

                <!-- optional subtle hint: separate from admin -->
                <div class="help-footer">
                    <i class="fas fa-shield-alt" style="margin-right: 6px;"></i> 
                    Secure zone · Placement officers only <br>
                    <a href="#"><i class="fas fa-phone-alt"></i> Contact placement cell</a>  ·  
                    <a href="#"><i class="fas fa-question-circle"></i> Guide</a>
                </div>
            </form>
        </div>
    </div>

    <!-- tiny script to keep staff id field clean (optional) but not necessary -->
</body>
</html>