<?php
require_once '../config/db.php';
require_once '../config/mail.php';
require_once '../config/session.php';

$id=(int)$_GET['id'];

/* get student */
$stmt=$conn->prepare(
"SELECT full_name,email FROM students WHERE id=?"
);
$stmt->bind_param("i",$id);
$stmt->execute();
$res=$stmt->get_result();
$user=$res->fetch_assoc();

/* approve */
$stmt=$conn->prepare(
"UPDATE students SET status='approved' WHERE id=?"
);
$stmt->bind_param("i",$id);
$stmt->execute();

/* SEND APPROVAL MAIL */

$subject="GLA Placement Portal Account Approved";

$message="
<h3>Dear {$user['full_name']},</h3>

<p>Your student account has been <b style='color:green'>APPROVED</b>.</p>

<p>You can now login and apply for placements.</p>

<a href='https://gla.pardeep.org/student/login.php'>
Login Now
</a>

<hr>
GLA Placement Cell
";

sendMail($user['email'],$user['full_name'],$subject,$message);

header("Location: students.php");
exit;