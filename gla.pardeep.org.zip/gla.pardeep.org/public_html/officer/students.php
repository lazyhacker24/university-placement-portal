<?php
require_once '../config/db.php';
require_once '../config/session.php';

$result=$conn->query(
"SELECT id,full_name,roll_no,email,course
 FROM students
 WHERE status='pending'
 ORDER BY id DESC"
);
?>

<h2>Pending Student Approvals</h2>

<table border="1" cellpadding="10">
<tr>
<th>Name</th>
<th>Roll</th>
<th>Email</th>
<th>Course</th>
<th>Action</th>
</tr>

<?php while($row=$result->fetch_assoc()): ?>

<tr>
<td><?= $row['full_name'] ?></td>
<td><?= $row['roll_no'] ?></td>
<td><?= $row['email'] ?></td>
<td><?= $row['course'] ?></td>

<td>
<a href="approve.php?id=<?= $row['id'] ?>">✅ Approve</a>
|
<a href="reject.php?id=<?= $row['id'] ?>">❌ Reject</a>
</td>

</tr>

<?php endwhile; ?>

</table>