<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../auth.php';
require_once '../../config/db.php';

$officer_id = $_SESSION['user_id'];

// Update application status
if (isset($_POST['update_status'])) {
    $app_id = (int)$_POST['app_id'];
    $status = $_POST['status'];
    $update_query = "UPDATE applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("si", $status, $app_id);
    $stmt->execute();
    header("Location: list.php?msg=updated");
    exit();
}

// Fetch applications
$query = "SELECT a.*, 
                 s.full_name AS student_name, 
                 s.roll_no, 
                 s.course,
                 c.company_name, 
                 c.location
          FROM applications a
          JOIN students s ON a.student_id = s.id
          LEFT JOIN companies c ON a.company_id = c.company_id
          WHERE a.placement_officer_id = ?
          ORDER BY a.applied_date DESC";

          $stmt = $conn->prepare($query);
$stmt->bind_param("i", $officer_id);
$stmt->execute();
$applications = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applications | GLA University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Same base styles */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafd;
            color: #1e293b;
            display: flex;
        }
        
        /* ===== SIDEBAR - MODERN MINIMAL (SAME AS DASHBOARD) ===== */
.sidebar {
    width: 280px;
    background: white;
    border-right: 1px solid rgba(0,0,0,0.05);
    padding: 32px 20px;
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    z-index: 100;
    box-shadow: 4px 0 20px rgba(0,0,0,0.02);
}

.sidebar-logo {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 40px;
    padding-left: 8px;
}

.logo-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
    box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.3);
}

.logo-text h2 {
    font-size: 1.5rem;
    font-weight: 700;
    color: #0f172a;
    line-height: 1.2;
}

.logo-text span {
    font-size: 0.75rem;
    color: #64748b;
    font-weight: 500;
    letter-spacing: 0.3px;
}

.sidebar-menu {
    list-style: none;
}

.menu-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #94a3b8;
    font-weight: 600;
    padding: 20px 16px 8px;
}

.sidebar-menu li {
    margin-bottom: 4px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 12px 16px;
    color: #475569;
    text-decoration: none;
    border-radius: 14px;
    transition: all 0.2s ease;
    font-weight: 500;
    font-size: 0.95rem;
}

.sidebar-menu a i {
    width: 24px;
    font-size: 1.2rem;
    color: #94a3b8;
    transition: all 0.2s ease;
}

.sidebar-menu a:hover {
    background: #f1f5f9;
    color: #2563eb;
}

.sidebar-menu a:hover i {
    color: #2563eb;
}

.sidebar-menu a.active {
    background: #eef2ff;
    color: #2563eb;
    font-weight: 600;
}

.sidebar-menu a.active i {
    color: #2563eb;
}

/* ===== MAIN CONTENT SHIFT ===== */
.main-content {
    flex: 1;
    margin-left: 280px;
    padding: 32px;
    max-width: calc(100vw - 280px);
}

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: white;
            padding: 20px 28px;
            border-radius: 24px;
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
        }

        /* Kanban Board */
        .kanban-board {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }

        .kanban-column {
            background: #f8fafc;
            border-radius: 20px;
            padding: 20px;
        }

        .column-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .column-header h3 {
            font-size: 1rem;
            font-weight: 600;
            color: #0f172a;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .column-count {
            background: white;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            color: #2563eb;
        }

        .application-card {
            background: white;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
            cursor: move;
        }
        .application-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px -5px rgba(37, 99, 235, 0.1);
            border-color: #2563eb;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        .student-name {
            font-weight: 600;
            color: #0f172a;
        }
        .student-course {
            font-size: 0.7rem;
            color: #64748b;
        }

        .company-badge {
            background: #eef2ff;
            color: #2563eb;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .card-details {
            margin: 12px 0;
            font-size: 0.85rem;
        }
        .detail {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 6px;
            color: #475569;
        }
        .detail i {
            width: 16px;
            color: #94a3b8;
        }

        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #f1f5f9;
        }
        .app-date {
            font-size: 0.7rem;
            color: #94a3b8;
        }
        .status-select {
            padding: 6px 10px;
            border-radius: 30px;
            border: 1px solid #e2e8f0;
            font-size: 0.75rem;
            font-weight: 500;
            outline: none;
            cursor: pointer;
        }
        .status-pending { background: #fef3c7; color: #d97706; }
        .status-reviewed { background: #dbeafe; color: #2563eb; }
        .status-shortlisted { background: #d1fae5; color: #059669; }
        .status-rejected { background: #fee2e2; color: #ef4444; }

        /* Applications Table */
        .table-container {
            background: white;
            border-radius: 24px;
            padding: 24px;
            margin-top: 32px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 16px 12px;
            color: #64748b;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            border-bottom: 2px solid #f1f5f9;
        }

        td {
            padding: 16px 12px;
            border-bottom: 1px solid #f1f5f9;
        }

        .alert {
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            background: #d1fae5;
            color: #065f46;
            display: flex;
            align-items: center;
            gap: 12px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon"><i class="fas fa-briefcase"></i></div>
            <div class="logo-text"><h2>Placement Officer</h2><span>GLA University</span></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label"><span>MAIN</span></li>
            <li><a href="../dashboard.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
            <li><a href="../students/index.php"><i class="fas fa-users"></i> <span>Students</span></a></li>
            <li><a href="../companies/index.php"><i class="fas fa-building"></i> <span>Companies</span></a></li>
            <li class="menu-label"><span>MANAGEMENT</span></li>
            <li><a href="../drives/index.php"><i class="fas fa-calendar-alt"></i> <span>Drives</span></a></li>
            <li><a href="list.php" class="active"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="../placements/index.php"><i class="fas fa-handshake"></i> <span>Placements</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1>Applications</h1>
                <div class="breadcrumb">
                    <a href="../dashboard.php">Dashboard</a> <i class="fas fa-chevron-right" style="margin: 0 8px;"></i> Applications
                </div>
            </div>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div class="alert">
                <i class="fas fa-check-circle"></i> Application status updated successfully!
            </div>
        <?php endif; ?>

        <!-- Kanban Board -->
        <?php
        // Categorize applications by status
        $pending = [];
        $reviewed = [];
        $shortlisted = [];
        $rejected = [];
        
        mysqli_data_seek($applications, 0);
        while($app = $applications->fetch_assoc()) {
            switch($app['status']) {
                case 'pending': $pending[] = $app; break;
                case 'reviewed': $reviewed[] = $app; break;
                case 'shortlisted': $shortlisted[] = $app; break;
                case 'rejected': $rejected[] = $app; break;
                default: $pending[] = $app;
            }
        }
        mysqli_data_seek($applications, 0);
        ?>

        <div class="kanban-board">
            <!-- Pending Column -->
            <div class="kanban-column">
                <div class="column-header">
                    <h3><i class="fas fa-clock" style="color: #d97706; margin-right: 8px;"></i> Pending</h3>
                    <span class="column-count"><?= count($pending) ?></span>
                </div>
                <?php foreach($pending as $app): ?>
                    <div class="application-card" draggable="true" data-id="<?= $app['id'] ?>">
                        <div class="card-header">
                            <div>
                                <div class="student-name"><?= htmlspecialchars($app['student_name']) ?></div>
                                <div class="student-course"><?= htmlspecialchars($app['course']) ?></div>
                            </div>
                            <span class="company-badge"><?= htmlspecialchars($app['company_name']) ?></span>
                        </div>
                        <div class="card-details">
                            <div class="detail"><i class="fas fa-briefcase"></i> <?= htmlspecialchars($app['job_title'] ?? 'General Application') ?></div>
                            <div class="detail"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($app['location']) ?></div>
                        </div>
                        <div class="card-footer">
                            <span class="app-date"><i class="far fa-calendar-alt"></i> <?= date('d M', strtotime($app['applied_date'])) ?></span>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <select name="status" class="status-select status-pending" onchange="this.form.submit()">
                                    <option value="pending" selected>Pending</option>
                                    <option value="reviewed">Reviewed</option>
                                    <option value="shortlisted">Shortlist</option>
                                    <option value="rejected">Reject</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Reviewed Column -->
            <div class="kanban-column">
                <div class="column-header">
                    <h3><i class="fas fa-eye" style="color: #2563eb; margin-right: 8px;"></i> Reviewed</h3>
                    <span class="column-count"><?= count($reviewed) ?></span>
                </div>
                <?php foreach($reviewed as $app): ?>
                    <div class="application-card" draggable="true" data-id="<?= $app['id'] ?>">
                        <div class="card-header">
                            <div>
                                <div class="student-name"><?= htmlspecialchars($app['student_name']) ?></div>
                                <div class="student-course"><?= htmlspecialchars($app['course']) ?></div>
                            </div>
                            <span class="company-badge"><?= htmlspecialchars($app['company_name']) ?></span>
                        </div>
                        <div class="card-details">
                            <div class="detail"><i class="fas fa-briefcase"></i> <?= htmlspecialchars($app['job_title'] ?? 'General Application') ?></div>
                        </div>
                        <div class="card-footer">
                            <span class="app-date"><i class="far fa-calendar-alt"></i> <?= date('d M', strtotime($app['applied_date'])) ?></span>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <select name="status" class="status-select status-reviewed" onchange="this.form.submit()">
                                    <option value="pending">Pending</option>
                                    <option value="reviewed" selected>Reviewed</option>
                                    <option value="shortlisted">Shortlist</option>
                                    <option value="rejected">Reject</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Shortlisted Column -->
            <div class="kanban-column">
                <div class="column-header">
                    <h3><i class="fas fa-star" style="color: #059669; margin-right: 8px;"></i> Shortlisted</h3>
                    <span class="column-count"><?= count($shortlisted) ?></span>
                </div>
                <?php foreach($shortlisted as $app): ?>
                    <div class="application-card" draggable="true" data-id="<?= $app['id'] ?>">
                        <div class="card-header">
                            <div>
                                <div class="student-name"><?= htmlspecialchars($app['student_name']) ?></div>
                                <div class="student-course"><?= htmlspecialchars($app['course']) ?></div>
                            </div>
                            <span class="company-badge"><?= htmlspecialchars($app['company_name']) ?></span>
                        </div>
                        <div class="card-footer">
                            <span class="app-date"><i class="far fa-calendar-alt"></i> <?= date('d M', strtotime($app['applied_date'])) ?></span>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <select name="status" class="status-select status-shortlisted" onchange="this.form.submit()">
                                    <option value="pending">Pending</option>
                                    <option value="reviewed">Reviewed</option>
                                    <option value="shortlisted" selected>Shortlist</option>
                                    <option value="rejected">Reject</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Rejected Column -->
            <div class="kanban-column">
                <div class="column-header">
                    <h3><i class="fas fa-times-circle" style="color: #ef4444; margin-right: 8px;"></i> Rejected</h3>
                    <span class="column-count"><?= count($rejected) ?></span>
                </div>
                <?php foreach($rejected as $app): ?>
                    <div class="application-card" draggable="true" data-id="<?= $app['id'] ?>">
                        <div class="card-header">
                            <div>
                                <div class="student-name"><?= htmlspecialchars($app['student_name']) ?></div>
                                <div class="student-course"><?= htmlspecialchars($app['course']) ?></div>
                            </div>
                            <span class="company-badge"><?= htmlspecialchars($app['company_name']) ?></span>
                        </div>
                        <div class="card-footer">
                            <span class="app-date"><i class="far fa-calendar-alt"></i> <?= date('d M', strtotime($app['applied_date'])) ?></span>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <select name="status" class="status-select status-rejected" onchange="this.form.submit()">
                                    <option value="pending">Pending</option>
                                    <option value="reviewed">Reviewed</option>
                                    <option value="shortlisted">Shortlist</option>
                                    <option value="rejected" selected>Reject</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- All Applications Table -->
        <div class="table-container">
            <h3 style="margin-bottom: 20px;">All Applications</h3>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Company</th>
                        <th>Job Title</th>
                        <th>Applied Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($applications->num_rows > 0): ?>
                        <?php while($app = $applications->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?= htmlspecialchars($app['student_name']) ?></div>
                                    <div style="font-size: 0.8rem; color: #64748b;"><?= htmlspecialchars($app['roll_no']) ?></div>
                                </td>
                                <td><?= htmlspecialchars($app['company_name']) ?></td>
                                <td><?= htmlspecialchars($app['job_title'] ?? 'General Application') ?></td>
                                <td><?= date('d M Y', strtotime($app['applied_date'])) ?></td>
                                <td>
                                    <?php
                                    $statusClass = '';
                                    if($app['status'] == 'pending') $statusClass = 'status-pending';
                                    elseif($app['status'] == 'reviewed') $statusClass = 'status-reviewed';
                                    elseif($app['status'] == 'shortlisted') $statusClass = 'status-shortlisted';
                                    elseif($app['status'] == 'rejected') $statusClass = 'status-rejected';
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>"><?= ucfirst($app['status']) ?></span>
                                </td>
                                <td>
                                    <a href="view.php?id=<?= $app['id'] ?>" class="action-btn-icon"><i class="fas fa-eye"></i></a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align: center; padding: 40px;">No applications found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Simple drag and drop for kanban
        const cards = document.querySelectorAll('.application-card');
        const columns = document.querySelectorAll('.kanban-column');

        cards.forEach(card => {
            card.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', card.dataset.id);
            });
        });

        columns.forEach(column => {
            column.addEventListener('dragover', (e) => {
                e.preventDefault();
            });

            column.addEventListener('drop', (e) => {
                e.preventDefault();
                const appId = e.dataTransfer.getData('text/plain');
                const newStatus = column.querySelector('h3').textContent.trim().toLowerCase();
                
                // Update via AJAX
                fetch('update_status.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: `app_id=${appId}&status=${newStatus}`
                }).then(() => location.reload());
            });
        });
    </script>
</body>
</html>