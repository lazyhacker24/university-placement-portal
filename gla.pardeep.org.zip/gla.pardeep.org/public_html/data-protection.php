<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Protection Policy | SPMS 2.0</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f5f7fa;
            line-height: 1.6;
            color: #2c3e50;
            padding: 30px 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 50px;
        }

        h1 {
            font-size: 32px;
            color: #1e3c72;
            margin-bottom: 8px;
            font-weight: 600;
            border-bottom: 3px solid #1e3c72;
            padding-bottom: 15px;
        }

        .subtitle {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        section {
            margin-bottom: 35px;
        }

        h2 {
            font-size: 22px;
            color: #1e3c72;
            margin-bottom: 15px;
            font-weight: 600;
            background: #f8fafc;
            padding: 10px 15px;
            border-radius: 8px;
            border-left: 4px solid #1e3c72;
        }

        h3 {
            font-size: 18px;
            color: #334155;
            margin: 20px 0 10px;
            font-weight: 600;
        }

        p {
            color: #475569;
            margin-bottom: 15px;
            font-size: 15px;
        }

        ul {
            list-style: none;
            margin: 15px 0;
        }

        ul li {
            color: #475569;
            padding: 6px 0 6px 25px;
            position: relative;
            font-size: 15px;
        }

        ul li::before {
            content: "•";
            color: #1e3c72;
            font-weight: bold;
            position: absolute;
            left: 8px;
        }

        strong {
            color: #1e3c72;
            font-weight: 600;
        }

        .contact-info {
            background: #f8fafc;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

        .contact-info p {
            margin-bottom: 5px;
        }

        hr {
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 30px 0;
        }

        .footer-note {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 28px;
            }
            
            h2 {
                font-size: 20px;
            }
        }

        @media print {
            body {
                background: white;
                padding: 0;
            }
            .container {
                box-shadow: none;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Data Protection Policy</h1>
        <div class="subtitle">Student Placement Management System (SPMS v2.0)</div>

        <section>
            <h2>1. Introduction</h2>
            <p>
                The Student Placement Management System (SPMS v2.0) is an academic project
                developed by <strong>Pardeep Kumar</strong> Student at GLA University.
                This portal demonstrates how a student placement system works.
                This website is created only for educational and demonstration purposes
                and is not an official system of GLA University.
            </p>
        </section>

        <section>
            <h2>2. Purpose of Data Collection</h2>
            <p>The system collects limited information to demonstrate features such as:</p>
            <ul>
                <li>Student registration</li>
                <li>Resume building</li>
                <li>Company job postings</li>
                <li>Application tracking</li>
                <li>Placement statistics</li>
            </ul>
        </section>

        <section>
            <h2>3. Types of Information Collected</h2>
            
            <h3>Student Information</h3>
            <ul>
                <li>Name</li>
                <li>Email address</li>
                <li>Enrollment number</li>
                <li>Course and branch</li>
                <li>Academic information</li>
                <li>Resume data</li>
            </ul>

            <h3>Company Information</h3>
            <ul>
                <li>Company name</li>
                <li>HR contact details</li>
                <li>Job descriptions</li>
                <li>Eligibility criteria</li>
            </ul>
        </section>

        <section>
            <h2>4. Data Usage</h2>
            <p>
                Information collected is used only to simulate the placement process and
                demonstrate system functionality such as job applications,
                recruitment workflow, and placement statistics.
            </p>
        </section>

        <section>
            <h2>5. Data Security</h2>
            <ul>
                <li>Secure login sessions</li>
                <li>Password encryption</li>
                <li>Role-based access (Admin / Student / Recruiter)</li>
                <li>Controlled database access</li>
            </ul>
        </section>

        <section>
            <h2>6. Data Sharing</h2>
            <p>
                This academic project does not sell, distribute, or share any user data.
                All information is used only within the system for demonstration purposes.
            </p>
        </section>

        <section>
            <h2>7. User Responsibility</h2>
            <ul>
                <li>Do not upload sensitive personal information</li>
                <li>Use demo or sample data</li>
                <li>Keep login credentials secure</li>
            </ul>
        </section>

        <section>
            <h2>8. Data Retention</h2>
            <p>
                Data stored in the system may be modified or removed during development
                and testing of the academic project.
            </p>
        </section>

        <section>
            <h2>9. Disclaimer</h2>
            <p>
                This Student Placement Portal is a student-developed academic project and
                is not affiliated with the official GLA University Placement Cell.
            </p>
        </section>

        <section>
            <h2>10. Contact</h2>
            <div class="contact-info">
                <p><strong>Pardeep Kumar</strong></p>
                <p>GLA University, Mathura</p>
                <p>Email: webmaster@pardeep.org</p>
            </div>
        </section>

        <div class="footer-note">
            © 2025 Pardeep Kumar | Student Placement Management System v2.0 | Academic Project - GLA University
        </div>
    </div>
</body>
</html>