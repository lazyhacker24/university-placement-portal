<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Privacy Policy | SPMS 2.0</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f5f7fa;
            line-height: 1.6;
            color: #2c3e50;
            padding: 30px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 50px;
        }

        h1 {
            font-size: 32px;
            color: #1e3c72;
            margin-bottom: 8px;
            font-weight: 600;
            border-bottom: 3px solid #1e3c72;
            padding-bottom: 15px;
        }

        .subtitle {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        section {
            margin-bottom: 35px;
        }

        h2 {
            font-size: 22px;
            color: #1e3c72;
            margin-bottom: 15px;
            font-weight: 600;
            background: #f8fafc;
            padding: 10px 15px;
            border-radius: 8px;
            border-left: 4px solid #1e3c72;
        }

        p {
            color: #475569;
            margin-bottom: 15px;
            font-size: 15px;
        }

        ul {
            list-style: none;
            margin: 15px 0;
        }

        ul li {
            color: #475569;
            padding: 6px 0 6px 25px;
            position: relative;
            font-size: 15px;
        }

        ul li::before {
            content: "•";
            color: #1e3c72;
            font-weight: bold;
            position: absolute;
            left: 8px;
        }

        strong {
            color: #1e3c72;
            font-weight: 600;
        }

        a {
            color: #1e3c72;
            text-decoration: none;
            word-break: break-all;
            background: #f0f4f8;
            padding: 8px 12px;
            border-radius: 6px;
            display: inline-block;
            margin-top: 5px;
            font-size: 14px;
            border: 1px solid #d1d9e6;
        }

        a:hover {
            background: #e1e8f0;
            border-color: #1e3c72;
        }

        hr {
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 30px 0;
        }

        .footer-note {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 28px;
            }
            
            h2 {
                font-size: 20px;
            }
            
            a {
                display: block;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Privacy Policy</h1>
        <div class="subtitle">Student Placement Management System (SPMS v2.0)</div>

        <section>
            <h2>1. Overview</h2>
            <p>
                This Privacy Policy explains how information is collected and used within the
                Student Placement Management System (SPMS v2.0). This portal is an academic
                project created for educational purposes by <strong>Pardeep Kumar</strong>.
            </p>
        </section>

        <section>
            <h2>2. Information We Collect</h2>
            <ul>
                <li>Student profile details</li>
                <li>Login credentials</li>
                <li>Academic information</li>
                <li>Job application records</li>
            </ul>
        </section>

        <section>
            <h2>3. How Information Is Used</h2>
            <p>
                The collected information is used to simulate the placement process,
                manage applications, and demonstrate placement portal functionality.
            </p>
        </section>

        <section>
            <h2>4. Data Protection</h2>
            <p>
                For detailed information about how user data is protected in this project,
                please visit our Data Protection page.
            </p>

            <p>
                <strong>Data Protection Policy:</strong><br>
                <a href="https://gla.pardeep.org/data-protection.php">
                    View Data Protection Policy 
                </a>
            </p>
        </section>

        <section>
            <h2>5. Disclaimer</h2>
            <p>
                This portal is a student academic project and is not an official platform
                of GLA University.
            </p>
        </section>

        <div class="footer-note">
            © 2025 Pardeep Kumar | Student Placement Management System v2.0 | Academic Project - GLA University
        </div>
    </div>
</body>
</html>