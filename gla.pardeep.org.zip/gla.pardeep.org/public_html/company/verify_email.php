<?php
require_once '../config/db.php';

$verification_status = 'error';
$message = '';
$verification_time = date("F j, Y, g:i a");

if(isset($_GET['token'])){
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT company_id FROM company_email_verification WHERE token=? AND expires_at > NOW()");
    $stmt->bind_param("s",$token);
    $stmt->execute();
    $result = $stmt->get_result();

    if($row = $result->fetch_assoc()){
        $company_id = $row['company_id'];

        $stmt2 = $conn->prepare("UPDATE companies SET status='pending_verification' WHERE id=?");
        $stmt2->bind_param("i",$company_id);
        $stmt2->execute();

        $stmt3 = $conn->prepare("DELETE FROM company_email_verification WHERE company_id=?");
        $stmt3->bind_param("i",$company_id);
        $stmt3->execute();

        $verification_status = 'success';
        $message = "Email verified successfully. Our team will review your company within 24–48 hours.";
    }
    else{
        $verification_status = 'expired';
        $message = "Verification link is invalid or expired.";
    }
}
else{
    $verification_status = 'invalid';
    $message = "Invalid verification link.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Company Email Verification</title>
<style>
body{
    margin:0;
    font-family:Segoe UI,Arial;
    background:linear-gradient(135deg,#667eea,#764ba2);
    display:flex;
    align-items:center;
    justify-content:center;
    height:100vh;
}
.card{
    background:#fff;
    width:420px;
    border-radius:20px;
    padding:40px;
    text-align:center;
    box-shadow:0 20px 60px rgba(0,0,0,.2);
}
.icon{
    font-size:60px;
    margin-bottom:20px;
}
.success{color:#10b981;}
.error{color:#ef4444;}
.warning{color:#f59e0b;}
h2{margin-bottom:15px;}
p{color:#555;line-height:1.6}
.time{margin:15px 0;font-size:14px;color:#888}
.btn{
    display:inline-block;
    margin-top:25px;
    padding:12px 30px;
    border-radius:30px;
    text-decoration:none;
    font-weight:bold;
    background:#667eea;
    color:#fff;
}
.btn:hover{opacity:.9}
</style>
</head>
<body>

<div class="card">

<?php if($verification_status==='success'): ?>
    <div class="icon success">✔</div>
    <h2>Email Verified Successfully</h2>
    <p><?= htmlspecialchars($message) ?></p>
    <div class="time">Verified at: <?= $verification_time ?></div>
    <a href="company_login.php" class="btn">Company Login</a>

<?php elseif($verification_status==='expired'): ?>
    <div class="icon warning">⚠</div>
    <h2>Verification Link Expired</h2>
    <p><?= htmlspecialchars($message) ?></p>
    <a href="resend_verification.php" class="btn">Resend Verification</a>

<?php else: ?>
    <div class="icon error">✖</div>
    <h2>Invalid Verification Link</h2>
    <p><?= htmlspecialchars($message) ?></p>
    <a href="register.php" class="btn">Register Again</a>
<?php endif; ?>

</div>

</body>
</html>