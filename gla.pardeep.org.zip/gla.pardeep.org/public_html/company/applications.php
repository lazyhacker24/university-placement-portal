<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Applications</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        /* glass background shapes */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .applications-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        /* header */
        .applications-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ffb347, #ff9f1c);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        /* title */
        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #1e3c72;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* filter bar */
        .filter-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .filter-btn {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
            padding: 0.8rem 1.8rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            border: 1px solid white;
            cursor: pointer;
            transition: 0.2s;
        }
        .filter-btn.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        }
        .filter-btn:hover {
            background: white;
            border-color: #1e3c72;
        }
        .search-box {
            flex: 1;
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.8);
            border-radius: 60px;
            padding: 0.3rem 0.3rem 0.3rem 1.8rem;
            border: 1px solid white;
        }
        .search-box input {
            flex: 1;
            border: none;
            background: transparent;
            padding: 0.8rem 1rem;
            font-weight: 500;
            outline: none;
        }
        .search-box button {
            background: #1e3c72;
            border: none;
            color: white;
            padding: 0.8rem 2rem;
            border-radius: 60px;
            font-weight: 600;
            cursor: pointer;
        }

        /* stats row */
        .stats-row {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border-radius: 2rem;
            padding: 1.5rem 2rem;
            flex: 1;
            min-width: 150px;
            border: 1px solid rgba(255,255,255,0.9);
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: #0b2b4e;
        }
        .stat-label {
            font-weight: 600;
            color: #2c577c;
        }

        /* applications table */
        .applications-table {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 1.5rem;
            border: 1px solid rgba(255,255,255,0.9);
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: left;
            padding: 1.2rem 1rem;
            font-weight: 700;
            color: #1a3b5c;
            border-bottom: 2px solid rgba(30,60,114,0.2);
        }
        td {
            padding: 1rem;
            border-bottom: 1px solid rgba(30,60,114,0.1);
        }
        tr:last-child td {
            border-bottom: none;
        }
        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .student-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
            font-weight: 700;
        }
        .status-badge {
            padding: 0.4rem 1.2rem;
            border-radius: 60px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
        }
        .status-new { background: #ffb34720; color: #b45f06; }
        .status-reviewed { background: #1e3c7220; color: #1e3c72; }
        .status-shortlisted { background: #28a74520; color: #1e8f5e; }
        .status-rejected { background: #dc354520; color: #b34141; }
        .action-btn {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 0.5rem 1.2rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            font-size: 0.9rem;
        }
        .action-btn:hover {
            background: white;
            border-color: #1e3c72;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        .page-link {
            background: rgba(255,255,255,0.6);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #1e3c72;
            text-decoration: none;
            border: 1px solid white;
        }
        .page-link.active {
            background: #1e3c72;
            color: white;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="applications-wrapper">
        <!-- header -->
        <div class="applications-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-file-signature"></i> applications.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-users"></i>
            </div>
            <div>
                <h1>Applications</h1>
                <p>Manage student applications for your drives</p>
            </div>
        </div>

        <!-- stats -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-number">128</div>
                <div class="stat-label">Total applications</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">42</div>
                <div class="stat-label">New</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">56</div>
                <div class="stat-label">Reviewed</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">24</div>
                <div class="stat-label">Shortlisted</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">6</div>
                <div class="stat-label">Rejected</div>
            </div>
        </div>

        <!-- filters -->
        <div class="filter-bar">
            <button class="filter-btn active">All drives</button>
            <button class="filter-btn">SDE 2026</button>
            <button class="filter-btn">Analyst 2026</button>
            <button class="filter-btn">Consultant</button>
            <div class="search-box">
                <i class="fas fa-search" style="color: #1e3c72; opacity: 0.6;"></i>
                <input type="text" placeholder="Search by name, roll number...">
                <button><i class="fas fa-filter"></i> Filter</button>
            </div>
        </div>

        <!-- applications table -->
        <div class="applications-table">
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Roll No.</th>
                        <th>Drive</th>
                        <th>Applied for</th>
                        <th>Applied on</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">RS</div>
                                <div>
                                    <div style="font-weight: 700;">Rahul Sharma</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 8.9 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345001</td>
                        <td>Infosys SDE</td>
                        <td>SDE Intern</td>
                        <td>12 Nov 2026</td>
                        <td><span class="status-badge status-new">New</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">PM</div>
                                <div>
                                    <div style="font-weight: 700;">Priya Mehta</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">ECE · 8.7 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345042</td>
                        <td>Deloitte Analyst</td>
                        <td>Business Analyst</td>
                        <td>13 Nov 2026</td>
                        <td><span class="status-badge status-reviewed">Reviewed</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">AV</div>
                                <div>
                                    <div style="font-weight: 700;">Ankit Verma</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">IT · 9.2 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345117</td>
                        <td>Amazon SDE</td>
                        <td>SDE I</td>
                        <td>10 Nov 2026</td>
                        <td><span class="status-badge status-shortlisted">Shortlisted</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">SK</div>
                                <div>
                                    <div style="font-weight: 700;">Sneha Kapoor</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 8.5 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345088</td>
                        <td>Microsoft</td>
                        <td>Software Engineer</td>
                        <td>14 Nov 2026</td>
                        <td><span class="status-badge status-new">New</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">RJ</div>
                                <div>
                                    <div style="font-weight: 700;">Rohan Joshi</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">ME · 8.1 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345223</td>
                        <td>Texas Instruments</td>
                        <td>Core Engineer</td>
                        <td>09 Nov 2026</td>
                        <td><span class="status-badge status-rejected">Rejected</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">NT</div>
                                <div>
                                    <div style="font-weight: 700;">Neha Tiwari</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 9.4 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345056</td>
                        <td>Google</td>
                        <td>SDE</td>
                        <td>15 Nov 2026</td>
                        <td><span class="status-badge status-shortlisted">Shortlisted</span></td>
                        <td><button class="action-btn"><i class="fas fa-eye"></i> View</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- pagination -->
        <div class="pagination">
            <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
            <a href="#" class="page-link active">1</a>
            <a href="#" class="page-link">2</a>
            <a href="#" class="page-link">3</a>
            <a href="#" class="page-link">4</a>
            <a href="#" class="page-link">5</a>
            <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · application management</span>
        </div>
    </div>

    <!-- floating badge -->
    <div class="floating-company">
        <i class="fas fa-building"></i> applications · review
    </div>
</body>
</html>