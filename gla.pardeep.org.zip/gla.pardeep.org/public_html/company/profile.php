<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Company Profile</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        /* glass background shapes */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .profile-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        /* header with back link */
        .profile-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ffb347, #ff9f1c);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
            box-shadow: 0 6px 14px rgba(255,160,50,0.2);
        }
        .page-badge i {
            margin-right: 6px;
        }

        /* title section */
        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 3rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240, 0 0 0 1px rgba(255,255,255,0.8) inset;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #1e3c72;
            filter: drop-shadow(0 6px 8px #1e3c7220);
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .title-section p {
            color: #365f8a;
            font-weight: 500;
            font-size: 1.1rem;
            margin-top: 0.2rem;
        }

        /* profile grid */
        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 2rem;
            margin-bottom: 3rem;
        }

        /* glass card */
        .glass-card {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 2.5rem;
            padding: 2rem;
            border: 1px solid rgba(255,255,255,0.9);
            box-shadow: 0 25px 40px -24px #1e3c72, inset 0 1px 2px white;
        }

        /* company logo section */
        .logo-section {
            text-align: center;
        }
        .company-logo {
            width: 180px;
            height: 180px;
            background: white;
            border-radius: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            box-shadow: 0 20px 30px -12px #1e3c72;
            border: 3px solid rgba(255,255,255,0.9);
        }
        .company-logo i {
            font-size: 5rem;
            color: #1e3c72;
        }
        .upload-btn {
            background: rgba(255,255,255,0.8);
            padding: 0.8rem 1.8rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            border: 1px solid white;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        .upload-btn:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* info sections */
        .info-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 2rem;
            border-bottom: 1px dashed rgba(30,60,114,0.2);
            padding-bottom: 1rem;
        }
        .info-header i {
            font-size: 2rem;
            background: white;
            padding: 12px;
            border-radius: 20px;
            color: #ff9f1c;
        }
        .info-header h3 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0b2b4e;
        }

        .info-row {
            display: flex;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid rgba(30,60,114,0.1);
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            width: 140px;
            font-weight: 600;
            color: #1a3b5c;
        }
        .info-value {
            flex: 1;
            color: #2c577c;
        }
        .info-action {
            color: #1e3c72;
            opacity: 0.7;
            cursor: pointer;
            transition: 0.2s;
        }
        .info-action:hover {
            opacity: 1;
            transform: scale(1.1);
        }

        /* form styles for edit mode */
        .edit-input {
            background: rgba(255,255,255,0.9);
            border: 1px solid #cdddec;
            border-radius: 60px;
            padding: 0.8rem 1.5rem;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 500;
            width: 100%;
            outline: none;
        }
        .edit-input:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 3px rgba(30,60,114,0.1);
        }

        .btn-primary {
            background: #1e3c72;
            border: none;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            color: white;
            font-weight: 700;
            font-size: 1.1rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #1e3c72;
            transition: 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .btn-primary:hover {
            background: #143768;
            transform: translateY(-3px);
            box-shadow: 0 28px 38px -16px #0f2b50;
        }

        .btn-secondary {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-secondary:hover {
            background: white;
            border-color: #1e3c72;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2rem;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
            border: 1px solid rgba(255,255,255,0.8);
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
            box-shadow: 0 10px 20px -12px #1e3c72;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="profile-wrapper">
        <!-- header with back link -->
        <div class="profile-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-id-card"></i> profile.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-building"></i>
            </div>
            <div>
                <h1>Company profile</h1>
                <p>Manage your company information and branding</p>
            </div>
        </div>

        <!-- profile grid -->
        <div class="profile-grid">
            <!-- left column - logo & basic info -->
            <div class="glass-card logo-section">
                <div class="company-logo">
                    <i class="fas fa-city"></i>
                </div>
                <button class="upload-btn"><i class="fas fa-cloud-upload-alt"></i> Upload logo</button>
                <p style="margin-top: 1rem; color: #5f7d9c; font-size: 0.9rem;">PNG, JPG up to 2MB</p>
                
                <div style="margin-top: 2rem; text-align: left;">
                    <div class="info-row">
                        <span class="info-label">Member since</span>
                        <span class="info-value">March 2025</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Last updated</span>
                        <span class="info-value">Today, 10:23 AM</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Profile strength</span>
                        <span class="info-value">
                            <div style="background: white; border-radius: 60px; height: 8px; width: 100%; margin-top: 5px;">
                                <div style="width: 85%; height: 8px; background: linear-gradient(to right, #1e3c72, #ff9f1c); border-radius: 60px;"></div>
                            </div>
                        </span>
                    </div>
                </div>
            </div>

            <!-- right column - company details (editable form) -->
            <div class="glass-card">
                <div class="info-header">
                    <i class="fas fa-info-circle"></i>
                    <h3>Company details</h3>
                </div>

                <form id="profileForm" action="update_profile.php" method="POST">
                    <div class="info-row">
                        <span class="info-label">Company name</span>
                        <input type="text" class="edit-input" name="company_name" value="Nexa Corp.">
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email address</span>
                        <input type="email" class="edit-input" name="email" value="hr@nexa.com">
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone number</span>
                        <input type="tel" class="edit-input" name="phone" value="+91 98765 43210">
                    </div>
                    <div class="info-row">
                        <span class="info-label">Website</span>
                        <input type="url" class="edit-input" name="website" value="https://www.nexa.in">
                    </div>
                    <div class="info-row">
                        <span class="info-label">Industry</span>
                        <select class="edit-input" name="industry">
                            <option>Information Technology</option>
                            <option selected>IT Services</option>
                            <option>Consulting</option>
                            <option>Manufacturing</option>
                            <option>Finance</option>
                        </select>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Employee count</span>
                        <select class="edit-input" name="employee_count">
                            <option>1-50</option>
                            <option>51-200</option>
                            <option selected>201-500</option>
                            <option>501-1000</option>
                            <option>1000+</option>
                        </select>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Founded year</span>
                        <input type="number" class="edit-input" name="founded" value="2015">
                    </div>
                    <div class="info-row">
                        <span class="info-label">Address</span>
                        <textarea class="edit-input" name="address" rows="2" style="border-radius: 30px;">Noida SEZ, Sector 62, Noida, Uttar Pradesh 201309</textarea>
                    </div>
                    <div class="info-row">
                        <span class="info-label">About company</span>
                        <textarea class="edit-input" name="about" rows="3" style="border-radius: 30px;">Leading IT services company providing innovative solutions to global clients. Specialized in cloud computing, AI, and digital transformation.</textarea>
                    </div>

                    <div class="action-buttons">
                        <button type="button" class="btn-secondary" onclick="window.location.href='dashboard.php'"><i class="fas fa-times"></i> Cancel</button>
                        <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Save changes</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- social media links section -->
        <div class="glass-card" style="margin-top: 2rem;">
            <div class="info-header">
                <i class="fas fa-share-alt"></i>
                <h3>Social media & links</h3>
            </div>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;">
                <div>
                    <label style="font-weight: 600; color: #1a3b5c; display: block; margin-bottom: 0.5rem;"><i class="fab fa-linkedin" style="color: #0077b5;"></i> LinkedIn</label>
                    <input type="url" class="edit-input" value="https://linkedin.com/company/nexa" placeholder="LinkedIn URL">
                </div>
                <div>
                    <label style="font-weight: 600; color: #1a3b5c; display: block; margin-bottom: 0.5rem;"><i class="fab fa-twitter" style="color: #1da1f2;"></i> Twitter</label>
                    <input type="url" class="edit-input" value="https://twitter.com/nexacorp" placeholder="Twitter URL">
                </div>
                <div>
                    <label style="font-weight: 600; color: #1a3b5c; display: block; margin-bottom: 0.5rem;"><i class="fab fa-facebook" style="color: #4267B2;"></i> Facebook</label>
                    <input type="url" class="edit-input" value="https://facebook.com/nexacorp" placeholder="Facebook URL">
                </div>
                <div>
                    <label style="font-weight: 600; color: #1a3b5c; display: block; margin-bottom: 0.5rem;"><i class="fab fa-youtube" style="color: #FF0000;"></i> YouTube</label>
                    <input type="url" class="edit-input" value="https://youtube.com/@nexacorp" placeholder="YouTube URL">
                </div>
            </div>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · company profile</span>
        </div>
    </div>

    <!-- floating company badge -->
    <div class="floating-company">
        <i class="fas fa-building"></i> profile · company view
    </div>
</body>
</html>