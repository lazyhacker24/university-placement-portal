<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Selected Candidates</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        /* glass background shapes */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .selected-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        /* header */
        .selected-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #28a745, #34ce57);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: white;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #28a745;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* stats row */
        .stats-row {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border-radius: 2rem;
            padding: 1.5rem 2rem;
            flex: 1;
            min-width: 150px;
            border: 1px solid rgba(255,255,255,0.9);
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: #28a745;
        }
        .stat-label {
            font-weight: 600;
            color: #2c577c;
        }

        /* action bar */
        .action-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .btn-primary {
            background: #1e3c72;
            border: none;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            color: white;
            font-weight: 700;
            font-size: 1rem;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #1e3c72;
            transition: 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .btn-primary:hover {
            background: #143768;
            transform: translateY(-3px);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        .btn-secondary:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* selected table */
        .selected-table {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 1.5rem;
            border: 1px solid rgba(255,255,255,0.9);
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: left;
            padding: 1.2rem 1rem;
            font-weight: 700;
            color: #1a3b5c;
            border-bottom: 2px solid rgba(30,60,114,0.2);
        }
        td {
            padding: 1rem;
            border-bottom: 1px solid rgba(30,60,114,0.1);
        }
        tr:last-child td {
            border-bottom: none;
        }
        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .student-avatar {
            width: 40px;
            height: 40px;
            background: #28a74520;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #28a745;
            font-weight: 700;
        }
        .status-badge {
            padding: 0.4rem 1.2rem;
            border-radius: 60px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
        }
        .status-offer-sent { background: #1e3c7220; color: #1e3c72; }
        .status-accepted { background: #28a74520; color: #28a745; }
        .status-onboarding { background: #ffb34720; color: #b45f06; }
        
        .action-btn {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 0.5rem 1.2rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            font-size: 0.9rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .action-btn:hover {
            background: white;
            border-color: #1e3c72;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="selected-wrapper">
        <!-- header -->
        <div class="selected-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-user-graduate"></i> selected.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-trophy"></i>
            </div>
            <div>
                <h1>Selected candidates</h1>
                <p>Manage offer letters and onboarding</p>
            </div>
        </div>

        <!-- stats -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-number">8</div>
                <div class="stat-label">Total selected</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">5</div>
                <div class="stat-label">Offer sent</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">3</div>
                <div class="stat-label">Accepted</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">0</div>
                <div class="stat-label">Onboarding</div>
            </div>
        </div>

        <!-- action bar -->
        <div class="action-bar">
            <div>
                <select style="background: rgba(255,255,255,0.8); border: 1px solid white; padding: 1rem 2rem; border-radius: 60px; font-weight: 600; color: #1e3c72; outline: none;">
                    <option>All drives</option>
                    <option>Infosys SDE</option>
                    <option>Deloitte Analyst</option>
                    <option>Amazon SDE</option>
                </select>
            </div>
            <div style="display: flex; gap: 1rem;">
                <a href="#" class="btn-secondary"><i class="fas fa-file-pdf"></i> Export all</a>
                <a href="#" class="btn-primary"><i class="fas fa-plus"></i> Generate offer letter</a>
            </div>
        </div>

        <!-- selected table -->
        <div class="selected-table">
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Roll No.</th>
                        <th>Drive</th>
                        <th>Position</th>
                        <th>Package (LPA)</th>
                        <th>Status</th>
                        <th>Offer letter</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">SG</div>
                                <div>
                                    <div style="font-weight: 700;">Shreya Gupta</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 9.1 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345123</td>
                        <td>Amazon SDE</td>
                        <td>SDE I</td>
                        <td>32.5 LPA</td>
                        <td><span class="status-badge status-accepted">Accepted</span></td>
                        <td><a href="#" style="color: #1e3c72;"><i class="fas fa-download"></i> PDF</a></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="#" class="action-btn"><i class="fas fa-eye"></i></a>
                                <a href="#" class="action-btn"><i class="fas fa-envelope"></i></a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">YJ</div>
                                <div>
                                    <div style="font-weight: 700;">Yash Jain</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">IT · 8.8 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345099</td>
                        <td>Deloitte</td>
                        <td>Analyst</td>
                        <td>18.2 LPA</td>
                        <td><span class="status-badge status-accepted">Accepted</span></td>
                        <td><a href="#" style="color: #1e3c72;"><i class="fas fa-download"></i> PDF</a></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="#" class="action-btn"><i class="fas fa-eye"></i></a>
                                <a href="#" class="action-btn"><i class="fas fa-envelope"></i></a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">DT</div>
                                <div>
                                    <div style="font-weight: 700;">Divya Tripathi</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">ECE · 8.5 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345177</td>
                        <td>Infosys</td>
                        <td>Systems Engineer</td>
                        <td>9.5 LPA</td>
                        <td><span class="status-badge status-offer-sent">Offer sent</span></td>
                        <td><a href="#" style="color: #1e3c72;"><i class="fas fa-download"></i> PDF</a></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="#" class="action-btn"><i class="fas fa-eye"></i></a>
                                <a href="#" class="action-btn"><i class="fas fa-envelope"></i></a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">AK</div>
                                <div>
                                    <div style="font-weight: 700;">Arjun Kumar</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 9.3 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345012</td>
                        <td>Microsoft</td>
                        <td>SDE</td>
                        <td>28.0 LPA</td>
                        <td><span class="status-badge status-offer-sent">Offer sent</span></td>
                        <td><a href="#" style="color: #1e3c72;"><i class="fas fa-download"></i> PDF</a></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="#" class="action-btn"><i class="fas fa-eye"></i></a>
                                <a href="#" class="action-btn"><i class="fas fa-envelope"></i></a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">PS</div>
                                <div>
                                    <div style="font-weight: 700;">Priya Singh</div>
                                    <div style="font-size: 0.85rem; color: #5f7d9c;">CSE · 9.0 CGPA</div>
                                </div>
                            </div>
                        </td>
                        <td>2112345198</td>
                        <td>Google</td>
                        <td>Software Engineer</td>
                        <td>35.0 LPA</td>
                        <td><span class="status-badge status-offer-sent">Offer sent</span></td>
                        <td><a href="#" style="color: #1e3c72;"><i class="fas fa-download"></i> PDF</a></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="#" class="action-btn"><i class="fas fa-eye"></i></a>
                                <a href="#" class="action-btn"><i class="fas fa-envelope"></i></a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · selected candidates & offers</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> selected · offers
    </div>
</body>
</html>