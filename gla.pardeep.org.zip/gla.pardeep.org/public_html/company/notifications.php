<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Notifications</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .notifications-wrapper {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        .notifications-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ff9f1c, #ffb347);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #ff9f1c;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* filter tabs */
        .filter-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .filter-tab {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            border: 1px solid white;
            cursor: pointer;
            transition: 0.2s;
        }
        .filter-tab.active {
            background: #1e3c72;
            color: white;
        }
        .filter-tab:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* notifications list */
        .notifications-list {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 1rem;
            border: 1px solid rgba(255,255,255,0.9);
        }

        .notification-item {
            display: flex;
            align-items: flex-start;
            gap: 1.5rem;
            padding: 1.5rem;
            border-bottom: 1px solid rgba(30,60,114,0.1);
            transition: 0.2s;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item:hover {
            background: rgba(255,255,255,0.5);
            border-radius: 1.5rem;
        }
        .notification-item.unread {
            background: rgba(30,60,114,0.05);
        }

        .notification-icon {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #1e3c72;
        }
        .notification-content {
            flex: 1;
        }
        .notification-title {
            font-weight: 700;
            font-size: 1.1rem;
            color: #0b2b4e;
            margin-bottom: 0.3rem;
        }
        .notification-message {
            color: #2c577c;
            margin-bottom: 0.5rem;
        }
        .notification-time {
            font-size: 0.85rem;
            color: #5f7d9c;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .notification-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        .notif-action-btn {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 0.5rem 1.2rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            font-size: 0.9rem;
            text-decoration: none;
        }
        .notif-action-btn:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* mark all read */
        .mark-read {
            text-align: right;
            margin-bottom: 1rem;
        }
        .mark-read-btn {
            background: rgba(255,255,255,0.6);
            padding: 0.6rem 1.8rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            border: 1px solid white;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
            text-decoration: none;
        }
        .mark-read-btn:hover {
            background: white;
            border-color: #1e3c72;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="notifications-wrapper">
        <!-- header -->
        <div class="notifications-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-bell"></i> notifications.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-bell"></i>
            </div>
            <div>
                <h1>Notifications</h1>
                <p>Stay updated with recent activities</p>
            </div>
        </div>

        <!-- filter tabs -->
        <div class="filter-tabs">
            <div class="filter-tab active">All (12)</div>
            <div class="filter-tab">Unread (5)</div>
            <div class="filter-tab">Applications (6)</div>
            <div class="filter-tab">Drives (4)</div>
            <div class="filter-tab">Interviews (2)</div>
        </div>

        <!-- mark all read -->
        <div class="mark-read">
            <a href="#" class="mark-read-btn"><i class="fas fa-check-double"></i> Mark all as read</a>
        </div>

        <!-- notifications list -->
        <div class="notifications-list">
            <!-- unread notification -->
            <div class="notification-item unread">
                <div class="notification-icon"><i class="fas fa-user-plus"></i></div>
                <div class="notification-content">
                    <div class="notification-title">New application received</div>
                    <div class="notification-message">Rahul Sharma applied for SDE position at Infosys drive.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 5 minutes ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-eye"></i> View</a>
                    <a href="#" class="notif-action-btn"><i class="fas fa-check"></i> Mark read</a>
                </div>
            </div>

            <!-- unread notification -->
            <div class="notification-item unread">
                <div class="notification-icon"><i class="fas fa-calendar-check"></i></div>
                <div class="notification-content">
                    <div class="notification-title">Interview scheduled</div>
                    <div class="notification-message">Virtual interview with Priya Mehta (Deloitte Analyst) at 4:00 PM today.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 1 hour ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-video"></i> Join</a>
                    <a href="#" class="notif-action-btn"><i class="fas fa-check"></i> Mark read</a>
                </div>
            </div>

            <!-- read notification -->
            <div class="notification-item">
                <div class="notification-icon"><i class="fas fa-check-circle"></i></div>
                <div class="notification-content">
                    <div class="notification-title">Candidate shortlisted</div>
                    <div class="notification-message">Ankit Verma has been shortlisted for Amazon SDE position.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 3 hours ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-eye"></i> View</a>
                </div>
            </div>

            <!-- read notification -->
            <div class="notification-item">
                <div class="notification-icon"><i class="fas fa-bullhorn"></i></div>
                <div class="notification-content">
                    <div class="notification-title">New drive created</div>
                    <div class="notification-message">Google SDE drive has been scheduled for 25th November 2026.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 5 hours ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-eye"></i> View</a>
                </div>
            </div>

            <!-- read notification -->
            <div class="notification-item">
                <div class="notification-icon"><i class="fas fa-file-pdf"></i></div>
                <div class="notification-content">
                    <div class="notification-title">Offer letter generated</div>
                    <div class="notification-message">Offer letter for Shreya Gupta (Amazon SDE) has been generated.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 1 day ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-download"></i> Download</a>
                </div>
            </div>

            <!-- read notification -->
            <div class="notification-item">
                <div class="notification-icon"><i class="fas fa-user-check"></i></div>
                <div class="notification-content">
                    <div class="notification-title">Offer accepted</div>
                    <div class="notification-message">Yash Jain has accepted the offer from Deloitte.</div>
                    <div class="notification-time"><i class="far fa-clock"></i> 2 days ago</div>
                </div>
                <div class="notification-actions">
                    <a href="#" class="notif-action-btn"><i class="fas fa-eye"></i> View</a>
                </div>
            </div>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · notification center</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> notifications · center
    </div>
</body>
</html>