<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require '../../config/db.php';

$token = $_GET['token'] ?? '';

if(!$token) die("Invalid link");

// 1️⃣ Verify token
$stmt = $conn->prepare("
SELECT id, company_uid, token_expiry 
FROM companies 
WHERE doc_token=?
");
$stmt->bind_param("s",$token);
$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows == 0) die("Invalid token");

$company = $res->fetch_assoc();

if(strtotime($company['token_expiry']) < time())
    die("Link expired");

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    $uid = $company['company_uid'];
    $uploadDir = "../../assets/company_docs/".$uid."/";

    if(!is_dir($uploadDir)) mkdir($uploadDir,0777,true);

    $zipName = "documents_".time().".zip";
    $path = $uploadDir.$zipName;

    move_uploaded_file($_FILES['docs']['tmp_name'], $path);

    // Update DB
    $stmt2 = $conn->prepare("
    UPDATE companies 
    SET docs_uploaded=1,
        docs_uploaded_at=NOW(),
        status='docs_submitted',
        doc_file=?
    WHERE id=?
    ");
    $stmt2->bind_param("si",$zipName,$company['id']);
    $stmt2->execute();

    echo "<h2>Documents uploaded successfully</h2>";
    exit;
}
?>

<form method="POST" enctype="multipart/form-data">
    <h2>Upload Documents (ZIP only)</h2>
    <input type="file" name="docs" accept=".zip" required>
    <button type="submit">Upload</button>
</form>