<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Orientation Section</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .orient-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        .orient-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ff9f1c, #ffb347);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #ff9f1c;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* stats row */
        .stats-row {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border-radius: 2rem;
            padding: 1.5rem 2rem;
            flex: 1;
            min-width: 150px;
            border: 1px solid rgba(255,255,255,0.9);
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: #ff9f1c;
        }
        .stat-label {
            font-weight: 600;
            color: #2c577c;
        }

        /* progress overview */
        .progress-overview {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .progress-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 1.5rem;
        }
        .progress-item {
            margin-bottom: 1.5rem;
        }
        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .progress-bar-bg {
            background: rgba(255,255,255,0.8);
            height: 12px;
            border-radius: 60px;
            overflow: hidden;
        }
        .progress-bar-fill {
            height: 12px;
            background: linear-gradient(to right, #1e3c72, #ff9f1c);
            border-radius: 60px;
        }

        /* sessions grid */
        .sessions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.8rem;
            margin-top: 1rem;
        }

        .session-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2rem;
            padding: 1.8rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
        }
        .session-card:hover {
            transform: translateY(-5px);
            background: rgba(255,255,255,0.9);
        }

        .session-date {
            color: #ff9f1c;
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }
        .session-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: #0b2b4e;
            margin-bottom: 1rem;
        }
        .session-company {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #2c577c;
            margin-bottom: 1rem;
        }
        .session-details {
            margin: 1rem 0;
        }
        .session-detail {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0;
            color: #2c577c;
        }
        .session-status {
            display: inline-block;
            padding: 0.3rem 1rem;
            border-radius: 60px;
            font-size: 0.85rem;
            font-weight: 600;
            margin: 0.5rem 0;
        }
        .status-scheduled { background: #ffb34720; color: #b45f06; }
        .status-completed { background: #28a74520; color: #28a745; }
        .status-cancelled { background: #dc354520; color: #dc3545; }

        .session-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .session-btn {
            flex: 1;
            padding: 0.8rem;
            border-radius: 60px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            transition: 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            color: #1e3c72;
        }
        .session-btn.primary {
            background: #ff9f1c;
            color: white;
        }
        .session-btn:hover {
            background: white;
            border-color: #ff9f1c;
        }

        /* materials section */
        .materials-section {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 2rem;
            margin-top: 2rem;
        }
        .materials-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 1.5rem;
        }
        .materials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
        }
        .material-item {
            background: rgba(255,255,255,0.8);
            padding: 1rem;
            border-radius: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .material-icon {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ff9f1c;
        }
        .material-info {
            flex: 1;
        }
        .material-name {
            font-weight: 600;
            color: #1e3c72;
        }
        .material-size {
            font-size: 0.8rem;
            color: #5f7d9c;
        }
        .material-download {
            color: #1e3c72;
            cursor: pointer;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="orient-wrapper">
        <!-- header -->
        <div class="orient-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-compass"></i> orient_section.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div>
                <h1>Orientation section</h1>
                <p>Manage pre-placement talks and orientation sessions</p>
            </div>
        </div>

        <!-- stats -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-number">8</div>
                <div class="stat-label">Total sessions</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">5</div>
                <div class="stat-label">Completed</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">3</div>
                <div class="stat-label">Upcoming</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">342</div>
                <div class="stat-label">Students attended</div>
            </div>
        </div>

        <!-- progress overview -->
        <div class="progress-overview">
            <div class="progress-title">Orientation progress</div>
            <div class="progress-item">
                <div class="progress-header">
                    <span>Overall completion</span>
                    <span>68%</span>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: 68%;"></div>
                </div>
            </div>
            <div class="progress-item">
                <div class="progress-header">
                    <span>Technical sessions</span>
                    <span>75%</span>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: 75%;"></div>
                </div>
            </div>
            <div class="progress-item">
                <div class="progress-header">
                    <span>HR / soft skills</span>
                    <span>60%</span>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: 60%;"></div>
                </div>
            </div>
        </div>

        <!-- action bar -->
        <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem;">
            <h2 style="color: #1e3c72;">Upcoming sessions</h2>
            <a href="#" class="btn-primary" style="background: #ff9f1c; padding: 0.8rem 2rem; border-radius: 60px; color: white; text-decoration: none; display: inline-flex; align-items: center; gap: 8px;"><i class="fas fa-plus"></i> Schedule session</a>
        </div>

        <!-- sessions grid -->
        <div class="sessions-grid">
            <!-- upcoming session -->
            <div class="session-card">
                <div class="session-date">📅 20 Nov 2026 · 11:00 AM</div>
                <div class="session-title">Pre-placement talk</div>
                <div class="session-company"><i class="fas fa-building"></i> Infosys</div>
                <div class="session-details">
                    <div class="session-detail"><i class="fas fa-user-tie"></i> Speaker: Rajesh Kumar (HR)</div>
                    <div class="session-detail"><i class="fas fa-users"></i> Expected: 120 students</div>
                    <div class="session-detail"><i class="fas fa-video"></i> Mode: Online (Google Meet)</div>
                </div>
                <div class="session-status status-scheduled">⏳ Scheduled</div>
                <div class="session-actions">
                    <a href="#" class="session-btn"><i class="fas fa-edit"></i> Edit</a>
                    <a href="#" class="session-btn primary"><i class="fas fa-video"></i> Start</a>
                </div>
            </div>

            <!-- upcoming session -->
            <div class="session-card">
                <div class="session-date">📅 22 Nov 2026 · 2:00 PM</div>
                <div class="session-title">Technical orientation</div>
                <div class="session-company"><i class="fas fa-building"></i> Microsoft</div>
                <div class="session-details">
                    <div class="session-detail"><i class="fas fa-user-tie"></i> Speaker: Sarah Johnson</div>
                    <div class="session-detail"><i class="fas fa-users"></i> Expected: 80 students</div>
                    <div class="session-detail"><i class="fas fa-video"></i> Mode: Microsoft Teams</div>
                </div>
                <div class="session-status status-scheduled">⏳ Scheduled</div>
                <div class="session-actions">
                    <a href="#" class="session-btn"><i class="fas fa-edit"></i> Edit</a>
                    <a href="#" class="session-btn primary"><i class="fas fa-video"></i> Start</a>
                </div>
            </div>

            <!-- upcoming session -->
            <div class="session-card">
                <div class="session-date">📅 25 Nov 2026 · 10:00 AM</div>
                <div class="session-title">Company culture & values</div>
                <div class="session-company"><i class="fas fa-building"></i> Google</div>
                <div class="session-details">
                    <div class="session-detail"><i class="fas fa-user-tie"></i> Speaker: Michael Chen</div>
                    <div class="session-detail"><i class="fas fa-users"></i> Expected: 150 students</div>
                    <div class="session-detail"><i class="fas fa-video"></i> Mode: YouTube Live</div>
                </div>
                <div class="session-status status-scheduled">⏳ Scheduled</div>
                <div class="session-actions">
                    <a href="#" class="session-btn"><i class="fas fa-edit"></i> Edit</a>
                    <a href="#" class="session-btn primary"><i class="fas fa-video"></i> Start</a>
                </div>
            </div>
        </div>

        <!-- completed sessions -->
        <h2 style="color: #1e3c72; margin: 2rem 0 1rem;">Completed sessions</h2>
        <div class="sessions-grid">
            <!-- completed session -->
            <div class="session-card">
                <div class="session-date">📅 10 Nov 2026</div>
                <div class="session-title">Resume building workshop</div>
                <div class="session-company"><i class="fas fa-building"></i> Deloitte</div>
                <div class="session-details">
                    <div class="session-detail"><i class="fas fa-users"></i> Attended: 95 students</div>
                    <div class="session-detail"><i class="fas fa-star"></i> Feedback: 4.5/5</div>
                </div>
                <div class="session-status status-completed">✓ Completed</div>
                <div class="session-actions">
                    <a href="#" class="session-btn"><i class="fas fa-chart-bar"></i> Report</a>
                    <a href="#" class="session-btn"><i class="fas fa-redo"></i> Schedule again</a>
                </div>
            </div>

            <!-- completed session -->
            <div class="session-card">
                <div class="session-date">📅 05 Nov 2026</div>
                <div class="session-title">Interview preparation</div>
                <div class="session-company"><i class="fas fa-building"></i> Amazon</div>
                <div class="session-details">
                    <div class="session-detail"><i class="fas fa-users"></i> Attended: 110 students</div>
                    <div class="session-detail"><i class="fas fa-star"></i> Feedback: 4.8/5</div>
                </div>
                <div class="session-status status-completed">✓ Completed</div>
                <div class="session-actions">
                    <a href="#" class="session-btn"><i class="fas fa-chart-bar"></i> Report</a>
                    <a href="#" class="session-btn"><i class="fas fa-redo"></i> Schedule again</a>
                </div>
            </div>
        </div>

        <!-- materials section -->
        <div class="materials-section">
            <div class="materials-title"><i class="fas fa-download" style="margin-right: 10px;"></i> Orientation materials</div>
            <div class="materials-grid">
                <div class="material-item">
                    <div class="material-icon"><i class="fas fa-file-pdf"></i></div>
                    <div class="material-info">
                        <div class="material-name">Infosys PPT.pdf</div>
                        <div class="material-size">2.4 MB</div>
                    </div>
                    <div class="material-download"><i class="fas fa-download"></i></div>
                </div>
                <div class="material-item">
                    <div class="material-icon"><i class="fas fa-file-video"></i></div>
                    <div class="material-info">
                        <div class="material-name">Microsoft recording.mp4</div>
                        <div class="material-size">156 MB</div>
                    </div>
                    <div class="material-download"><i class="fas fa-download"></i></div>
                </div>
                <div class="material-item">
                    <div class="material-icon"><i class="fas fa-file-word"></i></div>
                    <div class="material-info">
                        <div class="material-name">Amazon guide.docx</div>
                        <div class="material-size">1.1 MB</div>
                    </div>
                    <div class="material-download"><i class="fas fa-download"></i></div>
                </div>
                <div class="material-item">
                    <div class="material-icon"><i class="fas fa-file-powerpoint"></i></div>
                    <div class="material-info">
                        <div class="material-name">Deloitte slides.pptx</div>
                        <div class="material-size">3.8 MB</div>
                    </div>
                    <div class="material-download"><i class="fas fa-download"></i></div>
                </div>
            </div>
            <div style="margin-top: 1.5rem; text-align: right;">
                <a href="#" class="btn-secondary" style="background: rgba(255,255,255,0.8); padding: 0.8rem 2rem; border-radius: 60px; text-decoration: none; color: #1e3c72;"><i class="fas fa-cloud-upload-alt"></i> Upload new material</a>
            </div>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · orientation section</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> orientation · sessions
    </div>
</body>
</html>