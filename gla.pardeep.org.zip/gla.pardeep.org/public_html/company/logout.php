<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Logout</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            line-height: 1.5;
        }

        /* glass background shapes */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .logout-wrapper {
            max-width: 500px;
            width: 100%;
            padding: 2rem;
            margin: 0 auto;
            position: relative;
            z-index: 5;
        }

        .logout-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 3rem;
            box-shadow: 
                0 35px 68px -20px rgba(0,45,75,0.3),
                inset 0 -1px 1px rgba(255,255,255,0.7),
                inset 0 1px 2px rgba(255,255,255,0.8);
            border: 1px solid rgba(255,255,255,0.7);
            width: 100%;
            padding: 3rem 2.5rem;
            text-align: center;
        }

        /* animated icon */
        .icon-container {
            margin-bottom: 2rem;
            position: relative;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 120px;
            height: 120px;
            border-radius: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            box-shadow: 0 20px 30px -12px #1e3c7240, 0 0 0 1px rgba(255,255,255,0.8) inset;
            animation: pulse 2s infinite;
        }
        .icon-ring i {
            font-size: 4rem;
            color: #b34141;
            filter: drop-shadow(0 6px 8px rgba(179,65,65,0.3));
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .logout-card h1 {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(to right, #b34141, #d64545);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 0.5rem;
        }

        .logout-card p {
            color: #365f8a;
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        /* user info */
        .user-info {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
            border-radius: 60px;
            padding: 1.2rem;
            margin-bottom: 2.5rem;
            border: 1px solid rgba(255,255,255,0.8);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: #1e3c72;
        }
        .user-details {
            text-align: left;
        }
        .user-name {
            font-weight: 700;
            font-size: 1.1rem;
            color: #0b2b4e;
        }
        .user-email {
            color: #5f7d9c;
            font-size: 0.9rem;
        }

        /* action buttons */
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .btn-primary {
            flex: 1;
            background: #b34141;
            border: none;
            padding: 1.2rem;
            border-radius: 60px;
            color: white;
            font-weight: 700;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #b34141;
            transition: 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .btn-primary:hover {
            background: #8f2e2e;
            transform: translateY(-3px);
            box-shadow: 0 28px 38px -16px #8f2e2e;
        }

        .btn-secondary {
            flex: 1;
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 1.2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }
        .btn-secondary:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* logout options */
        .logout-options {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
            margin-top: 1rem;
        }
        .option-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.8rem 1.5rem;
            background: rgba(255,255,255,0.5);
            border-radius: 60px;
            text-decoration: none;
            color: #1e3c72;
            font-weight: 600;
            transition: 0.2s;
            border: 1px solid transparent;
        }
        .option-link:hover {
            background: white;
            border-color: #1e3c72;
        }
        .option-link i {
            width: 24px;
        }

        /* redirect message */
        .redirect-message {
            margin-top: 2rem;
            font-size: 0.9rem;
            color: #5f7d9c;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .spinner {
            width: 20px;
            height: 20px;
            border: 3px solid rgba(30,60,114,0.2);
            border-top-color: #1e3c72;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .footer-note {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.8rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.6rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
            border: 1px solid rgba(255,255,255,0.8);
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
            box-shadow: 0 10px 20px -12px #1e3c72;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }

        /* dark overlay for logout effect */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(3px);
            z-index: 9998;
            display: none;
        }
        .overlay.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- overlay for logout effect -->
    <div class="overlay" id="overlay"></div>

    <div class="logout-wrapper">
        <div class="logout-card">
            <!-- animated icon -->
            <div class="icon-container">
                <div class="icon-ring">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
            </div>

            <h1>Logout</h1>
            <p>Are you sure you want to sign out?</p>

            <!-- current user info -->
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-building"></i>
                </div>
                <div class="user-details">
                    <div class="user-name">Nexa Corp.</div>
                    <div class="user-email">hr@nexa.com</div>
                </div>
            </div>

            <!-- action buttons -->
            <div class="action-buttons">
                <a href="dashboard.php" class="btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                <a href="#" class="btn-primary" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>

            <!-- other options -->
            <div class="logout-options">
                <a href="#" class="option-link" id="switchAccount">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Switch to different account</span>
                </a>
                <a href="#" class="option-link" id="staySignedIn">
                    <i class="fas fa-clock"></i>
                    <span>Stay signed in for 24 hours</span>
                </a>
            </div>

            <!-- redirect message (hidden by default) -->
            <div class="redirect-message" id="redirectMessage" style="display: none;">
                <div class="spinner"></div>
                <span>Logging out... Redirecting to login page</span>
            </div>

            <!-- footer note -->
            <div style="margin-top: 2rem;">
                <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · secure logout</span>
            </div>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> Nexa Corp. · logging out
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const overlay = document.getElementById('overlay');
            const redirectMessage = document.getElementById('redirectMessage');
            const switchAccount = document.getElementById('switchAccount');
            const staySignedIn = document.getElementById('staySignedIn');
            const cancelBtn = document.querySelector('.btn-secondary');

            // Logout functionality
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Show overlay and message
                overlay.classList.add('active');
                redirectMessage.style.display = 'flex';
                
                // Disable buttons
                logoutBtn.style.pointerEvents = 'none';
                if(cancelBtn) cancelBtn.style.pointerEvents = 'none';
                
                // Simulate logout process
                setTimeout(function() {
                    // Clear session storage (demo)
                    sessionStorage.clear();
                    localStorage.removeItem('user');
                    
                    // Redirect to login page
                    window.location.href = 'login.php?loggedout=1';
                }, 2000);
            });

            // Switch account
            switchAccount.addEventListener('click', function(e) {
                e.preventDefault();
                
                overlay.classList.add('active');
                redirectMessage.style.display = 'flex';
                redirectMessage.querySelector('span').textContent = 'Redirecting to account switcher...';
                
                setTimeout(function() {
                    window.location.href = 'login.php?switch=1';
                }, 1500);
            });

            // Stay signed in
            staySignedIn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Show toast notification (demo)
                alert('🔒 Session extended for 24 hours');
                
                // Redirect back to dashboard
                window.location.href = 'dashboard.php';
            });

            // Cancel button - already has href="dashboard.php"
            
            // Auto logout after inactivity (demo)
            let timeout;
            function resetTimer() {
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    if(confirm('Session timeout due to inactivity. Would you like to stay logged in?')) {
                        // reset
                    } else {
                        window.location.href = 'logout.php';
                    }
                }, 300000); // 5 minutes
            }
            
            // Uncomment to enable auto-logout
            // window.addEventListener('mousemove', resetTimer);
            // window.addEventListener('keypress', resetTimer);
            // resetTimer();
        });

        // Simulate session check (PHP-style)
        <?php if(isset($_GET['expired'])): ?>
        alert('Your session has expired. Please login again.');
        window.location.href = 'login.php';
        <?php endif; ?>
    </script>

    <!-- server-side logout simulation (commented for HTML demo) -->
    <!-- 
    <?php
    // session_start();
    // session_destroy();
    // setcookie("user_login", "", time() - 3600, "/");
    // header("Location: login.php?logout=success");
    ?>
    -->
</body>
</html>