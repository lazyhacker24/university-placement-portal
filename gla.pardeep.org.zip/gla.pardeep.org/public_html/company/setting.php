<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Settings</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        /* glass background shapes (consistent with portal) */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        /* main container */
        .settings-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 2rem;
            position: relative;
            z-index: 5;
        }

        /* header with back link */
        .settings-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ffb347, #ff9f1c);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
            box-shadow: 0 6px 14px rgba(255,160,50,0.2);
        }
        .page-badge i {
            margin-right: 6px;
        }

        /* title area */
        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 3rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240, 0 0 0 1px rgba(255,255,255,0.8) inset;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #1e3c72;
            filter: drop-shadow(0 6px 8px #1e3c7220);
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .title-section p {
            color: #365f8a;
            font-weight: 500;
            font-size: 1.1rem;
            margin-top: 0.2rem;
        }

        /* settings grid – two columns */
        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        /* glass card */
        .glass-card {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 2.5rem;
            padding: 2rem 2rem;
            border: 1px solid rgba(255,255,255,0.9);
            box-shadow: 0 25px 40px -24px #1e3c72, inset 0 1px 2px white;
            transition: all 0.2s;
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 2rem;
            border-bottom: 1px dashed rgba(30,60,114,0.2);
            padding-bottom: 1.2rem;
        }
        .card-header i {
            font-size: 2rem;
            background: white;
            padding: 12px;
            border-radius: 20px;
            color: #ff9f1c;
            box-shadow: 0 8px 16px -12px #1e3c72;
        }
        .card-header h3 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0b2b4e;
        }

        /* settings rows */
        .setting-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem 0.5rem;
            border-bottom: 1px solid rgba(30,60,114,0.1);
        }
        .setting-row:last-child {
            border-bottom: none;
        }
        .setting-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .setting-info i {
            width: 28px;
            color: #1e3c72;
            font-size: 1.3rem;
        }
        .setting-text {
            font-weight: 600;
            color: #1a3b5c;
        }
        .setting-value {
            color: #2c577c;
            font-weight: 500;
            background: rgba(255,255,255,0.6);
            padding: 0.3rem 1rem;
            border-radius: 40px;
            font-size: 0.9rem;
        }
        .setting-action {
            color: #1e3c72;
            font-size: 1.2rem;
            opacity: 0.7;
            transition: 0.2s;
            cursor: default;
        }
        .setting-action:hover {
            opacity: 1;
            transform: scale(1.1);
        }

        /* toggle switch simulation */
        .toggle-indicator {
            width: 44px;
            height: 24px;
            background: #1e3c72;
            border-radius: 60px;
            position: relative;
            display: inline-block;
            box-shadow: inset 0 1px 4px #00000020;
        }
        .toggle-indicator::after {
            content: "";
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            position: absolute;
            top: 2px;
            right: 2px;
            box-shadow: 0 1px 3px black;
        }

        .btn-primary {
            background: #1e3c72;
            border: none;
            padding: 1.2rem 2.5rem;
            border-radius: 120px;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #1e3c72, 0 2px 0 0 #2f5890 inset;
            transition: 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .btn-primary:hover {
            background: #143768;
            transform: translateY(-3px);
            box-shadow: 0 28px 38px -16px #0f2b50;
        }

        .danger-zone {
            margin-top: 3rem;
            background: rgba(255,230,230,0.6);
            backdrop-filter: blur(10px);
            border-radius: 2rem;
            padding: 2rem;
            border: 1px solid #ffb3b3;
        }
        .danger-zone h4 {
            font-size: 1.5rem;
            color: #b34141;
            margin-bottom: 1.2rem;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
            border: 1px solid rgba(255,255,255,0.8);
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
            box-shadow: 0 10px 20px -12px #1e3c72;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="settings-wrapper">
        <!-- header with back link (like forgot.php style) -->
        <div class="settings-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-sliders"></i> settings.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-cog"></i>
            </div>
            <div>
                <h1>Company settings</h1>
                <p>Manage your account, team and preferences</p>
            </div>
        </div>

        <!-- settings grid: all options neatly arranged -->
        <div class="settings-grid">
            <!-- ACCOUNT SETTINGS CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-user-lock"></i>
                    <h3>Account</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-envelope"></i><span class="setting-text">Email address</span></div>
                    <span class="setting-value">hr@nexa.com</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-lock"></i><span class="setting-text">Password</span></div>
                    <span class="setting-value">••••••••</span>
                    <i class="fas fa-sync-alt setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-building"></i><span class="setting-text">Company name</span></div>
                    <span class="setting-value">Nexa Corp.</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-phone"></i><span class="setting-text">Phone</span></div>
                    <span class="setting-value">+91 98765 43210</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
            </div>

            <!-- TEAM & ACCESS CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-users-cog"></i>
                    <h3>Team & roles</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-user-tie"></i><span class="setting-text">Primary admin</span></div>
                    <span class="setting-value">amit@nexa.com</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-user-plus"></i><span class="setting-text">Team members</span></div>
                    <span class="setting-value">3 users</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-user-tag"></i><span class="setting-text">Roles & permissions</span></div>
                    <span class="setting-value">2 roles</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-history"></i><span class="setting-text">Activity log</span></div>
                    <span class="setting-value">view</span>
                    <i class="fas fa-external-link-alt setting-action"></i>
                </div>
            </div>

            <!-- NOTIFICATIONS CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-bell"></i>
                    <h3>Notifications</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-envelope-open-text"></i><span class="setting-text">Email alerts</span></div>
                    <span class="toggle-indicator"></span>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-calendar-check"></i><span class="setting-text">Drive reminders</span></div>
                    <span class="toggle-indicator"></span>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-bell"></i><span class="setting-text">New applications</span></div>
                    <span class="setting-value">instant</span>
                    <i class="fas fa-chevron-down setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-sms"></i><span class="setting-text">SMS (optional)</span></div>
                    <span class="setting-value">off</span>
                    <i class="fas fa-toggle-off setting-action" style="color:#888;"></i>
                </div>
            </div>

            <!-- COMPANY PROFILE CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-briefcase"></i>
                    <h3>Company profile</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-globe"></i><span class="setting-text">Website</span></div>
                    <span class="setting-value">nexa.in</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-map-marker-alt"></i><span class="setting-text">Address</span></div>
                    <span class="setting-value">Noida, India</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-industry"></i><span class="setting-text">Industry</span></div>
                    <span class="setting-value">IT services</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-users"></i><span class="setting-text">Employee count</span></div>
                    <span class="setting-value">200+</span>
                    <i class="fas fa-pen setting-action"></i>
                </div>
            </div>

            <!-- INTEGRATION & API CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-plug"></i>
                    <h3>Integrations</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fab fa-google"></i><span class="setting-text">Google calendar</span></div>
                    <span class="setting-value">connected</span>
                    <i class="fas fa-check-circle" style="color:#28a745;"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-code"></i><span class="setting-text">API access</span></div>
                    <span class="setting-value">v2 active</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-key"></i><span class="setting-text">API keys</span></div>
                    <span class="setting-value">••••••</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-webhook"></i><span class="setting-text">Webhooks</span></div>
                    <span class="setting-value">0 configured</span>
                    <i class="fas fa-plus setting-action"></i>
                </div>
            </div>

            <!-- SECURITY CARD -->
            <div class="glass-card">
                <div class="card-header">
                    <i class="fas fa-shield-alt"></i>
                    <h3>Security</h3>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-mobile-alt"></i><span class="setting-text">Two‑factor auth</span></div>
                    <span class="setting-value">off</span>
                    <i class="fas fa-toggle-off setting-action" style="color:#888;"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-history"></i><span class="setting-text">Session timeout</span></div>
                    <span class="setting-value">30 min</span>
                    <i class="fas fa-chevron-down setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-clipboard-list"></i><span class="setting-text">Login history</span></div>
                    <span class="setting-value">view</span>
                    <i class="fas fa-chevron-right setting-action"></i>
                </div>
                <div class="setting-row">
                    <div class="setting-info"><i class="fas fa-ip"></i><span class="setting-text">IP whitelist</span></div>
                    <span class="setting-value">none</span>
                    <i class="fas fa-plus setting-action"></i>
                </div>
            </div>
        </div>

        <!-- DANGER ZONE (like delete account etc) -->
        <div class="danger-zone">
            <h4><i class="fas fa-exclamation-triangle"></i> Danger zone</h4>
            <div style="display: flex; flex-wrap: wrap; gap: 2rem; align-items: center;">
                <div style="flex:1;">
                    <p style="font-weight:600;">Permanently delete company account</p>
                    <p style="font-size:0.9rem;">Once deleted, all data will be lost. This action cannot be undone.</p>
                </div>
                <button style="background:#b34141; border:none; padding:1rem 2.5rem; border-radius:60px; color:white; font-weight:700; cursor:pointer;">Delete account</button>
            </div>
        </div>

        <!-- save button row -->
        <div style="display: flex; justify-content: flex-end; margin-top: 2rem;">
            <a href="#" class="btn-primary"><i class="fas fa-save"></i> Save settings</a>
        </div>

        <!-- footer note (like forgot.php style) -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · secure settings panel</span>
        </div>
    </div>

    <!-- floating company badge -->
    <div class="floating-company">
        <i class="fas fa-building"></i> settings · advanced
    </div>

    <!-- hidden note: this is settings.php standalone -->
    <div style="display: none;">settings.php – individual page</div>
</body>
</html>