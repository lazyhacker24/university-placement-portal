<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../config/db.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $identifier = trim($_POST['company_identifier']);

    if(empty($identifier)){
        header("Location: ../forgot.php?error=empty");
        exit();
    }

    // find company
    $stmt = $conn->prepare("SELECT id,email FROM companies WHERE email=? OR company_id=? LIMIT 1");
    $stmt->bind_param("ss",$identifier,$identifier);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $company = $result->fetch_assoc();
        $company_id = $company['id'];
        $email = $company['email'];

        // generate secure token
        $token = bin2hex(random_bytes(32));
        $expiry = date("Y-m-d H:i:s", strtotime("+30 minutes"));

        // delete old tokens
        $del = $conn->prepare("DELETE FROM password_resets WHERE company_id=?");
        $del->bind_param("i",$company_id);
        $del->execute();

        // insert new token
        $ins = $conn->prepare("INSERT INTO password_resets(company_id,token,expires_at) VALUES(?,?,?)");
        $ins->bind_param("iss",$company_id,$token,$expiry);
        $ins->execute();

        // reset link
        $reset_link = "https://gla.pardeep.org/company/reset-password.php?token=".$token;

        // send email
        $subject = "Password Reset Request";
        $message = "Click the link to reset password:\n\n".$reset_link."\n\nLink expires in 30 minutes.";
        $headers = "From: noreply@gla.pardeep.org";

        mail($email,$subject,$message,$headers);
    }

    header("Location: ../forgot.php?reset=sent");
    exit();
}
?>