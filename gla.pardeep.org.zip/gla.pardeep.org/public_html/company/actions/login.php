<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $company_id = trim($_POST['company_id']);
    $password   = trim($_POST['password']);

    if (empty($company_id) || empty($password)) {
        header("Location: ../index.php?error=empty");
        exit();
    }

    $sql = "SELECT * FROM companies WHERE email = ? OR company_id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $company_id, $company_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $company = $result->fetch_assoc();

        if (password_verify($password, $company['password'])) {

            $_SESSION['company_logged_in'] = true;
            $_SESSION['company_id'] = $company['id'];
            $_SESSION['company_name'] = $company['company_name'];

            if (isset($_POST['remember'])) {
                setcookie("company_auth", $company['id'], time() + (86400 * 30), "/");
            }

            header("Location: ../dashboard.php");
            exit();

        } else {
            header("Location: ../index.php?error=wrongpass");
            exit();
        }

    } else {
        header("Location: ../index.php?error=notfound");
        exit();
    }
}
?>