<?php
require_once '../../config/db.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $token = $_POST['token'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("SELECT company_id FROM password_resets WHERE token=? AND expires_at > NOW()");
    $stmt->bind_param("s",$token);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows==0) die("Invalid or expired token");

    $row = $result->fetch_assoc();
    $company_id = $row['company_id'];

    $update = $conn->prepare("UPDATE companies SET password=? WHERE id=?");
    $update->bind_param("si",$password,$company_id);
    $update->execute();

    $del = $conn->prepare("DELETE FROM password_resets WHERE company_id=?");
    $del->bind_param("i",$company_id);
    $del->execute();

    echo "Password updated successfully. <a href='../company'>Login</a>";
}
?>