<?php
session_start();
session_destroy();
setcookie("company_auth", "", time() - 3600, "/");
header("Location: ../../login.php");
exit();
?>