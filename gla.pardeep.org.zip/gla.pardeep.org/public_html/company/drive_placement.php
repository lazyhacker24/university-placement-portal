<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../config/session.php'; 
require_once '../config/db.php';

if(!isset($_SESSION['company_id'])){
    die("Login required");
}

$company_id = intval($_SESSION['company_id']);

// ================= INSERT DRIVE =================
if(isset($_POST['create_drive'])){

    $title = $_POST['title'];
    $role = $_POST['role'];
    $date = $_POST['date'];
    $deadline = $_POST['deadline'];
    $ctc = $_POST['ctc'];
    $location = $_POST['location'];
    $mode = $_POST['mode'];

    // 🔴 CHECK SAME DATE (ALL COMPANIES)
    $check = $conn->prepare("SELECT id FROM placement_drives WHERE date=?");
    $check->bind_param("s", $date);
    $check->execute();
    $res = $check->get_result();

    if($res->num_rows > 0){
        echo "<script>alert('⚠️ Drive already exists on this date');</script>";
    } else {

        $stmt = $conn->prepare("INSERT INTO placement_drives 
        (company_id, title, role, date, last_date, salary_package, location, venue, drive_status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')");

        $stmt->bind_param("isssssss", $company_id, $title, $role, $date, $deadline, $ctc, $location, $mode);
        $stmt->execute();
    }
}

// ================= FETCH DRIVES =================
$drives = $conn->query("SELECT * FROM placement_drives WHERE company_id=$company_id ORDER BY id DESC");

// ================= STATS =================
$total = $conn->query("SELECT COUNT(*) as t FROM placement_drives WHERE company_id=$company_id")->fetch_assoc()['t'];

$active = $conn->query("SELECT COUNT(*) as t FROM placement_drives WHERE drive_status='active' AND company_id=$company_id")->fetch_assoc()['t'];

$upcoming = $conn->query("SELECT COUNT(*) as t FROM placement_drives WHERE date > CURDATE() AND company_id=$company_id")->fetch_assoc()['t'];

$applications = $conn->query("SELECT COUNT(*) as t FROM applications WHERE company_id=$company_id")->fetch_assoc()['t'];


// ================= UPCOMING (ALL COMPANIES) =================
$allUpcoming = $conn->query("
SELECT p.title, p.date, c.company_name 
FROM placement_drives p
JOIN companies c ON p.company_id = c.id
WHERE p.date >= CURDATE()
ORDER BY p.date ASC
LIMIT 5
");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Drive Placement</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        /* glass background shapes */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .drive-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        /* header */
        .drive-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #1e3c72, #2a5a9c);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: white;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #1e3c72;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* stats row */
        .stats-row {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border-radius: 2rem;
            padding: 1.5rem 2rem;
            flex: 1;
            min-width: 150px;
            border: 1px solid rgba(255,255,255,0.9);
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: #1e3c72;
        }
        .stat-label {
            font-weight: 600;
            color: #2c577c;
        }

        /* action bar */
        .action-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .btn-primary {
            background: #1e3c72;
            border: none;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            color: white;
            font-weight: 700;
            font-size: 1rem;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #1e3c72;
            transition: 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .btn-primary:hover {
            background: #143768;
            transform: translateY(-3px);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 1rem 2.5rem;
            border-radius: 120px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        .btn-secondary:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* drives grid */
        .drives-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 1.8rem;
            margin-top: 1rem;
        }

        .drive-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 1.8rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            position: relative;
            overflow: hidden;
        }
        .drive-card:hover {
            transform: translateY(-5px);
            background: rgba(255,255,255,0.9);
        }
        .drive-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(to right, #1e3c72, #ff9f1c);
        }

        .drive-header-card {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .drive-company {
            font-size: 1.4rem;
            font-weight: 700;
            color: #0b2b4e;
        }
        .drive-status {
            padding: 0.4rem 1.2rem;
            border-radius: 60px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-active { background: #28a74520; color: #28a745; }
        .status-upcoming { background: #ffb34720; color: #b45f06; }
        .status-completed { background: #1e3c7220; color: #1e3c72; }

        .drive-details {
            margin: 1.2rem 0;
        }
        .detail-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.5rem 0;
            color: #2c577c;
        }
        .detail-item i {
            width: 24px;
            color: #1e3c72;
        }

        .drive-stats {
            display: flex;
            justify-content: space-around;
            margin: 1.5rem 0;
            padding: 1rem 0;
            border-top: 1px dashed rgba(30,60,114,0.2);
            border-bottom: 1px dashed rgba(30,60,114,0.2);
        }
        .stat-small {
            text-align: center;
        }
        .stat-small-value {
            font-size: 1.4rem;
            font-weight: 700;
            color: #1e3c72;
        }
        .stat-small-label {
            font-size: 0.85rem;
            color: #5f7d9c;
        }

        .drive-footer {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .drive-btn {
            flex: 1;
            padding: 0.8rem;
            border-radius: 60px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            transition: 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            color: #1e3c72;
            font-size: 0.9rem;
        }
        .drive-btn.primary {
            background: #1e3c72;
            color: white;
        }
        .drive-btn:hover {
            background: white;
            border-color: #1e3c72;
        }
        .drive-btn.primary:hover {
            background: #143768;
        }

        /* create drive form */
        .create-section {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 2rem;
            margin-top: 3rem;
        }
        .create-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 1.5rem;
        }
        .create-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .form-group label {
            font-weight: 600;
            color: #1a3b5c;
        }
        .form-control {
            background: rgba(255,255,255,0.9);
            border: 1px solid #cdddec;
            border-radius: 60px;
            padding: 1rem 1.5rem;
            font-family: inherit;
            outline: none;
        }
        .form-control:focus {
            border-color: #1e3c72;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="drive-wrapper">
        <!-- header -->
        <div class="drive-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-calendar-plus"></i> drive_placement.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-briefcase"></i>
            </div>
            <div>
                <h1>Drive placement</h1>
                <p>Manage campus recruitment drives</p>
            </div>
        </div>

        <!-- stats -->
        <div class="stats-row">
            <div class="stat-card">
              <div class="stat-number"><?= $active ?></div>
<div class="stat-label">Active drives</div>

<div class="stat-number"><?= $upcoming ?></div>
<div class="stat-label">Upcoming</div>

<div class="stat-number"><?= $total ?></div>
<div class="stat-label">Total drives</div>

<div class="stat-number"><?= $applications ?></div>
<div class="stat-label">Total applications</div>
            </div>
        </div>

        <!-- action bar -->
        <div class="action-bar">
            <div>
                <select style="background: rgba(255,255,255,0.8); border: 1px solid white; padding: 1rem 2rem; border-radius: 60px; font-weight: 600; color: #1e3c72; outline: none;">
                    <option>All drives</option>
                    <option>Active</option>
                    <option>Upcoming</option>
                    <option>Completed</option>
                </select>
            </div>
            <a href="#" class="btn-primary" id="showCreateForm"><i class="fas fa-plus-circle"></i> Create new drive</a>
        </div>

        <!-- drives grid -->
       <div class="drives-grid">

<?php if($drives->num_rows > 0): ?>
<?php while($d = $drives->fetch_assoc()): 

    if($d['date'] > date('Y-m-d')){
        $status = "Upcoming";
        $class = "status-upcoming";
    } elseif($d['drive_status'] == 'closed'){
        $status = "Completed";
        $class = "status-completed";
    } else {
        $status = "Active";
        $class = "status-active";
    }

?>

<div class="drive-card">
    <div class="drive-header-card">
        <span class="drive-company"><?= htmlspecialchars($d['title']) ?></span>
        <span class="drive-status <?= $class ?>">● <?= $status ?></span>
    </div>

    <div class="drive-details">
        <div class="detail-item"><i class="fas fa-briefcase"></i> <?= $d['role'] ?></div>
        <div class="detail-item"><i class="fas fa-calendar"></i> <?= date('d M Y', strtotime($d['date'])) ?></div>
        <div class="detail-item"><i class="fas fa-clock"></i> <?= date('d M Y', strtotime($d['last_date'])) ?></div>
        <div class="detail-item"><i class="fas fa-rupee-sign"></i> <?= $d['salary_package'] ?></div>
    </div>

    <div class="drive-footer">
        <a href="applications.php?drive_id=<?= $d['id'] ?>" class="drive-btn">
            Applications
        </a>
    </div>
</div>

<?php endwhile; ?>
<?php else: ?>
<p>No drives found</p>
<?php endif; ?>

</div>

            <!-- active drive -->
            <div class="drive-card">
                <div class="drive-header-card">
                    <span class="drive-company">Deloitte</span>
                    <span class="drive-status status-active">● Active</span>
                </div>
                <div class="drive-details">
                    <div class="detail-item"><i class="fas fa-briefcase"></i> Analyst / Consultant</div>
                    <div class="detail-item"><i class="fas fa-calendar"></i> Drive date: 18 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-clock"></i> Registration closes: 15 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-rupee-sign"></i> CTC: 16 - 20 LPA</div>
                </div>
                <div class="drive-stats">
                    <div class="stat-small">
                        <div class="stat-small-value">38</div>
                        <div class="stat-small-label">Applied</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">21</div>
                        <div class="stat-small-label">Shortlisted</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">6</div>
                        <div class="stat-small-label">Selected</div>
                    </div>
                </div>
                <div class="drive-footer">
                    <a href="applications.php?drive=deloitte" class="drive-btn"><i class="fas fa-users"></i> Applications</a>
                    <a href="#" class="drive-btn primary"><i class="fas fa-edit"></i> Manage</a>
                </div>
            </div>

            <!-- upcoming drive -->
            <div class="drive-card">
                <div class="drive-header-card">
                    <span class="drive-company">Amazon</span>
                    <span class="drive-status status-upcoming">⏳ Upcoming</span>
                </div>
                <div class="drive-details">
                    <div class="detail-item"><i class="fas fa-briefcase"></i> SDE I / PM</div>
                    <div class="detail-item"><i class="fas fa-calendar"></i> Drive date: 22 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-clock"></i> Registration closes: 19 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-rupee-sign"></i> CTC: 28 - 35 LPA</div>
                </div>
                <div class="drive-stats">
                    <div class="stat-small">
                        <div class="stat-small-value">57</div>
                        <div class="stat-small-label">Applied</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">0</div>
                        <div class="stat-small-label">Shortlisted</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">0</div>
                        <div class="stat-small-label">Selected</div>
                    </div>
                </div>
                <div class="drive-footer">
                    <a href="applications.php?drive=amazon" class="drive-btn"><i class="fas fa-users"></i> Applications</a>
                    <a href="#" class="drive-btn primary"><i class="fas fa-edit"></i> Manage</a>
                </div>
            </div>

            <!-- upcoming drive -->
            <div class="drive-card">
                <div class="drive-header-card">
                    <span class="drive-company">Microsoft</span>
                    <span class="drive-status status-upcoming">⏳ Upcoming</span>
                </div>
                <div class="drive-details">
                    <div class="detail-item"><i class="fas fa-briefcase"></i> Software Engineer</div>
                    <div class="detail-item"><i class="fas fa-calendar"></i> Drive date: 25 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-clock"></i> Registration closes: 22 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-rupee-sign"></i> CTC: 32 - 38 LPA</div>
                </div>
                <div class="drive-stats">
                    <div class="stat-small">
                        <div class="stat-small-value">44</div>
                        <div class="stat-small-label">Applied</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">0</div>
                        <div class="stat-small-label">Shortlisted</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">0</div>
                        <div class="stat-small-label">Selected</div>
                    </div>
                </div>
                <div class="drive-footer">
                    <a href="applications.php?drive=microsoft" class="drive-btn"><i class="fas fa-users"></i> Applications</a>
                    <a href="#" class="drive-btn primary"><i class="fas fa-edit"></i> Manage</a>
                </div>
            </div>

            <!-- completed drive -->
            <div class="drive-card">
                <div class="drive-header-card">
                    <span class="drive-company">Texas Instruments</span>
                    <span class="drive-status status-completed">✓ Completed</span>
                </div>
                <div class="drive-details">
                    <div class="detail-item"><i class="fas fa-briefcase"></i> Core Engineer</div>
                    <div class="detail-item"><i class="fas fa-calendar"></i> Drive date: 05 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-rupee-sign"></i> CTC: 12 - 15 LPA</div>
                </div>
                <div class="drive-stats">
                    <div class="stat-small">
                        <div class="stat-small-value">32</div>
                        <div class="stat-small-label">Applied</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">18</div>
                        <div class="stat-small-label">Shortlisted</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">5</div>
                        <div class="stat-small-label">Selected</div>
                    </div>
                </div>
                <div class="drive-footer">
                    <a href="#" class="drive-btn"><i class="fas fa-chart-bar"></i> Report</a>
                    <a href="#" class="drive-btn"><i class="fas fa-redo"></i> Reopen</a>
                </div>
            </div>

            <!-- completed drive -->
            <div class="drive-card">
                <div class="drive-header-card">
                    <span class="drive-company">Google</span>
                    <span class="drive-status status-completed">✓ Completed</span>
                </div>
                <div class="drive-details">
                    <div class="detail-item"><i class="fas fa-briefcase"></i> SDE / Research</div>
                    <div class="detail-item"><i class="fas fa-calendar"></i> Drive date: 01 Nov 2026</div>
                    <div class="detail-item"><i class="fas fa-rupee-sign"></i> CTC: 35 - 42 LPA</div>
                </div>
                <div class="drive-stats">
                    <div class="stat-small">
                        <div class="stat-small-value">68</div>
                        <div class="stat-small-label">Applied</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">24</div>
                        <div class="stat-small-label">Shortlisted</div>
                    </div>
                    <div class="stat-small">
                        <div class="stat-small-value">8</div>
                        <div class="stat-small-label">Selected</div>
                    </div>
                </div>
                <div class="drive-footer">
                    <a href="#" class="drive-btn"><i class="fas fa-chart-bar"></i> Report</a>
                    <a href="#" class="drive-btn"><i class="fas fa-redo"></i> Reopen</a>
                </div>
            </div>
        </div>

        <!-- create new drive section -->
        <div class="create-section">
            <div class="create-title"><i class="fas fa-plus-circle" style="margin-right: 10px;"></i> Schedule new placement drive</div>
            <form method="POST">
<div class="create-form">
                <div class="form-group">
                    <label>Company name</label>
                    <input type="text" class="form-control" placeholder="e.g., Microsoft">
                </div>
                <div class="form-group">
                    <label>Position / Role</label>
                    <input type="text" class="form-control" placeholder="e.g., SDE I">
                </div>
                <div class="form-group">
                    <label>Drive date</label>
                    <input type="date" class="form-control">
                </div>
                <div class="form-group">
                    <label>Registration deadline</label>
                    <input type="date" class="form-control">
                </div>
                <div class="form-group">
                    <label>CTC (LPA)</label>
                    <input type="text" class="form-control" placeholder="e.g., 12-15 LPA">
                </div>
                <div class="form-group">
                    <label>Eligibility criteria</label>
                    <input type="text" class="form-control" placeholder="e.g., 7.0 CGPA, CSE/IT">
                </div>
                <div class="form-group">
                    <label>Job location</label>
                    <input type="text" class="form-control" placeholder="e.g., Bangalore">
                </div>
                <div class="form-group">
                    <label>Drive mode</label>
                    <select class="form-control">
                        <option>Online</option>
                        <option>Offline</option>
                        <option>Hybrid</option>
                    </select>
                </div>
            </div>
            <div style="margin-top: 2rem; text-align: right;">
                <a href="#" class="btn-primary" style="background: #1e3c72; padding: 1rem 3rem;"><i class="fas fa-calendar-check"></i> Create drive</a>
            </div>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · drive placement management</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> drives · placement
    </div>
</body>
</html>