<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Virtual Interviews</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }

        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .interview-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        .interview-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #6f42c1, #8551d9);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: white;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #6f42c1;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* date selector */
        .date-nav {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
            background: rgba(255,255,255,0.5);
            backdrop-filter: blur(8px);
            padding: 1rem 2rem;
            border-radius: 60px;
            justify-content: space-between;
        }
        .date-display {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e3c72;
        }
        .date-arrows {
            display: flex;
            gap: 1rem;
        }
        .date-arrow {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: 0.2s;
        }
        .date-arrow:hover {
            background: #1e3c72;
            color: white;
        }

        /* interview grid */
        .interview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .interview-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2rem;
            padding: 1.8rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            position: relative;
            overflow: hidden;
        }
        .interview-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: #6f42c1;
        }
        .interview-card.completed::before {
            background: #28a745;
        }
        .interview-card.cancelled::before {
            background: #dc3545;
        }

        .interview-time {
            font-size: 1.2rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 1rem;
        }
        .interview-participants {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1rem;
        }
        .participant-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        .interview-details {
            margin: 1rem 0;
        }
        .detail-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0;
            color: #2c577c;
        }
        .interview-status {
            display: inline-block;
            padding: 0.3rem 1rem;
            border-radius: 60px;
            font-size: 0.85rem;
            font-weight: 600;
            margin: 1rem 0;
        }
        .status-scheduled { background: #6f42c120; color: #6f42c1; }
        .status-live { background: #dc354520; color: #dc3545; animation: pulse 1.5s infinite; }
        .status-completed { background: #28a74520; color: #28a745; }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }

        .interview-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .interview-btn {
            flex: 1;
            padding: 0.8rem;
            border-radius: 60px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            transition: 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            color: #1e3c72;
        }
        .interview-btn.primary {
            background: #6f42c1;
            color: white;
        }
        .interview-btn.primary:hover {
            background: #5a32a3;
        }
        .interview-btn:hover {
            background: white;
            border-color: #6f42c1;
        }

        /* schedule section */
        .schedule-section {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2.5rem;
            padding: 2rem;
            margin-top: 2rem;
        }
        .schedule-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 1.5rem;
        }
        .schedule-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .form-group label {
            font-weight: 600;
            color: #1a3b5c;
        }
        .form-control {
            background: rgba(255,255,255,0.9);
            border: 1px solid #cdddec;
            border-radius: 60px;
            padding: 1rem 1.5rem;
            font-family: inherit;
            outline: none;
        }
        .form-control:focus {
            border-color: #6f42c1;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="interview-wrapper">
        <!-- header -->
        <div class="interview-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-video"></i> virtual_interview.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-video"></i>
            </div>
            <div>
                <h1>Virtual interviews</h1>
                <p>Schedule and manage online interviews</p>
            </div>
        </div>

        <!-- date navigation -->
        <div class="date-nav">
            <div class="date-arrows">
                <div class="date-arrow"><i class="fas fa-chevron-left"></i></div>
                <div class="date-arrow"><i class="fas fa-chevron-right"></i></div>
            </div>
            <div class="date-display">Wednesday, 17 March 2026</div>
            <div style="width: 80px;"></div>
        </div>

        <!-- interview grid -->
        <div class="interview-grid">
            <!-- live interview -->
            <div class="interview-card">
                <div class="interview-time">2:30 PM - 3:30 PM</div>
                <div class="interview-participants">
                    <div class="participant-avatar">RM</div>
                    <div>
                        <div style="font-weight: 700;">Rahul Mehta</div>
                        <div style="font-size: 0.85rem;">SDE Candidate · CSE</div>
                    </div>
                </div>
                <div class="interview-details">
                    <div class="detail-item"><i class="fas fa-building"></i> Amazon SDE Drive</div>
                    <div class="detail-item"><i class="fas fa-users"></i> Interviewer: Rajesh Kumar</div>
                </div>
                <div class="interview-status status-live">🔴 Live now</div>
                <div class="interview-actions">
                    <a href="#" class="interview-btn"><i class="fas fa-info-circle"></i> Details</a>
                    <a href="#" class="interview-btn primary"><i class="fas fa-video"></i> Join</a>
                </div>
            </div>

            <!-- scheduled interview -->
            <div class="interview-card">
                <div class="interview-time">4:00 PM - 5:00 PM</div>
                <div class="interview-participants">
                    <div class="participant-avatar">SV</div>
                    <div>
                        <div style="font-weight: 700;">Shreya Verma</div>
                        <div style="font-size: 0.85rem;">Analyst Candidate · ECE</div>
                    </div>
                </div>
                <div class="interview-details">
                    <div class="detail-item"><i class="fas fa-building"></i> Deloitte Analyst</div>
                    <div class="detail-item"><i class="fas fa-users"></i> Interviewer: Priya Singh</div>
                </div>
                <div class="interview-status status-scheduled">⏳ Scheduled</div>
                <div class="interview-actions">
                    <a href="#" class="interview-btn"><i class="fas fa-edit"></i> Reschedule</a>
                    <a href="#" class="interview-btn primary"><i class="fas fa-link"></i> Get link</a>
                </div>
            </div>

            <!-- completed interview -->
            <div class="interview-card completed">
                <div class="interview-time">11:00 AM - 12:00 PM</div>
                <div class="interview-participants">
                    <div class="participant-avatar">AK</div>
                    <div>
                        <div style="font-weight: 700;">Arjun Kapoor</div>
                        <div style="font-size: 0.85rem;">SDE Candidate · IT</div>
                    </div>
                </div>
                <div class="interview-details">
                    <div class="detail-item"><i class="fas fa-building"></i> Microsoft SDE</div>
                    <div class="detail-item"><i class="fas fa-star"></i> Feedback: Positive</div>
                </div>
                <div class="interview-status status-completed">✅ Completed</div>
                <div class="interview-actions">
                    <a href="#" class="interview-btn"><i class="fas fa-clipboard"></i> Feedback</a>
                    <a href="#" class="interview-btn"><i class="fas fa-redo"></i> Schedule next</a>
                </div>
            </div>
        </div>

        <!-- schedule new interview -->
        <div class="schedule-section">
            <div class="schedule-title"><i class="fas fa-plus-circle" style="margin-right: 10px;"></i> Schedule new interview</div>
            <div class="schedule-form">
                <div class="form-group">
                    <label>Candidate</label>
                    <select class="form-control">
                        <option>Select candidate</option>
                        <option>Rahul Mehta (SDE)</option>
                        <option>Shreya Verma (Analyst)</option>
                        <option>Arjun Kapoor (SDE)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" class="form-control" value="2026-03-18">
                </div>
                <div class="form-group">
                    <label>Time</label>
                    <input type="time" class="form-control" value="14:00">
                </div>
                <div class="form-group">
                    <label>Duration</label>
                    <select class="form-control">
                        <option>30 minutes</option>
                        <option selected>1 hour</option>
                        <option>1.5 hours</option>
                        <option>2 hours</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Interviewer</label>
                    <input type="text" class="form-control" value="Rajesh Kumar">
                </div>
                <div class="form-group">
                    <label>Platform</label>
                    <select class="form-control">
                        <option selected>Google Meet</option>
                        <option>Zoom</option>
                        <option>Microsoft Teams</option>
                        <option>Custom</option>
                    </select>
                </div>
            </div>
            <div style="margin-top: 2rem; text-align: right;">
                <a href="#" class="btn-primary" style="background: #6f42c1; padding: 1rem 3rem; border-radius: 60px; color: white; text-decoration: none; display: inline-flex; align-items: center; gap: 10px;"><i class="fas fa-calendar-plus"></i> Schedule interview</a>
            </div>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · virtual interview management</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> interviews · virtual
    </div>
</body>
</html>