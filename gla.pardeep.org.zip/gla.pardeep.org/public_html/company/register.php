<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../api/mail/mailer.php';

function generateCompanyUID($conn){
    $result = $conn->query("SELECT id FROM companies ORDER BY id DESC LIMIT 1");
    $nextId = ($result && $row = $result->fetch_assoc()) ? $row['id'] + 1 : 1;
    return 'COMP' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
}

$success = false;
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $company_name = trim($_POST['company_name']);
    $industry     = trim($_POST['industry']);
    $hr_name      = trim($_POST['hr_name']);
    $email        = trim($_POST['email']);
    $phone        = trim($_POST['phone']);
    $password     = $_POST['password'];
$confirm      = $_POST['confirm_password'];

if($password !== $confirm){
    $error = "Passwords do not match";
}
elseif(!isset($_POST['terms'])){
    $error = "Please accept Terms & Conditions";
}
else{

    // Duplicate Email Check
        $stmt = $conn->prepare("SELECT id FROM companies WHERE email=? LIMIT 1");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows > 0){
            $error = "Email already registered";
        }
        else{

            $company_uid = generateCompanyUID($conn);
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $ip = $_SERVER['REMOTE_ADDR'];

            $stmt = $conn->prepare("INSERT INTO companies 
                (company_uid, company_name, industry, hr_name, email, phone, password, status, register_ip) 
                VALUES (?,?,?,?,?,?,?, 'email_not_verified', ?)");
            $stmt->bind_param("ssssssss", $company_uid,$company_name,$industry,$hr_name,$email,$phone,$hashed,$ip);

            if($stmt->execute()){
                $company_id = $stmt->insert_id;

                $token = bin2hex(random_bytes(32));
                $expires = date("Y-m-d H:i:s", strtotime("+30 minutes"));

                $stmt2 = $conn->prepare("INSERT INTO company_email_verification (company_id, token, expires_at) VALUES (?,?,?)");
                $stmt2->bind_param("iss",$company_id,$token,$expires);
                $stmt2->execute();

                sendCompanyVerificationMail($email,$hr_name,$company_name,$token);

                $success = true;
            }
            else{
                $error = "Registration failed. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Register Company</title>
    <!-- Font Awesome 5 -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <!-- Google Fonts: Inter & Poppins (same as original) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #f0f5fe 0%, #e9f0fa 100%);
            min-height: 100vh;
            color: #1e293b;
            line-height: 1.5;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .dot-pattern {
            background: radial-gradient(#1e3c72 2px, transparent 2px);
            background-size: 25px 25px;
            opacity: 0.2;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            pointer-events: none;
            z-index: -1;
        }

        .container {
            width: 100%;
            max-width: 560px;
            padding: 20px;
            margin: 20px;
        }

        .back-home {
            margin-bottom: 20px;
            display: inline-block;
            color: #1e3c72;
            text-decoration: none;
            font-weight: 500;
            background: rgba(255,255,255,0.5);
            padding: 8px 20px;
            border-radius: 40px;
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255,255,255,0.7);
            transition: 0.2s;
        }
        .back-home i {
            margin-right: 6px;
        }
        .back-home:hover {
            background: white;
            transform: translateX(-3px);
        }

        .register-card {
            background: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(12px);
            border-radius: 50px;
            padding: 45px 40px;
            box-shadow: 0 30px 50px -20px rgba(0,45,75,0.3);
            border: 1px solid rgba(255,255,255,0.7);
            width: 100%;
        }

        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .register-header .logo-icon {
            background: #1e3c72;
            color: white;
            width: 70px;
            height: 70px;
            border-radius: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            margin: 0 auto 15px;
            box-shadow: 0 10px 20px rgba(0,35,70,0.2);
        }
        .register-header h2 {
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            font-size: 2rem;
            background: linear-gradient(135deg, #0b2b4e, #2a5a8c);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 5px;
        }
        .register-header p {
            color: #2c4e72;
            font-size: 1rem;
            font-weight: 500;
        }
        .register-header .role-badge {
            background: rgba(255, 180, 70, 0.2);
            color: #ffb347;
            padding: 5px 15px;
            border-radius: 40px;
            display: inline-block;
            margin-top: 10px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 22px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1a3b5c;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
        }
        .input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        .input-wrapper i {
            position: absolute;
            left: 18px;
            color: #1e4c7a;
            font-size: 1.2rem;
            opacity: 0.8;
            z-index: 2;
        }
        .input-wrapper input,
        .input-wrapper select {
            width: 100%;
            padding: 16px 20px 16px 52px;
            border: 2px solid rgba(255,255,255,0.9);
            border-radius: 60px;
            font-size: 1rem;
            background: rgba(255,255,255,0.8);
            backdrop-filter: blur(4px);
            transition: 0.2s;
            font-family: 'Inter', sans-serif;
            outline: none;
            color: #0b2b4e;
            font-weight: 500;
            appearance: none;
        }
        .input-wrapper select {
            cursor: pointer;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%231e4c7a' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 20px center;
            background-size: 16px;
        }
        .input-wrapper input:focus,
        .input-wrapper select:focus {
            border-color: #1e3c72;
            background: white;
            box-shadow: 0 8px 16px -8px #1e3c7240;
        }
        .input-wrapper input::placeholder {
            color: #6f8fae;
            font-weight: 400;
        }

        .checkbox-group {
            margin: 25px 0 30px;
        }
        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
            color: #1a3b5c;
            cursor: pointer;
        }
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            accent-color: #1e3c72;
            border-radius: 6px;
            cursor: pointer;
        }

        .register-submit {
            width: 100%;
            background: linear-gradient(105deg, #1e3c72, #143157);
            border: none;
            padding: 16px;
            border-radius: 60px;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            transition: 0.25s;
            border: 1px solid #6387b1;
            box-shadow: 0 10px 20px -8px #0b2b4e;
            margin-bottom: 25px;
        }
        .register-submit:hover {
            background: linear-gradient(105deg, #143157, #0b2341);
            transform: translateY(-2px);
            box-shadow: 0 18px 25px -10px #0b2b4e;
        }

        .login-prompt {
            text-align: center;
            border-top: 2px dashed rgba(30, 60, 114, 0.15);
            padding-top: 25px;
        }
        .login-prompt p {
            color: #1f4468;
            font-weight: 500;
            margin-bottom: 8px;
        }
        .login-link {
            background: rgba(255,255,255,0.8);
            border: 2px solid #b9d3f0;
            border-radius: 60px;
            padding: 12px 30px;
            font-weight: 600;
            color: #1e3c72;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: 0.2s;
        }
        .login-link:hover {
            background: white;
            border-color: #1e3c72;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 50px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
            border: 1px solid #c3e6cb;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .version-note {
            text-align: center;
            margin-top: 20px;
            font-size: 0.85rem;
            color: #1d4a79;
            background: rgba(255,255,255,0.3);
            padding: 8px 20px;
            border-radius: 60px;
            backdrop-filter: blur(4px);
            display: inline-block;
            width: auto;
        }

        .company-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" opacity="0.1"><rect x="20" y="30" width="60" height="40" fill="%231e3c72"/><rect x="35" y="20" width="30" height="20" fill="%23ffb347"/></svg>') repeat;
            pointer-events: none;
            z-index: -1;
        }
    </style>
</head>
<body>
    <div class="dot-pattern"></div>
    <div class="company-bg"></div>

    <div class="container">
        <a href="index.php" class="back-home"><i class="fas fa-arrow-left"></i> Back to Home</a>

        <!-- Company Registration Card (standalone) -->
        <div class="register-card">
            <div class="register-header">
            <?php if($success): ?>
<div class="success-message">
    <i class="fas fa-check-circle"></i>
    Registration successful! Please check your email for verification.
</div>
<script>
setTimeout(()=>{ window.location.href='/company'; },3000);
</script>
<?php endif; ?>

<?php if($error): ?>
<div style="background:#f8d7da;color:#721c24;padding:15px;border-radius:50px;margin-bottom:20px;text-align:center;">
    <i class="fas fa-times-circle"></i> <?= $error ?>
</div>
<?php endif; ?>
                <div class="logo-icon">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h2>Company Registration</h2>
                <p>Register your company for placements</p>
                <div class="role-badge">
                    <i class="fas fa-briefcase"></i> New Company
                </div>
            </div>

            <form method="POST">
                <!-- Company Name -->
                <div class="form-group">
                    <label><i class="fas fa-building" style="margin-right: 6px;"></i> Company Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-building"></i>
                       <input type="text" id="companyName" name="company_name" placeholder="e.g., Microsoft, Google" required>
                    </div>
                </div>

                

                <!-- Industry Type -->
                <div class="form-group">
                    <label><i class="fas fa-industry" style="margin-right: 6px;"></i> Industry Type</label>
                    <div class="input-wrapper">
                        <i class="fas fa-industry"></i>
                        <select id="industry" name="industry" required>
                            <option value="" disabled selected>Select industry</option>
                            <option value="IT">IT Services</option>
                            <option value="Banking">Banking & Finance</option>
                            <option value="Consulting">Consulting</option>
                            <option value="Manufacturing">Manufacturing</option>
                            <option value="Retail">Retail</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Education">Education</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>

                <!-- HR Contact Name -->
                <div class="form-group">
                    <label><i class="fas fa-user-tie" style="margin-right: 6px;"></i> HR Contact Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-tie"></i>
                        <input type="text" id="hrName" name="hr_name" placeholder="Full name of HR" required>
                    </div>
                </div>

                <!-- HR Email -->
                <div class="form-group">
                    <label><i class="fas fa-envelope" style="margin-right: 6px;"></i> HR Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder="hr@company.com" required>
                    </div>
                </div>

                <!-- HR Phone -->
                <div class="form-group">
                    <label><i class="fas fa-phone" style="margin-right: 6px;"></i> HR Phone</label>
                    <div class="input-wrapper">
                        <i class="fas fa-phone"></i>
                        <input type="tel" id="phone" name="phone" placeholder="+91 98765 43210" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label><i class="fas fa-lock" style="margin-right: 6px;"></i> Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" id="password" name="password" placeholder="Min. 8 characters" required>
                    </div>
                </div>

                <!-- Confirm Password -->
                <div class="form-group">
                    <label><i class="fas fa-check-circle" style="margin-right: 6px;"></i> Confirm Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-check-circle"></i>
                        <input type="password" id="confirmPassword" name="confirm_password" placeholder="Re-enter password" required>
                    </div>
                </div>

                <!-- Terms and conditions -->
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" name="terms" required>
                        <span>I agree to the <a href="#" style="color:#1e3c72; font-weight:600;">Terms & Conditions</a> and <a href="#" style="color:#1e3c72;">Privacy Policy</a>.</span>
                    </label>
                </div>

                <button type="submit" class="register-submit">
                    <i class="fas fa-building"></i> Register Company
                </button>

                <div class="login-prompt">
                    <p>Already have a company account?</p>
                    <a href="company_login.php" class="login-link">
                        <i class="fas fa-sign-in-alt"></i> Sign in
                    </a>
                </div>
            </form>
        </div>

        <div style="text-align: center; margin-top: 20px;">
            <span class="version-note"><i class="fas fa-shield-alt"></i> GLA University SPMS · Register your company</span>
        </div>
    </div>

   

    <div style="position: fixed; bottom: 10px; right: 20px; background: white; padding: 5px 20px; border-radius: 60px; font-size: 0.8rem; border: 1px solid #ccc; z-index: 99;">
        <i class="fas fa-building" style="color: #1e3c72;"></i> Register · Company
    </div>
</body>
</html>