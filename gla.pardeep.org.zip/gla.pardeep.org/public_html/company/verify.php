<?php
require_once '../config/db.php';

if(!isset($_GET['token'])){
    die("Invalid verification link");
}

$token = $_GET['token'];

$stmt = $conn->prepare("SELECT company_id FROM company_email_verification WHERE token=? AND expires_at > NOW()");
$stmt->bind_param("s",$token);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows == 0){
    die("Link expired or invalid");
}

$stmt->bind_result($company_id);
$stmt->fetch();

$conn->query("UPDATE companies SET status='active' WHERE id=$company_id");
$conn->query("DELETE FROM company_email_verification WHERE company_id=$company_id");

echo "Email verified successfully. You can login now.";
?>