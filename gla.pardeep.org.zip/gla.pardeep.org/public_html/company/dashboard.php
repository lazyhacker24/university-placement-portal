<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../config/session.php'; 
require_once '../config/db.php';

if(!isset($_SESSION['company_id'])){
    die("Company not logged in");
}

$company_id = intval($_SESSION['company_id']);

// ================= COMPANY DATA =================
$stmt = $conn->prepare("SELECT * FROM companies WHERE id=?");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();

// ================= STATS =================
$drivesCount = $conn->query("SELECT COUNT(*) as total FROM placement_drives WHERE company_id=$company_id")->fetch_assoc()['total'];

$appCount = $conn->query("SELECT COUNT(*) as total FROM applications WHERE company_id=$company_id")->fetch_assoc()['total'];

$shortCount = $conn->query("SELECT COUNT(*) as total FROM applications WHERE status='shortlisted' AND company_id=$company_id")->fetch_assoc()['total'];

$selectedCount = $conn->query("SELECT COUNT(*) as total FROM applications WHERE status='selected' AND company_id=$company_id")->fetch_assoc()['total'];

// ================= RECENT DRIVES =================
$drives = $conn->query("SELECT title, date FROM placement_drives 
WHERE company_id=$company_id 
ORDER BY id DESC LIMIT 5");
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Dashboard</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f5f7fb;
            color: #1e293b;
            min-height: 100vh;
        }

        /* main layout */
        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* ========== SIDEBAR - REDESIGNED ========== */
        .sidebar {
            width: 280px;
            background: white;
            box-shadow: 4px 0 20px rgba(0,0,0,0.02);
            padding: 2rem 1.2rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
        }

        /* brand section */
        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 2rem;
            padding: 0 0.5rem;
        }
        .brand-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #1e3c72, #2a5a9c);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.8rem;
            box-shadow: 0 8px 16px -8px #1e3c72;
        }
        .brand-text h2 {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1e3c72;
            line-height: 1.3;
        }
        .brand-text p {
            font-size: 0.75rem;
            color: #64748b;
            letter-spacing: 0.3px;
        }

        /* company badge */
        .company-badge {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            border: 1px solid #e2e8f0;
            border-radius: 60px;
            padding: 0.8rem 1.2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .company-avatar {
            width: 36px;
            height: 36px;
            background: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
            font-size: 1.2rem;
            box-shadow: 0 4px 8px -4px #94a3b8;
        }
        .company-info h4 {
            font-size: 0.95rem;
            font-weight: 700;
            color: #1e293b;
        }
        .company-info span {
            font-size: 0.7rem;
            color: #64748b;
        }

        /* navigation menu */
        .nav-menu {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            overflow-y: auto;
            padding-right: 0.3rem;
        }
        .nav-menu::-webkit-scrollbar {
            width: 4px;
        }
        .nav-menu::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }
        .nav-menu::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        .nav-item {
            list-style: none;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.85rem 1.2rem;
            border-radius: 12px;
            color: #475569;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 0.95rem;
        }
        .nav-link i {
            width: 24px;
            font-size: 1.2rem;
            color: #64748b;
            transition: all 0.2s;
        }
        .nav-link:hover {
            background: #f8fafc;
            color: #1e3c72;
        }
        .nav-link:hover i {
            color: #1e3c72;
        }
        .nav-item.active .nav-link {
            background: linear-gradient(135deg, #1e3c72, #2a5a9c);
            color: white;
            box-shadow: 0 8px 16px -8px #1e3c72;
        }
        .nav-item.active .nav-link i {
            color: white;
        }

        /* logout section - now clearly visible */
        .logout-section {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 2px solid #e2e8f0;
        }
        .logout-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.85rem 1.2rem;
            border-radius: 12px;
            color: #b91c1c;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
            background: #fee2e2;
        }
        .logout-link i {
            width: 24px;
            font-size: 1.2rem;
            color: #b91c1c;
        }
        .logout-link:hover {
            background: #fecaca;
            transform: translateY(-2px);
        }

        /* weather widget */
        .weather-widget {
            margin-top: 1.5rem;
            padding: 1rem 1.2rem;
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .weather-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .weather-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.3rem;
        }
        .weather-temp {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1e293b;
        }
        .weather-desc {
            font-size: 0.75rem;
            color: #64748b;
        }

        /* ========== MAIN CONTENT ========== */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem 2.5rem;
            background: #f8fafc;
            min-height: 100vh;
        }

        /* top bar */
        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            background: white;
            padding: 1rem 2rem;
            border-radius: 60px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.02);
            border: 1px solid #e2e8f0;
        }
        .page-title {
            font-weight: 700;
            font-size: 1.3rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .page-title i {
            color: #f59e0b;
        }
        .date-badge {
            background: #f1f5f9;
            padding: 0.5rem 1.5rem;
            border-radius: 60px;
            font-weight: 500;
            color: #475569;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }

        /* stats grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.2rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            border-radius: 1.5rem;
            padding: 1.2rem 1.5rem;
            border: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(0,0,0,0.02);
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px -12px #1e3c72;
        }
        .stat-icon {
            width: 48px;
            height: 48px;
            background: #f1f5f9;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
            font-size: 1.5rem;
        }
        .stat-info h3 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1;
        }
        .stat-info p {
            color: #64748b;
            font-weight: 500;
            font-size: 0.85rem;
        }

        /* dashboard grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
        }

        .card {
            background: white;
            border-radius: 1.8rem;
            padding: 1.5rem;
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(0,0,0,0.02);
        }
        .card:hover {
            box-shadow: 0 12px 24px -12px #94a3b8;
        }

        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.2rem;
        }
        .card-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 1.1rem;
            color: #1e293b;
        }
        .card-title i {
            color: #f59e0b;
        }
        .card-badge {
            background: #f1f5f9;
            padding: 0.3rem 1rem;
            border-radius: 60px;
            font-size: 0.75rem;
            font-weight: 600;
            color: #475569;
        }

        .drive-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.8rem 0;
            border-bottom: 1px solid #e2e8f0;
        }
        .drive-item:last-child {
            border-bottom: none;
        }
        .drive-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .drive-icon {
            width: 32px;
            height: 32px;
            background: #f1f5f9;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
        }
        .drive-name {
            font-weight: 500;
            color: #1e293b;
        }
        .drive-date {
            font-size: 0.75rem;
            color: #64748b;
        }

        .progress-section {
            margin: 1rem 0;
        }
        .progress-label {
            display: flex;
            justify-content: space-between;
            font-size: 0.85rem;
            font-weight: 500;
            margin-bottom: 0.3rem;
        }
        .progress-bar {
            background: #e2e8f0;
            height: 8px;
            border-radius: 60px;
            overflow: hidden;
        }
        .progress-fill {
            height: 8px;
            background: linear-gradient(to right, #1e3c72, #f59e0b);
            border-radius: 60px;
            width: 68%;
        }

        .profile-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        .profile-avatar {
            width: 60px;
            height: 60px;
            background: #f1f5f9;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: #1e3c72;
        }
        .profile-details h4 {
            font-size: 1.1rem;
            font-weight: 600;
            color: #1e293b;
        }
        .profile-details p {
            color: #64748b;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 5px;
            margin: 0.2rem 0;
        }

        .contact-info {
            background: #f8fafc;
            padding: 0.8rem 1rem;
            border-radius: 60px;
            margin: 1rem 0;
            font-size: 0.85rem;
        }
        .contact-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #475569;
        }

        .simple-count {
            text-align: center;
            padding: 1.5rem;
            background: #f8fafc;
            border-radius: 1.5rem;
            margin: 0.5rem 0;
        }
        .count-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: #1e3c72;
            line-height: 1;
        }
        .count-label {
            color: #64748b;
            font-weight: 500;
            font-size: 0.85rem;
        }

        .schedule-btn {
            width: 100%;
            margin-top: 1rem;
            background: #1e3c72;
            border: none;
            padding: 0.9rem;
            border-radius: 60px;
            color: white;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 0.9rem;
        }
        .schedule-btn:hover {
            background: #2a5a9c;
            transform: translateY(-2px);
            box-shadow: 0 8px 16px -8px #1e3c72;
        }

        .card-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #1e3c72;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem;
            border-radius: 60px;
            background: #f8fafc;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        .card-link:hover {
            background: #1e3c72;
            color: white;
        }

        .footer-note {
            text-align: center;
            margin-top: 2rem;
            color: #64748b;
            font-size: 0.8rem;
        }

        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- ========== SIDEBAR - ALL OPTIONS VISIBLE ========== -->
        <aside class="sidebar">
            <!-- Brand -->
            <div class="brand">
                <div class="brand-icon">
                    <i class="fas fa-university"></i>
                </div>
                <div class="brand-text">
                    <h2>GLA SPMS</h2>
                    <p>company portal</p>
                </div>
            </div>

            <!-- Company Info -->
            <div class="company-badge">
                <div class="company-avatar">
                    <i class="fas fa-building"></i>
                </div>
                <div class="company-info">
                    <h4><?= htmlspecialchars($company['company_name'] ?? 'Company') ?></h4>
<span><?= htmlspecialchars($company['industry'] ?? 'Industry') ?></span>
                </div>
            </div>

            <!-- Navigation Menu - ALL OPTIONS CLEARLY VISIBLE -->
            <ul class="nav-menu">
                <li class="nav-item active">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-chart-pie"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="drive_placement.php" class="nav-link">
                        <i class="fas fa-calendar-plus"></i>
                        <span>Drive placement</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orient_section.php" class="nav-link">
                        <i class="fas fa-compass"></i>
                        <span>Orient section</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link">
                        <i class="fas fa-id-card"></i>
                        <span>Profile</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="applications.php" class="nav-link">
                        <i class="fas fa-file-signature"></i>
                        <span>Applications</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="shortlisted.php" class="nav-link">
                        <i class="fas fa-list-check"></i>
                        <span>Shortlisted</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="selected.php" class="nav-link">
                        <i class="fas fa-user-graduate"></i>
                        <span>Selected</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="virtual_interview.php" class="nav-link">
                        <i class="fas fa-video"></i>
                        <span>Virtual interview</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="notifications.php" class="nav-link">
                        <i class="fas fa-bell"></i>
                        <span>Notifications</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-sliders"></i>
                        <span>Settings</span>
                    </a>
                </li>
            </ul>

            <!-- Logout Section - PROMINENTLY VISIBLE -->
            <div class="logout-section">
                <a href="logout.php" class="logout-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>

            <!-- Weather Widget (from screenshot) -->
            <div class="weather-widget">
                <div class="weather-info">
                    <div class="weather-icon">
                        <i class="fas fa-sun"></i>
                    </div>
                    <div>
                        <div class="weather-temp">25°C</div>
                        <div class="weather-desc">Mostly sunny</div>
                    </div>
                </div>
                <i class="fas fa-chevron-right" style="color: #94a3b8;"></i>
            </div>
        </aside>

        <!-- ========== MAIN CONTENT ========== -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="page-title">
                    <i class="fas fa-home"></i>
                    Dashboard Overview
                </div>
                <div class="date-badge">
                    <i class="far fa-calendar"></i>
                    17 March 2026
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                    <div class="stat-info">
                        <h3><?= $drivesCount ?></h3>
                        <p>Active drives</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <h3><?= $appCount ?></h3>
                        <p>Applications</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-star"></i></div>
                    <div class="stat-info">
                        <h3><?= $shortCount ?></h3>
                        <p>Shortlisted</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-info">
                        <h3><?= $selectedCount ?></h3>
                        <p>Selected</p>
                    </div>
                </div>
            </div>

            <!-- Dashboard Grid -->
            <div class="dashboard-grid">
                <!-- Drive Placement -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-calendar-plus"></i> Drive placement</span>
                        <span class="card-badge"><?= $drivesCount ?> active</span>
                    </div>
                   <?php if($drives->num_rows > 0): ?>
    <?php while($d = $drives->fetch_assoc()): ?>
        <div class="drive-item">
            <div class="drive-info">
                <div class="drive-icon">
                    <i class="fas fa-briefcase"></i>
                </div>
                <div>
                    <div class="drive-name">
                        <?= htmlspecialchars($d['title']) ?>
                    </div>
                    <div class="drive-date">
                        <?= date('d M Y', strtotime($d['date'])) ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p style="color:#64748b;">No drives found</p>
<?php endif; ?>
</div>

                <!-- Orient Section -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-compass"></i> Orient section</span>
                    </div>
                    <div class="progress-section">
                        <div class="progress-label">
                            <span>Pre‑placement talk progress</span>
                            <span>68%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill"></div>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin: 1rem 0; color: #64748b;">
                        <span><i class="fas fa-check-circle" style="color: #22c55e;"></i> 3 sessions done</span>
                        <span><i class="far fa-clock"></i> 2 remaining</span>
                    </div>
                    <a href="orient_section.php" class="card-link">manage orientation</a>
                </div>

                <!-- Company Profile -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-id-card"></i> Company profile</span>
                    </div>
                    <div class="profile-info">
                        <div class="profile-avatar">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="profile-details">
                            <h4><?= htmlspecialchars($company['company_name']) ?></h4>
<p><i class="fas fa-map-pin"></i> <?= $company['location'] ?? 'India' ?></p>
<p><i class="fas fa-globe"></i> <?= $company['industry'] ?? '' ?></p>
                        </div>
                    </div>
                    <div class="contact-info">
                        <div class="contact-item"><i class="fas fa-envelope"></i> <?= $company['email'] ?? 'No email' ?>
</div>
                        <div class="contact-item"><i class="fas fa-phone"></i> <?= $company['phone'] ?? 'No phone' ?></div>
                    </div>
                    <a href="profile.php" class="card-link">edit profile</a>
                </div>

                <!-- Schedule New Drive -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-plus-circle"></i> Schedule new drive</span>
                    </div>
                    <p style="color: #64748b; font-size: 0.9rem; margin: 1rem 0;">Create a new placement drive for upcoming recruitment</p>
                    <a href="drive_placement.php" class="schedule-btn">
                        <i class="fas fa-calendar-plus"></i> Schedule now
                    </a>
                </div>

                <!-- Applications -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-file-signature"></i> Applications</span>
                    </div>
                    <div class="simple-count">
                        <div class="count-number"><?= $appCount ?></div>
                        <div class="count-label">total applications</div>
                    </div>
                    <a href="applications.php" class="card-link">view details</a>
                </div>

                <!-- Shortlisted -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title"><i class="fas fa-list-check"></i> Shortlisted</span>
                    </div>
                    <div class="simple-count">
                        <div class="count-number"><?= $shortCount ?></div>
                        <div class="count-label">shortlisted candidates</div>
                    </div>
                    <a href="shortlisted.php" class="card-link">view details</a>
                </div>
            </div>

            <!-- Footer -->
            <div class="footer-note">
                <i class="fas fa-shield-alt"></i> GLA SPMS · secure company portal
            </div>
        </main>
    </div>

    <script>
        // Highlight active nav item
        const currentPage = window.location.pathname.split('/').pop() || 'dashboard.php';
        const navItems = document.querySelectorAll('.nav-item');
        
        navItems.forEach(item => {
            const link = item.querySelector('.nav-link');
            if(link) {
                const href = link.getAttribute('href');
                if(href === currentPage) {
                    item.classList.add('active');
                } else {
                    item.classList.remove('active');
                }
            }
        });
    </script>
</body>
</html>