<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Shortlisted Candidates</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        /* Same base styles as applications.php */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f0f5fc;
            color: #111827;
            min-height: 100vh;
            line-height: 1.5;
        }
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.12) 0%, transparent 65%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 700px;
            height: 700px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.07) 0%, transparent 70%);
            bottom: -250px;
            right: -200px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.04) 1px, transparent 1px);
            background-size: 70px 70px;
            z-index: -1;
        }

        .shortlisted-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 5;
        }

        /* header */
        .shortlisted-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            padding: 0.8rem 2rem;
            border-radius: 120px;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .back-link {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.8rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .page-badge {
            background: linear-gradient(145deg, #ffb347, #ff9f1c);
            padding: 0.5rem 2rem;
            border-radius: 60px;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1e2b3c;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .page-badge i {
            margin-right: 6px;
        }

        .title-section {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 20px 30px -12px #1e3c7240;
        }
        .icon-ring i {
            font-size: 3rem;
            color: #1e3c72;
        }
        .title-section h1 {
            font-size: 2.8rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* tabs */
        .drive-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .drive-tab {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            border: 1px solid white;
            cursor: pointer;
            transition: 0.2s;
        }
        .drive-tab.active {
            background: #1e3c72;
            color: white;
        }
        .drive-tab:hover {
            background: white;
            border-color: #1e3c72;
        }

        /* shortlisted grid */
        .candidates-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .candidate-card {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(16px);
            border-radius: 2rem;
            padding: 1.8rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
        }
        .candidate-card:hover {
            transform: translateY(-5px);
            background: rgba(255,255,255,0.9);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 1.5rem;
        }
        .candidate-avatar {
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e3c72;
        }
        .candidate-name h3 {
            font-size: 1.4rem;
            font-weight: 700;
            color: #0b2b4e;
        }
        .candidate-name p {
            color: #5f7d9c;
            font-weight: 500;
        }

        .candidate-details {
            margin: 1rem 0;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px dashed rgba(30,60,114,0.1);
        }
        .detail-label {
            font-weight: 600;
            color: #1a3b5c;
        }
        .detail-value {
            color: #2c577c;
        }

        .card-actions {
            display: flex;
            gap: 0.8rem;
            margin-top: 1.5rem;
        }
        .action-btn {
            flex: 1;
            background: rgba(255,255,255,0.8);
            border: 1px solid white;
            padding: 0.8rem;
            border-radius: 60px;
            font-weight: 600;
            color: #1e3c72;
            cursor: pointer;
            transition: 0.2s;
            text-align: center;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .action-btn.primary {
            background: #1e3c72;
            color: white;
        }
        .action-btn:hover {
            background: white;
            border-color: #1e3c72;
        }
        .action-btn.primary:hover {
            background: #143768;
        }

        .footer-note {
            margin-top: 3rem;
            text-align: center;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="shortlisted-wrapper">
        <!-- header -->
        <div class="shortlisted-header">
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <span class="page-badge"><i class="fas fa-list-check"></i> shortlisted.php</span>
        </div>

        <!-- title -->
        <div class="title-section">
            <div class="icon-ring">
                <i class="fas fa-star"></i>
            </div>
            <div>
                <h1>Shortlisted candidates</h1>
                <p>24 candidates shortlisted across all drives</p>
            </div>
        </div>

        <!-- drive tabs -->
        <div class="drive-tabs">
            <div class="drive-tab active">All drives (24)</div>
            <div class="drive-tab">Infosys SDE (8)</div>
            <div class="drive-tab">Deloitte Analyst (6)</div>
            <div class="drive-tab">Amazon SDE (5)</div>
            <div class="drive-tab">Microsoft (5)</div>
        </div>

        <!-- candidates grid -->
        <div class="candidates-grid">
            <!-- candidate 1 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">NK</div>
                    <div class="candidate-name">
                        <h3>Neha Kapoor</h3>
                        <p>CSE · 9.2 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345088</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Microsoft SDE</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #ffb34720; padding: 0.2rem 1rem; border-radius: 60px;">Interview stage</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>

            <!-- candidate 2 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">AV</div>
                    <div class="candidate-name">
                        <h3>Ankit Verma</h3>
                        <p>IT · 9.2 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345117</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Amazon SDE</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #1e3c7220; padding: 0.2rem 1rem; border-radius: 60px;">Screening</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>

            <!-- candidate 3 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">RS</div>
                    <div class="candidate-name">
                        <h3>Rahul Sharma</h3>
                        <p>CSE · 8.9 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345001</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Infosys SDE</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #28a74520; padding: 0.2rem 1rem; border-radius: 60px;">Shortlisted</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>

            <!-- candidate 4 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">PM</div>
                    <div class="candidate-name">
                        <h3>Priya Mehta</h3>
                        <p>ECE · 8.7 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345042</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Deloitte Analyst</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #ffb34720; padding: 0.2rem 1rem; border-radius: 60px;">Interview stage</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>

            <!-- candidate 5 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">SK</div>
                    <div class="candidate-name">
                        <h3>Sneha Kapoor</h3>
                        <p>CSE · 8.5 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345088</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Microsoft SDE</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #28a74520; padding: 0.2rem 1rem; border-radius: 60px;">Shortlisted</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>

            <!-- candidate 6 -->
            <div class="candidate-card">
                <div class="card-header">
                    <div class="candidate-avatar">NT</div>
                    <div class="candidate-name">
                        <h3>Neha Tiwari</h3>
                        <p>CSE · 9.4 CGPA</p>
                    </div>
                </div>
                <div class="candidate-details">
                    <div class="detail-row">
                        <span class="detail-label">Roll No.</span>
                        <span class="detail-value">2112345056</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Drive</span>
                        <span class="detail-value">Google SDE</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status</span>
                        <span class="detail-value"><span style="background: #ffb34720; padding: 0.2rem 1rem; border-radius: 60px;">Interview stage</span></span>
                    </div>
                </div>
                <div class="card-actions">
                    <a href="#" class="action-btn"><i class="fas fa-eye"></i> Profile</a>
                    <a href="#" class="action-btn primary"><i class="fas fa-video"></i> Schedule</a>
                </div>
            </div>
        </div>

        <!-- pagination -->
        <div style="display: flex; justify-content: center; gap: 0.5rem; margin-top: 2rem;">
            <a href="#" class="page-link" style="background: rgba(255,255,255,0.6); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #1e3c72;"><i class="fas fa-chevron-left"></i></a>
            <a href="#" class="page-link" style="background: #1e3c72; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none;">1</a>
            <a href="#" class="page-link" style="background: rgba(255,255,255,0.6); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #1e3c72;">2</a>
            <a href="#" class="page-link" style="background: rgba(255,255,255,0.6); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #1e3c72;">3</a>
            <a href="#" class="page-link" style="background: rgba(255,255,255,0.6); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #1e3c72;"><i class="fas fa-chevron-right"></i></a>
        </div>

        <!-- footer note -->
        <div style="text-align: center; margin-top: 3rem;">
            <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · shortlisted candidates</span>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> shortlisted · interview ready
    </div>
</body>
</html>