<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA · Forgot password</title>
    <!-- Font Awesome 6 (free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f2f5fb;
            color: #111827;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            line-height: 1.5;
        }

        /* glass background + abstract shapes (identical to login) */
        .bg-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -2;
            overflow: hidden;
        }
        .shape-1 {
            position: absolute;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle at 30% 50%, rgba(0,81,155,0.15) 0%, transparent 60%);
            top: -150px;
            left: -100px;
            border-radius: 50%;
        }
        .shape-2 {
            position: absolute;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle at 70% 20%, rgba(255,140,0,0.08) 0%, transparent 70%);
            bottom: -200px;
            right: -150px;
            border-radius: 50%;
        }
        .grid-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(30,60,114,0.06) 1px, transparent 1px),
                linear-gradient(90deg, rgba(30,60,114,0.06) 1px, transparent 1px);
            background-size: 60px 60px;
            z-index: -1;
        }

        .login-wrapper {
            max-width: 1320px;
            width: 100%;
            padding: 2rem;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 3rem;
            box-shadow: 
                0 35px 68px -20px rgba(0,45,75,0.3),
                inset 0 -1px 1px rgba(255,255,255,0.7),
                inset 0 1px 2px rgba(255,255,255,0.8);
            border: 1px solid rgba(255,255,255,0.7);
            width: 100%;
            max-width: 500px;
            padding: 2.8rem 2.8rem 2.8rem 2.8rem;
            transition: all 0.3s ease;
        }

        .brand-tag {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .back-link {
            background: rgba(255,255,255,0.5);
            backdrop-filter: blur(4px);
            padding: 0.7rem 1.5rem;
            border-radius: 100px;
            color: #1e3c72;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.9rem;
            border: 1px solid rgba(255,255,255,0.9);
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .back-link i {
            font-size: 0.9rem;
        }
        .back-link:hover {
            background: white;
            transform: translateX(-4px);
            box-shadow: 0 10px 20px -10px #1e3c72;
        }
        .corporate-badge {
            background: linear-gradient(145deg, #ffb347, #ff9f1c);
            padding: 0.5rem 1.5rem;
            border-radius: 100px;
            font-weight: 700;
            font-size: 0.85rem;
            color: #1e2b3c;
            box-shadow: 0 6px 14px rgba(255,160,50,0.3);
            border: 1px solid rgba(255,255,255,0.5);
            letter-spacing: 0.3px;
        }
        .corporate-badge i {
            margin-right: 6px;
        }

        .header-icon {
            text-align: center;
            margin-bottom: 2rem;
        }
        .icon-ring {
            background: linear-gradient(145deg, #ffffff, #f0f5ff);
            width: 90px;
            height: 90px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.2rem;
            box-shadow: 0 20px 30px -12px #1e3c7240, 0 0 0 1px rgba(255,255,255,0.8) inset;
        }
        .icon-ring i {
            font-size: 3.5rem;
            color: #1e3c72;
            filter: drop-shadow(0 6px 8px #1e3c7220);
        }
        .header-icon h2 {
            font-size: 2.3rem;
            font-weight: 800;
            background: linear-gradient(to right, #0b2b4e, #1f4b82);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            margin-bottom: 0.4rem;
        }
        .header-icon p {
            color: #365f8a;
            font-weight: 500;
            font-size: 1rem;
        }

        /* modern form */
        .input-group-modern {
            margin-bottom: 2rem;
        }
        .input-group-modern label {
            display: block;
            font-weight: 700;
            font-size: 0.9rem;
            color: #1a3b5c;
            margin-bottom: 0.5rem;
            letter-spacing: 0.02rem;
            padding-left: 0.5rem;
        }
        .input-field {
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.8);
            border-radius: 100px;
            padding: 0 1.5rem;
            border: 2px solid rgba(255,255,255,0.9);
            transition: 0.2s ease;
            box-shadow: 0 4px 12px rgba(0,30,60,0.03);
        }
        .input-field i {
            color: #1e3c72;
            font-size: 1.2rem;
            opacity: 0.7;
            width: 24px;
        }
        .input-field input {
            width: 100%;
            padding: 1.1rem 0 1.1rem 0.8rem;
            border: none;
            background: transparent;
            font-weight: 500;
            font-size: 1rem;
            color: #111827;
            outline: none;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .input-field input::placeholder {
            color: #97b2cf;
            font-weight: 400;
        }
        .input-field:focus-within {
            border-color: #1e3c72;
            background: white;
            box-shadow: 0 8px 20px -14px #1e3c72, 0 0 0 3px rgba(30,60,114,0.1);
        }
        .hint-text {
            font-size: 0.75rem;
            margin-top: 0.4rem;
            padding-left: 1.2rem;
            color: #3e6a97;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin: 2rem 0 1.5rem;
        }
        .btn-primary {
            background: #1e3c72;
            border: none;
            padding: 1.2rem 1.8rem;
            border-radius: 120px;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            box-shadow: 0 20px 30px -12px #1e3c72, 0 2px 0 0 #2f5890 inset;
            transition: all 0.2s;
            border: 1px solid rgba(255,255,255,0.3);
        }
        .btn-primary i {
            font-size: 1.2rem;
        }
        .btn-primary:hover {
            background: #143768;
            transform: translateY(-3px);
            box-shadow: 0 28px 38px -16px #0f2b50;
        }

        .links-panel {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 0.2rem;
        }
        .links-panel a {
            text-decoration: none;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
            padding: 0.6rem 1.8rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.9rem;
            color: #1e3c72;
            border: 1px solid white;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .links-panel a i {
            font-size: 0.9rem;
        }
        .links-panel a:hover {
            background: white;
            border-color: #1e3c72;
            transform: scale(1.02);
        }

        .info-message {
            background: rgba(255,255,240,0.7);
            backdrop-filter: blur(8px);
            border-radius: 40px;
            padding: 0.9rem 2rem;
            margin: 1.2rem 0 0.5rem;
            font-weight: 600;
            font-size: 0.95rem;
            color: #044b67;
            border: 1px solid #ffe4a2;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .info-message i {
            color: #e68a2e;
            font-size: 1.2rem;
        }

        .register-section {
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(8px);
            border-radius: 80px;
            padding: 1.5rem 1.8rem;
            margin-top: 2.2rem;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .register-section p {
            font-weight: 600;
            color: #0b2b4e;
            margin-bottom: 0.8rem;
        }
        .register-link {
            background: linear-gradient(135deg, #ffffff, #f0f8ff);
            border-radius: 60px;
            padding: 0.9rem 2rem;
            font-weight: 700;
            color: #1e3c72;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.02);
            border: 1px solid #cdddec;
            transition: 0.2s;
        }
        .register-link:hover {
            background: white;
            border-color: #1e3c72;
            transform: translateY(-2px);
            box-shadow: 0 12px 24px -12px #1e3c72;
        }

        .footer-note {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.8rem;
            background: rgba(255,255,255,0.3);
            backdrop-filter: blur(8px);
            padding: 0.6rem 2rem;
            border-radius: 100px;
            color: #1a3b5c;
            font-weight: 500;
            display: inline-block;
            width: auto;
            border: 1px solid rgba(255,255,255,0.8);
        }
        .footer-note i {
            color: #ffb347;
        }

        .floating-company {
            position: fixed;
            bottom: 20px;
            right: 30px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(8px);
            padding: 0.8rem 2rem;
            border-radius: 60px;
            border: 1px solid rgba(255,255,255,0.9);
            font-weight: 600;
            color: #1e3c72;
            font-size: 0.9rem;
            z-index: 99;
            box-shadow: 0 10px 20px -12px #1e3c72;
        }
        .floating-company i {
            margin-right: 8px;
            color: #ffb347;
        }

        /* alert simulation (for forgot request) */
        .alert-box {
            background: #dcfce7;
            border: 1px solid #86efac;
            color: #14532d;
            padding: 1rem 1.5rem;
            border-radius: 60px;
            margin-bottom: 1.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(4px);
        }
    </style>
</head>
<body>
    <div class="bg-shapes">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <div class="login-wrapper">
        <div class="login-card">
            <!-- brand tag exactly same as login -->
            <div class="brand-tag">
                <a href="/company" class="back-link"><i class="fas fa-arrow-left"></i> Back to login</a>
                <span class="corporate-badge"><i class="fas fa-rotate-left"></i> RESET</span>
            </div>

            <!-- icon / heading : forgot version -->
            <div class="header-icon">
                <div class="icon-ring">
                    <i class="fas fa-key"></i>  <!-- subtle change but same style -->
                </div>
                <h2>Forgot password?</h2>
                <p>We'll send a reset link to your company email</p>
            </div>

           

            <form id="forgotForm" action="actions/send-reset.php" method="POST">
                <div class="input-group-modern">
                    <label><i class="far fa-id-card" style="margin-right: 6px;"></i> Company ID or Email</label>
                    <div class="input-field">
                        <i class="fas fa-building"></i>
                        <input type="text" name="company_identifier" id="company_identifier" placeholder="e.g., HR@company.com or COMP00876" required autocomplete="off">
                    </div>
                    <div class="hint-text">
                        <i class="fas fa-circle-info"></i> Enter the email / ID linked to your company profile
                    </div>
                </div>

                <!-- subtle info message (static) -->
                <div class="info-message">
                    <i class="fas fa-shield-halved"></i> A secure reset token will be sent if the account exists.
                </div>

                <div class="action-buttons">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-paper-plane"></i> Send reset instructions
                    </button>
                </div>

                <div class="links-panel">
                    <a href="/company"><i class="fas fa-arrow-right-to-bracket"></i> Return to sign in</a>
                    <a href="register.php"><i class="fas fa-briefcase"></i> Register</a>
                </div>
            </form>

            

            <!-- footer university note -->
            <div style="text-align: center; margin-top: 1.8rem;">
                <span class="footer-note"><i class="fas fa-shield"></i> GLA SPMS · password recovery</span>
            </div>
        </div>
    </div>

    <div class="floating-company">
        <i class="fas fa-building"></i> company access · v2
    </div>

    <!-- invisible note: fully working forgot page with company id/email field, design identical to login -->
</body>
</html>