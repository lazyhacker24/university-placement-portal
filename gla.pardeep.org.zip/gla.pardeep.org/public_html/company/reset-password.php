<?php
require_once '../config/db.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }

        h2 {
            color: #333;
            margin-bottom: 30px;
            text-align: center;
            font-size: 28px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
        }

        .password-requirements {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .password-requirements p {
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }

        .password-requirements ul {
            list-style: none;
            padding-left: 0;
        }

        .password-requirements li {
            margin-bottom: 5px;
            color: #666;
            display: flex;
            align-items: center;
        }

        .password-requirements li:before {
            content: "✗";
            color: #dc3545;
            margin-right: 8px;
            font-weight: bold;
        }

        .password-requirements li.valid:before {
            content: "✓";
            color: #28a745;
        }

        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.3s;
        }

        button:hover {
            opacity: 0.9;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }

        .info-message {
            background: #d1ecf1;
            color: #0c5460;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #bee5eb;
        }

        .password-strength {
            margin-top: 10px;
            height: 5px;
            background: #e1e1e1;
            border-radius: 3px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s, background-color 0.3s;
        }

        .password-strength-text {
            font-size: 12px;
            margin-top: 5px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>

        <?php
        // Check for error/success messages from session
        if(isset($_SESSION['reset_error'])) {
            echo '<div class="error-message">' . htmlspecialchars($_SESSION['reset_error']) . '</div>';
            unset($_SESSION['reset_error']);
        }
        if(isset($_SESSION['reset_success'])) {
            echo '<div class="success-message">' . htmlspecialchars($_SESSION['reset_success']) . '</div>';
            unset($_SESSION['reset_success']);
        }

        // Validate token
        if(!isset($_GET['token'])) {
            echo '<div class="error-message">Invalid reset link. No token provided.</div>';
            echo '<div style="text-align: center;"><a href="forgot-password.php" style="color: #667eea;">Request new reset link</a></div>';
            exit;
        }

        $token = $_GET['token'];
        
        // Clean token to prevent any issues
        $token = trim($token);
        $token = htmlspecialchars($token);
        
        // Verify token in database
        $stmt = $conn->prepare("SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW()");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows == 0) {
            echo '<div class="error-message">This password reset link has expired or is invalid.</div>';
            echo '<div style="text-align: center;"><a href="forgot-password.php" style="color: #667eea;">Request new reset link</a></div>';
            exit;
        }
        
        $data = $result->fetch_assoc();
        $company_id = $data['company_id'];
        $email = $data['email'] ?? 'your account';
        ?>
        
        <div class="info-message">
            Resetting password for: <strong><?php echo htmlspecialchars($email); ?></strong>
        </div>

        <form method="POST" action="actions/update-password.php" id="resetForm">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            
            <div class="form-group">
                <label for="password">New Password</label>
                <input 
                    type="password" 
                    name="password" 
                    id="password" 
                    placeholder="Enter new password" 
                    required
                    minlength="8"
                >
                <div class="password-strength">
                    <div class="password-strength-bar" id="strengthBar"></div>
                </div>
                <div class="password-strength-text" id="strengthText"></div>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input 
                    type="password" 
                    name="confirm_password" 
                    id="confirm_password" 
                    placeholder="Confirm new password" 
                    required
                >
            </div>

            <div class="password-requirements">
                <p>Password must contain:</p>
                <ul>
                    <li id="req-length">At least 8 characters</li>
                    <li id="req-uppercase">At least one uppercase letter</li>
                    <li id="req-lowercase">At least one lowercase letter</li>
                    <li id="req-number">At least one number</li>
                    <li id="req-special">At least one special character</li>
                    <li id="req-match">Passwords match</li>
                </ul>
            </div>

            <button type="submit">Update Password</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="login.php" style="color: #667eea; text-decoration: none;">Back to Login</a>
        </div>
    </div>

    <script>
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const strengthBar = document.getElementById('strengthBar');
        const strengthText = document.getElementById('strengthText');

        // Password requirements check
        function checkPasswordStrength() {
            const pass = password.value;
            
            // Check requirements
            const hasLength = pass.length >= 8;
            const hasUpper = /[A-Z]/.test(pass);
            const hasLower = /[a-z]/.test(pass);
            const hasNumber = /[0-9]/.test(pass);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
            const passwordsMatch = pass === confirmPassword.value && pass !== '';
            
            // Update requirement indicators
            document.getElementById('req-length').className = hasLength ? 'valid' : '';
            document.getElementById('req-uppercase').className = hasUpper ? 'valid' : '';
            document.getElementById('req-lowercase').className = hasLower ? 'valid' : '';
            document.getElementById('req-number').className = hasNumber ? 'valid' : '';
            document.getElementById('req-special').className = hasSpecial ? 'valid' : '';
            document.getElementById('req-match').className = passwordsMatch ? 'valid' : '';
            
            // Calculate strength
            const requirements = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial];
            const strength = requirements.filter(Boolean).length;
            
            // Update strength bar
            const percentage = (strength / 5) * 100;
            strengthBar.style.width = percentage + '%';
            
            // Update colors and text
            if(pass.length === 0) {
                strengthBar.style.backgroundColor = '#e1e1e1';
                strengthText.textContent = '';
            } else if(strength <= 2) {
                strengthBar.style.backgroundColor = '#dc3545';
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#dc3545';
            } else if(strength <= 4) {
                strengthBar.style.backgroundColor = '#ffc107';
                strengthText.textContent = 'Moderate password';
                strengthText.style.color = '#ffc107';
            } else {
                strengthBar.style.backgroundColor = '#28a745';
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#28a745';
            }
        }

        password.addEventListener('input', checkPasswordStrength);
        confirmPassword.addEventListener('input', checkPasswordStrength);

        // Form validation before submit
        document.getElementById('resetForm').addEventListener('submit', function(e) {
            const pass = password.value;
            const confirm = confirmPassword.value;
            
            // Check all requirements
            const hasLength = pass.length >= 8;
            const hasUpper = /[A-Z]/.test(pass);
            const hasLower = /[a-z]/.test(pass);
            const hasNumber = /[0-9]/.test(pass);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
            
            if(!hasLength || !hasUpper || !hasLower || !hasNumber || !hasSpecial) {
                e.preventDefault();
                alert('Please meet all password requirements');
                return false;
            }
            
            if(pass !== confirm) {
                e.preventDefault();
                alert('Passwords do not match');
                return false;
            }
        });
    </script>
</body>
</html>