require_once '../mail/company_mail.php';
sendCompanyVerificationMail($email,$hr_name,$company_name,$token);