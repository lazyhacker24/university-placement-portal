<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__.'/../vendor/PHPMailer/src/Exception.php';
require_once __DIR__.'/../vendor/PHPMailer/src/PHPMailer.php';
require_once __DIR__.'/../vendor/PHPMailer/src/SMTP.php';

function sendMail($to,$name,$subject,$body){

$mail = new PHPMailer(true);

try{

$mail->isSMTP();
$mail->Host       = 'mail.pardeep.org'; // IMPORTANT
$mail->SMTPAuth   = true;
$mail->Username   = 'no-reply@pardeep.org';
$mail->Password   = 'Raja1322#@';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
$mail->Port       = 465;

$mail->setFrom('no-reply@pardeep.org','GLA Placement Portal');
$mail->addAddress($to,$name);

$mail->isHTML(true);
$mail->Subject = $subject;
$mail->Body    = $body;

$mail->send();
return true;

}catch(Exception $e){
return false;
}

}