<?php

$host = "localhost";
$user = "pardeepo_gla";
$pass = "Raja1322#@";
$db   = "pardeepo_gla";

$conn = new mysqli($host,$user,$pass,$db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}