<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

/* =====================
   START SESSION SAFELY
===================== */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =====================
   REDIRECT IF LOGGED IN
===================== */
function redirectIfLoggedIn(){

    if(isset($_SESSION['admin_id'])){
        header("Location: /admin/dashboard.php");
        exit;
    }

    if(isset($_SESSION['student_id'])){
        header("Location: /student/dashboard/index.php");
        exit;
    }

    if(isset($_SESSION['company_id'])){
        header("Location: /company/dashboard.php");
        exit;
    }

    if(isset($_SESSION['officer_id'])){
        header("Location: /officer/dashboard.php");
        exit;
    }

}

/* =====================
   FLASH MESSAGE SYSTEM
===================== */

function setFlash($msg){
    $_SESSION['flash_message']=$msg;
}

function getFlash(){
    if(isset($_SESSION['flash_message'])){
        $msg=$_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $msg;
    }
    return "";
}
?>
