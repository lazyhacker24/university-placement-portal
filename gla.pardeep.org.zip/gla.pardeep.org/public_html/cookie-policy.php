<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cookie Policy | SPMS 2.0</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f5f7fa;
            line-height: 1.6;
            color: #2c3e50;
            padding: 30px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 50px;
        }

        h1 {
            font-size: 32px;
            color: #1e3c72;
            margin-bottom: 8px;
            font-weight: 600;
            border-bottom: 3px solid #1e3c72;
            padding-bottom: 15px;
        }

        .subtitle {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        section {
            margin-bottom: 35px;
        }

        h2 {
            font-size: 22px;
            color: #1e3c72;
            margin-bottom: 15px;
            font-weight: 600;
            background: #f8fafc;
            padding: 10px 15px;
            border-radius: 8px;
            border-left: 4px solid #1e3c72;
        }

        p {
            color: #475569;
            margin-bottom: 15px;
            font-size: 15px;
        }

        ul {
            list-style: none;
            margin: 15px 0;
        }

        ul li {
            color: #475569;
            padding: 8px 0 8px 25px;
            position: relative;
            font-size: 15px;
            border-bottom: 1px dashed #e2e8f0;
        }

        ul li:last-child {
            border-bottom: none;
        }

        ul li::before {
            content: "•";
            color: #1e3c72;
            font-weight: bold;
            position: absolute;
            left: 8px;
        }

        a {
            color: white;
            background: #1e3c72;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 8px;
            display: inline-block;
            margin-top: 10px;
            font-size: 15px;
            border: none;
            transition: background 0.2s;
            word-break: break-all;
        }

        a:hover {
            background: #2a5298;
        }

        .footer-note {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 28px;
            }
            
            h2 {
                font-size: 20px;
            }
            
            a {
                display: block;
                text-align: center;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cookie Policy</h1>
        <div class="subtitle">Student Placement Management System (SPMS v2.0)</div>

        <section>
            <h2>1. What Are Cookies</h2>
            <p>
                Cookies are small text files stored in the browser to help maintain
                user sessions and preferences.
            </p>
        </section>

        <section>
            <h2>2. Use of Cookies</h2>
            <ul>
                <li>Maintaining login sessions</li>
                <li>Improving user experience</li>
                <li>System functionality</li>
            </ul>
        </section>

        <section>
            <h2>3. Cookie Management</h2>
            <p>
                Users can disable cookies through browser settings, although some
                features may not function properly.
            </p>
        </section>

        <section>
            <h2>4. Data Protection</h2>
            <p>
                For more information about how data is handled in this portal,
                please visit the Data Protection Policy.
            </p>

            <p>
                <a href="https://gla.pardeep.org/data-protection.php">
                    View Data Protection Policy 
                </a>
            </p>
        </section>

        <div class="footer-note">
            © 2026 Pardeep Kumar | Student Placement Management System v2.0 | Academic Project - GLA University
        </div>
    </div>
</body>
</html>