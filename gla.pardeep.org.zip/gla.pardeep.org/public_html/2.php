<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

$hash = '';
$password = '';

if(isset($_POST['make_hash'])){

    $password = trim($_POST['password']);

    if($password != ''){
        $hash = password_hash($password, PASSWORD_DEFAULT);
    }

}
?>

<!DOCTYPE html>
<html>
<head>
<title>Password Hash Maker</title>
<style>

body{
    font-family: Arial;
    background:#111;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:#1e1e1e;
    padding:30px;
    border-radius:10px;
    width:450px;
}

input, textarea{
    width:100%;
    padding:10px;
    margin-top:10px;
    border:none;
    border-radius:5px;
}

button{
    margin-top:10px;
    padding:10px;
    width:100%;
    background:#00ff9c;
    border:none;
    cursor:pointer;
    font-weight:bold;
}

textarea{
    height:120px;
}

</style>
</head>

<body>

<div class="box">

<h2>Password Hash Maker</h2>

<form method="POST">

<label>Enter Password</label>
<input type="text" name="password" required>

<button type="submit" name="make_hash">Generate Hash</button>

</form>

<?php if($hash != ''){ ?>

<h3>Generated Hash</h3>

<textarea readonly><?php echo $hash; ?></textarea>

<?php } ?>

</div>

</body>
</html>