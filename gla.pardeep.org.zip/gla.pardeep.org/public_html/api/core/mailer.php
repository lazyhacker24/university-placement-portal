<?php

function sendMail($to, $subject, $message)
{
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: GLA Placement <no-reply@pardeep.org>";

    return mail($to, $subject, $message, $headers);
}
?>