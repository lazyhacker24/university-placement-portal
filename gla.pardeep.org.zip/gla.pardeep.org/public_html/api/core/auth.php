<?php
session_start();

/* Check Login */
function requireLogin($role = null)
{
    if (!isset($_SESSION['user_id'])) {
        header("Location: /login.php");
        exit;
    }

    if ($role && $_SESSION['role'] !== $role) {
        die("Unauthorized Access");
    }
}

/* Login User */
function loginUser($id, $role)
{
    session_regenerate_id(true);

    $_SESSION['user_id'] = $id;
    $_SESSION['role'] = $role;
}

/* Logout */
function logoutUser()
{
    session_unset();
    session_destroy();
}
?>