<?php

/* Clean Input */
function clean($data)
{
    return htmlspecialchars(trim($data));
}

/* Password Hash */
function hashPassword($password)
{
    return password_hash($password, PASSWORD_BCRYPT);
}

/* Verify Password */
function verifyPassword($password, $hash)
{
    return password_verify($password, $hash);
}

/* Generate Token */
function generateToken($length = 32)
{
    return bin2hex(random_bytes($length));
}

/* Redirect Helper */
function redirect($url)
{
    header("Location: $url");
    exit;
}
?>