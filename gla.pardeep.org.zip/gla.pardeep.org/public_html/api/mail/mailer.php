<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/*
|--------------------------------------------------------------------------
| REQUIRED FILES
|--------------------------------------------------------------------------
*/
require_once __DIR__.'/../../config/db.php';
require_once __DIR__.'/log_mail.php';
require_once __DIR__.'/phpmailer/PHPMailer.php';
require_once __DIR__.'/phpmailer/SMTP.php';
require_once __DIR__.'/phpmailer/Exception.php';


/*
|--------------------------------------------------------------------------
| UNIVERSAL SMTP MAIL FUNCTION
|--------------------------------------------------------------------------
*/
function sendMail($to, $subject, $body, $type='GENERAL'){

    global $conn; // Needed for logging

    $mail = new PHPMailer(true);

    try{
        $mail->isSMTP();
        $mail->Host       = 'mail.pardeep.org';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'webmaster@pardeep.org';
        $mail->Password   = 'Raja1322#@';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        $mail->setFrom('webmaster@pardeep.org', 'GLA Placement Portal');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();

        // ✅ Log success
        if(function_exists('logMail')){
            logMail($conn, $to, $subject, $type, 'SUCCESS', null);
        }

        return true;

    } catch (Exception $e){

        error_log("Mail Error: ".$mail->ErrorInfo);

        // ❌ Log failure
        if(function_exists('logMail')){
            logMail($conn, $to, $subject, $type, 'FAILED', $mail->ErrorInfo);
        }

        return false;
    }
}


/*
|--------------------------------------------------------------------------
| COMPANY EMAIL VERIFICATION
|--------------------------------------------------------------------------
*/
function sendCompanyVerificationMail($to_email, $hr_name, $company_name, $token){

    $verify_link = "https://gla.pardeep.org/company/verify.php?token=".$token;

    // Make variables available in template
    $GLOBALS['hr_name'] = $hr_name;
    $GLOBALS['company_name'] = $company_name;
    $GLOBALS['verify_link'] = $verify_link;

    ob_start();
    include __DIR__.'/company/new_register_verify.php';
    $body = ob_get_clean();

    $subject = "Verify Your Company Email - GLA Placement Portal";

    return sendMail($to_email, $subject, $body, 'COMPANY_VERIFY');
}

?>