<?php
function docRequestTemplate($hr, $company, $link){
return "
<h2>Dear $hr,</h2>
<p>Greetings from Placement Cell.</p>
<p>We reviewed your application for <b>$company</b>.</p>

<p>Please upload required documents:</p>
<ul>
<li>HR ID Proof</li>
<li>Company ID</li>
<li>Tax Certificate</li>
<li>Incorporation Certificate</li>
<li>University Agreement</li>
</ul>

<p><a href='$link'>Upload Documents</a></p>

<br>
<p>Regards,<br>GLA Placement Cell</p>
";
}