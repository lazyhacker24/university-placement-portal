<?php

function companyVerificationTemplate($hr,$company,$token){
$link = "https://gla.pardeep.org/company/verify.php?token=$token";
return "
<h2>Email Verification</h2>
<p>Dear $hr,</p>
<p>Thank you for registering <b>$company</b>.</p>
<p>Please verify your email:</p>
<p><a href='$link'>Verify Email</a></p>
<p>GLA University Placement Portal</p>";
}

function companyApprovedTemplate($hr,$company){
return "
<h2>Company Approved ✅</h2>
<p>Dear $hr,</p>
<p>Your company <b>$company</b> has been approved.</p>
<p>You can now login and post drives.</p>
<p>Best Regards,<br>GLA Placement Team</p>";
}

function companyRejectedTemplate($hr,$company,$reason){
return "
<h2>Company Registration Rejected ❌</h2>
<p>Dear $hr,</p>
<p>Your company <b>$company</b> was rejected.</p>
<p><b>Reason:</b> $reason</p>
<p>Please contact admin.</p>";
}

function companyDocsTemplate($hr,$company){
return "
<h2>Documents Required 📄</h2>
<p>Dear $hr,</p>
<p>Please upload required documents for <b>$company</b>.</p>
<p>Login → Upload Documents</p>";
}