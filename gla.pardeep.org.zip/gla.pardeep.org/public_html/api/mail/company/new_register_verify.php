<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
</head>
<body style="font-family:Arial;background:#f4f6f9;padding:30px;">

<div style="max-width:600px;margin:auto;background:#ffffff;padding:30px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);">

<h2 style="color:#1e3c72;">Hello <?= htmlspecialchars($hr_name) ?>,</h2>

<p>
Thank you for registering your company
<b><?= htmlspecialchars($company_name) ?></b>
with GLA University Placement Portal.
</p>

<p>Please verify your email by clicking the button below:</p>

<p style="text-align:center;margin:30px 0;">
<a href="<?= $verify_link ?>"
style="background:#1e3c72;color:white;padding:12px 25px;text-decoration:none;border-radius:5px;font-weight:bold;">
Verify Email
</a>
</p>

<p style="font-size:13px;color:#666;">
This link will expire in 30 minutes.
</p>

<br>
<p>Regards,<br><b>GLA Placement Team</b></p>

</div>
</body>
</html>