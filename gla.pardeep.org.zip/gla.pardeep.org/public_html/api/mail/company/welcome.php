<?php
function welcomeTemplate($hr_name){
return "
<h2>Welcome $hr_name,</h2>
<p>Your email has been verified.</p>
<p>Your hiring partner application is under review.</p>
<p>Please wait 24–48 working hours.</p>
<br>
<p>Regards,<br>GLA Placement Cell</p>
";
}