<?php
require_once 'mailer.php';
require_once 'company_templates.php';
require_once 'log_mail.php';

/* ===============================
   COMPANY EMAIL VERIFICATION
================================ */
function sendCompanyVerificationMail($to,$hr_name,$company_name,$token){
    $subject = "Verify Your Company Email - GLA University";
    $body = companyVerificationTemplate($hr_name,$company_name,$token);
    sendMail($to,$subject,$body);
    logMail($to,$subject,'company_verification');
}

/* ===============================
   COMPANY APPROVED
================================ */
function sendCompanyApprovedMail($to,$hr_name,$company_name){
    $subject = "Company Approved - GLA Placement Portal";
    $body = companyApprovedTemplate($hr_name,$company_name);
    sendMail($to,$subject,$body);
    logMail($to,$subject,'company_approved');
}

/* ===============================
   COMPANY REJECTED
================================ */
function sendCompanyRejectedMail($to,$hr_name,$company_name,$reason){
    $subject = "Company Registration Rejected";
    $body = companyRejectedTemplate($hr_name,$company_name,$reason);
    sendMail($to,$subject,$body);
    logMail($to,$subject,'company_rejected');
}

/* ===============================
   DOCUMENTS REQUESTED
================================ */
function sendCompanyDocsMail($to,$hr_name,$company_name){
    $subject = "Documents Required - GLA Placement Portal";
    $body = companyDocsTemplate($hr_name,$company_name);
    sendMail($to,$subject,$body);
    logMail($to,$subject,'company_docs_requested');
}