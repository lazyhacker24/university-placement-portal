<?php
/*
|--------------------------------------------------------------------------
| MAIL LOGGING SYSTEM
|--------------------------------------------------------------------------
| Stores all outgoing mail records for admin tracking
| Used by: mailer.php
|--------------------------------------------------------------------------
*/

function logMail($conn, $to, $subject, $type, $status, $error = null){

    // Prevent crash if DB missing
    if(!$conn){
        error_log("Mail Log Error: Database connection missing");
        return false;
    }

    // Prepare query
    $stmt = $conn->prepare("
        INSERT INTO mail_logs
        (recipient_email, subject, mail_type, status, error, created_at)
        VALUES (?,?,?,?,?,NOW())
    ");

    if(!$stmt){
        error_log("Mail Log Prepare Failed: ".$conn->error);
        return false;
    }

    // Bind values
    $stmt->bind_param("sssss", $to, $subject, $type, $status, $error);

    // Execute
    if(!$stmt->execute()){
        error_log("Mail Log Execute Failed: ".$stmt->error);
        return false;
    }

    $stmt->close();
    return true;
}
?>