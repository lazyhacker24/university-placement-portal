<?php

require_once __DIR__.'/mailer.php';

function sendOfficerWelcome($name,$email,$phone,$staff_id,$token){

/* ================= EMAIL 1 ================= */

$subject="Welcome to GLA University Placement Cell";

$body="

<h2>Welcome to GLA Placement Cell</h2>

<p>Hello $name</p>

<p>Your account has been created.</p>

<p><b>Staff ID:</b> $staff_id</p>
<p><b>Email:</b> $email</p>
<p><b>Phone:</b> $phone</p>

<a href='https://gla.pardeep.org/officer/'
style='padding:10px 20px;background:#1e3c72;color:white;text-decoration:none;border-radius:6px;'>

Login Portal

</a>

";

sendMail($email,$subject,$body);

/* ================= EMAIL 2 ================= */

$link="https://gla.pardeep.org/officer/set-password.php?token=".$token;

$subject="Create Your Password";

$body="

<h3>Hello $name</h3>

<p>Your Staff ID is <b>$staff_id</b></p>

<p>Please click below to create password.</p>

<a href='$link'
style='padding:10px 20px;background:#10b981;color:white;text-decoration:none;border-radius:6px;'>

Create Password

</a>

<p>This link expires in 5 minutes.</p>

";

sleep(2);

sendMail($email,$subject,$body);

}