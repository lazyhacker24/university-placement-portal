<?php
require_once '../config/session.php';

session_unset();
session_destroy();

session_start();
setFlash("Logged out successfully.");

header("Location: login.php");
exit;