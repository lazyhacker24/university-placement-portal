<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';

/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: /student/index.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */
$student_id = $_SESSION['student_id'];

$stmt = $conn->prepare("
SELECT full_name, roll_no, course
FROM students
WHERE id=?
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$result = $stmt->get_result();
$studentData = $result->fetch_assoc();
/* =========================
   GET APPLICATIONS
========================= */

$stmt = $conn->prepare("
SELECT 
applications.id,
placement_drives.company_name,
placement_drives.title,
applications.applied_at,
applications.status
FROM applications
JOIN placement_drives 
ON applications.drive_id = placement_drives.id
WHERE applications.student_id=?
ORDER BY applications.applied_at DESC
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$applications = $stmt->get_result();

/* =========================
   GET UPCOMING INTERVIEWS
========================= */

$stmt = $conn->prepare("
SELECT 
placement_drives.company_name,
interviews.interview_type,
interviews.interview_date,
interviews.status
FROM interviews
JOIN applications 
ON interviews.application_id = applications.id
JOIN placement_drives 
ON applications.drive_id = placement_drives.id
WHERE interviews.student_id=? 
AND interviews.interview_date >= NOW()
ORDER BY interviews.interview_date ASC
LIMIT 5
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$interviews = $stmt->get_result();

/* =========================
   TOTAL APPLICATION COUNT
========================= */

$stmt = $conn->prepare("
SELECT COUNT(*) as total 
FROM applications 
WHERE student_id=?
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$totalApps = $stmt->get_result()->fetch_assoc()['total'];

/* =========================
   UNDER REVIEW COUNT
========================= */

$stmt = $conn->prepare("
SELECT COUNT(*) as total 
FROM applications 
WHERE student_id=? AND status='applied'
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$underReview = $stmt->get_result()->fetch_assoc()['total'];

/* =========================
   SHORTLISTED COUNT
========================= */

$stmt = $conn->prepare("
SELECT COUNT(*) as total 
FROM applications 
WHERE student_id=? AND status='shortlisted'
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$shortlisted = $stmt->get_result()->fetch_assoc()['total'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job Applications · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Stats Cards */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.stat-card h3 {
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 5px;
}

.stat-card p {
    color: #666;
    font-size: 14px;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Filter Select */
.filter-select {
    padding: 8px 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    color: var(--dark);
    background: white;
    cursor: pointer;
}

.filter-select:focus {
    outline: none;
    border-color: var(--primary);
}

/* Table Styles */
.table {
    width: 100%;
    border-collapse: collapse;
}

.table th {
    text-align: left;
    padding: 15px 12px;
    background: #f8f9fa;
    color: #666;
    font-weight: 600;
    font-size: 13px;
}

.table td {
    padding: 15px 12px;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

.table tr:last-child td {
    border-bottom: none;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

.status-review {
    background: #cce5ff;
    color: #004085;
}

.status-shortlisted {
    background: #d4edda;
    color: #155724;
}

.status-rejected {
    background: #f8d7da;
    color: #721c24;
}

.status-selected {
    background: #d1e7dd;
    color: #0f5132;
}

.action-link {
    color: var(--primary);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
}

.action-link:hover {
    text-decoration: underline;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .table {
        display: block;
        overflow-x: auto;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
<?= strtoupper(substr($studentData['full_name'] ?? 'ST',0,2)) ?>
</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
<p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
<p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item active">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>Job Applications</h2>
                <p>Track your job applications and their status</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="dashboard-grid">
            <div class="stat-card">
    <h3 style="color: var(--primary);"><?= $totalApps ?></h3>
    <p>Total Applications</p>
</div>
            <div class="stat-card">
                <h3 style="color: #ffc107;"><?= $underReview ?></h3>
<p>Under Review</p>
            </div>
            <div class="stat-card">
                <h3 style="color: #28a745;"><?= $shortlisted ?></h3>
<p>Shortlisted</p>
            </div>
        </div>
        
        <!-- Applications List -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-history"></i> Application History</h3>
                <select class="filter-select" id="statusFilter">
                    <option value="all">All Applications</option>
                    <option value="pending">Pending</option>
                    <option value="review">Under Review</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="rejected">Rejected</option>
                    <option value="selected">Selected</option>
                </select>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Position</th>
                        <th>Applied Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
             <tbody>

<?php if($applications->num_rows > 0){ ?>

<?php while($row = $applications->fetch_assoc()){ ?>

<tr>

<td><?= htmlspecialchars($row['company_name']) ?></td>

<td><?= htmlspecialchars($row['title']) ?></td>

<td><?= date("Y-m-d", strtotime($row['applied_at'])) ?></td>

<td>
<?php
$statusClass = 'status-review';

if($row['status'] == 'shortlisted') $statusClass = 'status-shortlisted';
if($row['status'] == 'rejected') $statusClass = 'status-rejected';
if($row['status'] == 'selected') $statusClass = 'status-selected';
?>

<span class="status-badge <?= $statusClass ?>">
<?= ucfirst($row['status']) ?>
</span>
</td>

<td>
<a href="application-details.php?id=<?= $row['id'] ?>" class="action-link">
View Details
</a>
</td>

</tr>

<?php } ?>

<?php } else { ?>

<tr>
<td colspan="5" style="text-align:center;padding:30px;">
No job applications yet
</td>
</tr>

<?php } ?>

</tbody>
            </table>
        </div>
        
        <!-- Upcoming Interviews -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-alt"></i> Upcoming Interviews</h3>
                <a href="#" class="action-link">View All</a>
            </div>
            
            <div style="display:grid;gap:15px;">

<?php if($interviews->num_rows > 0){ ?>

<?php while($row = $interviews->fetch_assoc()){ ?>

<div style="display:flex;justify-content:space-between;align-items:center;padding:15px;background:#f8f9fa;border-radius:10px;">

<div>
<h4 style="font-weight:600;margin-bottom:5px;">
<?= htmlspecialchars($row['company_name']) ?> - <?= htmlspecialchars($row['interview_type']) ?>
</h4>

<p style="font-size:13px;color:#666;">
<i class="fas fa-calendar"></i>
<?= date("F d, Y \a\t h:i A", strtotime($row['interview_date'])) ?>
</p>
</div>

<span class="status-badge status-review">
<?= ucfirst($row['status']) ?>
</span>

</div>

<?php } ?>

<?php } else { ?>

<p>No upcoming interviews</p>

<?php } ?>

</div>

            
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>
// Filter functionality
document.getElementById('statusFilter').addEventListener('change', function() {
    const filterValue = this.value;
    const rows = document.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const statusCell = row.querySelector('td:nth-child(4) span');
        if(!statusCell) return;
        
        const statusClass = statusCell.className;
        
        if(filterValue === 'all') {
            row.style.display = '';
            return;
        }
        
        let show = false;
        if(filterValue === 'pending' && statusClass.includes('status-pending')) show = true;
        if(filterValue === 'review' && statusClass.includes('status-review')) show = true;
        if(filterValue === 'shortlisted' && statusClass.includes('status-shortlisted')) show = true;
        if(filterValue === 'rejected' && statusClass.includes('status-rejected')) show = true;
        if(filterValue === 'selected' && statusClass.includes('status-selected')) show = true;
        
        row.style.display = show ? '' : 'none';
    });
});

// Sidebar navigation
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>