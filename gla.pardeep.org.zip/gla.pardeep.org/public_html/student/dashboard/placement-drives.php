<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';

/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: /login.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */
$student_id = $_SESSION['student_id'];

$stmt = $conn->prepare("
SELECT full_name, roll_no, course
FROM students
WHERE id=?
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$studentData = $stmt->get_result()->fetch_assoc();

/* =========================
   FILTER DRIVES
========================= */

$filter = $_GET['filter'] ?? 'all';

switch($filter){

case 'upcoming':
$query = "SELECT * FROM placement_drives WHERE date > CURDATE() ORDER BY date ASC";
break;

case 'ongoing':
$query = "SELECT * FROM placement_drives WHERE date = CURDATE() ORDER BY date ASC";
break;

case 'past':
$query = "SELECT * FROM placement_drives WHERE date < CURDATE() ORDER BY date DESC";
break;

case 'eligible':
$query = "SELECT * FROM placement_drives WHERE min_cgpa <= (SELECT cgpa FROM students WHERE id=$student_id)";
break;

default:
$query = "SELECT * FROM placement_drives ORDER BY date ASC";
}

$drives = $conn->query($query);

/* =========================
   GET PLACEMENT DRIVES
========================= */

$drives = $conn->query("
SELECT *
FROM placement_drives
WHERE date > CURDATE()
ORDER BY date ASC
");


/* =========================
   ONGOING DRIVES
========================= */

$ongoingDrives = $conn->query("
SELECT *
FROM placement_drives
WHERE date = CURDATE() AND drive_status='active'
");

/* =========================
   PAST DRIVES
========================= */

$pastDrives = $conn->query("
SELECT *
FROM placement_drives
WHERE date < CURDATE()
ORDER BY date DESC
");


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Placement Drives · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Drive Card */
.drive-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 12px;
    margin-bottom: 15px;
    transition: transform 0.3s;
}

.drive-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.drive-info h4 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--dark);
}

.drive-info .company {
    color: var(--primary);
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 10px;
    display: block;
}

.drive-details {
    display: flex;
    gap: 20px;
    font-size: 13px;
    color: #666;
}

.drive-details span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.drive-details i {
    color: var(--primary);
    width: 16px;
}

.drive-actions {
    display: flex;
    gap: 10px;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

.btn-outline {
    background: white;
    color: var(--primary);
    border: 1px solid var(--primary);
}

.btn-outline:hover {
    background: var(--primary);
    color: white;
}

/* Tabs */
.tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.tab {
    padding: 8px 20px;
    cursor: pointer;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.tab.active {
    background: var(--primary);
    color: white;
}

.tab:hover:not(.active) {
    background: rgba(30, 60, 114, 0.1);
}

/* Search Bar */
.search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.search-input {
    flex: 1;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
}

/* Eligibility Badge */
.eligibility {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 15px;
    font-size: 11px;
    font-weight: 500;
    margin-left: 10px;
}

.eligible {
    background: #d4edda;
    color: #155724;
}

.not-eligible {
    background: #f8d7da;
    color: #721c24;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .drive-card {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start;
    }
    
    .drive-actions {
        width: 100%;
    }
    
    .btn {
        flex: 1;
        text-align: center;
        justify-content: center;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
<?= strtoupper(substr($studentData['full_name'],0,2)) ?>
</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item active">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>Placement Drives</h2>
                <p>Explore upcoming and ongoing placement opportunities</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Search and Filter -->
        <div class="card">
            <div class="search-bar">
                <input type="text" class="search-input" placeholder="Search companies, roles...">
                <button class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </div>
            
            <div class="tabs">

<a href="?filter=all" class="tab <?= ($_GET['filter'] ?? 'all')=='all'?'active':'' ?>">All Drives</a>

<a href="?filter=upcoming" class="tab <?= ($_GET['filter'] ?? '')=='upcoming'?'active':'' ?>">Upcoming</a>

<a href="?filter=ongoing" class="tab <?= ($_GET['filter'] ?? '')=='ongoing'?'active':'' ?>">Ongoing</a>

<a href="?filter=past" class="tab <?= ($_GET['filter'] ?? '')=='past'?'active':'' ?>">Past Drives</a>

<a href="?filter=eligible" class="tab <?= ($_GET['filter'] ?? '')=='eligible'?'active':'' ?>">Eligible for Me</a>

</div>
        </div>
        
       <div class="card">

<div class="card-header">
<h3><i class="fas fa-briefcase"></i> Placement Drives</h3>
</div>

<?php if($drives->num_rows > 0){ ?>

<?php while($row = $drives->fetch_assoc()){ ?>

<div class="drive-card">

<div class="drive-info">

<h4><?= htmlspecialchars($row['company_name']) ?></h4>

<span class="company">
<?= htmlspecialchars($row['title']) ?>
</span>

<div class="drive-details">

<span>
<i class="fas fa-calendar"></i>
<?= date("F d, Y", strtotime($row['date'])) ?>
</span>

<span>
<i class="fas fa-clock"></i>
<?= htmlspecialchars($row['drive_time'] ?? 'N/A') ?>
</span>

<span>
<i class="fas fa-map-marker"></i>
<?= htmlspecialchars($row['venue'] ?? 'Online') ?>
</span>

<span>
<i class="fas fa-briefcase"></i>
<?= htmlspecialchars($row['package'] ?? 'N/A') ?>
</span>

</div>

</div>

<div class="drive-actions">

<a href="apply-drive.php?id=<?= $row['id'] ?>" class="btn btn-primary">
Register Now
</a>

<a href="drive-details.php?id=<?= $row['id'] ?>" class="btn btn-outline">
Details
</a>

</div>

</div>

<?php } ?>

<?php } else { ?>

<p>No drives found</p>

<?php } ?>

</div>
        
        <!-- Calendar View Link -->
        <div style="text-align: center; margin-top: 20px;">
            <a href="#" class="btn btn-primary" style="padding: 12px 30px;">
                <i class="fas fa-calendar-alt"></i> View Full Calendar
            </a>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>
// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        // Here you would filter drives based on tab
        console.log('Switched to tab:', this.textContent);
    });
});

// Search functionality
document.querySelector('.search-input').addEventListener('keyup', function(e) {
    const searchTerm = this.value.toLowerCase();
    const driveCards = document.querySelectorAll('.drive-card');
    
    driveCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        if(text.includes(searchTerm)) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
});

// Sidebar navigation
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>