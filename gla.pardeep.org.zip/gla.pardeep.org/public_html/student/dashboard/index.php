<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../../config/session.php';
require_once '../../config/db.php';

if(!isset($_SESSION['student_id'])){
    header("Location: ../index.php");
    exit;
}

$student_id = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i",$student_id);
$stmt->execute();

$result = $stmt->get_result();
$studentData = $result->fetch_assoc();


if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$profile_fields = [
$studentData['phone'],
$studentData['skills'],
$studentData['resume'],
$studentData['cgpa']
];

$filled = 0;

foreach($profile_fields as $field){
if(!empty($field)){
$filled++;
}
}

$profile_completion = ($filled / count($profile_fields)) * 100;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard · GLA University</title>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">

<style>
/* Dashboard Specific Styles */
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* ========== SIDEBAR ========== */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* ========== MAIN CONTENT ========== */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* ========== DASHBOARD CARDS ========== */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.stat-icon.blue {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: white;
}

.stat-icon.green {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
}

.stat-icon.orange {
    background: linear-gradient(135deg, #ff7e5f, #feb47b);
    color: white;
}

.stat-details h3 {
    font-size: 28px;
    font-weight: 700;
    color: var(--dark);
    margin-bottom: 5px;
}

.stat-details p {
    font-size: 14px;
    color: #666;
    font-weight: 500;
}

/* ========== PROGRESS CARD ========== */
.profile-completion {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.progress-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
}

.progress-title {
    font-weight: 600;
    color: var(--dark);
}

.progress-percent {
    color: var(--primary);
    font-weight: 700;
}

.progress-bar {
    height: 10px;
    background: #eee;
    border-radius: 5px;
    overflow: hidden;
    margin-bottom: 15px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    border-radius: 5px;
    transition: width 0.3s ease;
}

.progress-steps {
    display: flex;
    justify-content: space-between;
    color: #666;
    font-size: 12px;
}

/* ========== MAIN GRID ========== */
.content-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
}

.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

.view-all {
    color: var(--primary);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
}

/* ========== NOTICES ========== */
.notice-item {
    padding: 15px 0;
    border-bottom: 1px solid #eee;
    display: flex;
    gap: 15px;
}

.notice-item:last-child {
    border-bottom: none;
}

.notice-icon {
    width: 40px;
    height: 40px;
    background: rgba(30, 60, 114, 0.1);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--primary);
}

.notice-content h4 {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.notice-content p {
    font-size: 12px;
    color: #666;
    margin-bottom: 5px;
}

.notice-meta {
    display: flex;
    gap: 15px;
    font-size: 11px;
    color: #999;
}

/* ========== UPCOMING EVENTS ========== */
.event-item {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 10px;
    transition: background 0.3s;
}

.event-item:hover {
    background: rgba(0,0,0,0.02);
}

.event-date {
    text-align: center;
    min-width: 50px;
}

.event-date .day {
    font-size: 20px;
    font-weight: 700;
    color: var(--primary);
    line-height: 1;
}

.event-date .month {
    font-size: 11px;
    color: #666;
    text-transform: uppercase;
}

.event-details h4 {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.event-details p {
    font-size: 12px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

/* ========== QUICK ACTIONS ========== */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-top: 15px;
}

.action-btn {
    padding: 12px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
}

.action-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

.action-btn.secondary {
    background: white;
    color: var(--primary);
    border: 1px solid var(--primary);
}

.action-btn.secondary:hover {
    background: var(--primary);
    color: white;
}

/* ========== FLOATING LABEL ========== */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

/* ========== RESPONSIVE ========== */
@media (max-width: 1024px) {
    .dashboard-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .content-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .top-bar {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- ========== SIDEBAR ========== -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">PK</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
                <?= htmlspecialchars($studentData['branch']) ?>
            </div>
        </div>
        
        <nav class="sidebar-nav">

<a href="index.php" class="nav-item active">
<i class="fas fa-tachometer-alt"></i>
<span>Dashboard</span>
</a>

<a href="../dashboard/my-profile.php" class="nav-item">
<i class="fas fa-user"></i>
<span>My Profile</span>
</a>

<a href="../dashboard/job-applications.php" class="nav-item">
<i class="fas fa-briefcase"></i>
<span>Job Applications</span>
</a>

<a href="../dashboard/placement-drives.php" class="nav-item">
<i class="fas fa-calendar-check"></i>
<span>Placement Drives</span>
</a>

<a href="../dashboard/my-performance.php" class="nav-item">
<i class="fas fa-chart-line"></i>
<span>My Performance</span>
</a>

<a href="../dashboard/documents/index.php" class="nav-item">
<i class="fas fa-file-alt"></i>
<span>Documents</span>
</a>

<a href="../dashboard/notifications.php" class="nav-item">
<i class="fas fa-bell"></i>
<span>Notifications</span>
</a>

<a href="../dashboard/help-support.php" class="nav-item">
<i class="fas fa-question-circle"></i>
<span>Help & Support</span>
</a>

<a href="../logout.php" class="nav-item">
<i class="fas fa-sign-out-alt"></i>
<span>Logout</span>
</a>

</nav>
    </aside>
    
    <!-- ========== MAIN CONTENT ========== -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>Welcome back, Pardeep! 👋</h2>
                <p>Here's what's happening with your placement journey</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="dashboard-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="fas fa-briefcase"></i>
                </div>
                <div class="stat-details">
                    <h3>12</h3>
                    <p>Applied Jobs</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="fas fa-building"></i>
                </div>
                <div class="stat-details">
                    <h3>8</h3>
                    <p>Companies Visited</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon orange">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="stat-details">
                    <h3>3</h3>
                    <p>Shortlisted</p>
                </div>
            </div>
        </div>
        
        <!-- Profile Completion -->
        <div class="profile-completion">
            <div class="progress-header">
                <span class="progress-title">Profile Completion</span>
                <span class="progress-percent"><?= $studentData['profile_completion'] ?>%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?= $studentData['profile_completion'] ?>%"></div>
            </div>
            <div class="progress-steps">
                <span><i class="fas fa-check-circle" style="color: #28a745;"></i> Personal Info</span>
                <span><i class="fas fa-check-circle" style="color: #28a745;"></i> Education</span>
                <span><i class="fas fa-circle"></i> Skills</span>
                <span><i class="fas fa-circle"></i> Resume</span>
            </div>
        </div>
        
        <!-- Main Grid Content -->
        <div class="content-grid">
            <!-- Left Column -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-bullhorn"></i> Latest Notices</h3>
                    <a href="#" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <div class="notice-item">
                    <div class="notice-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="notice-content">
                        <h4>TCS Campus Drive Registration</h4>
                        <p>Registration open for TCS Ninja hiring program</p>
                        <div class="notice-meta">
                            <span><i class="fas fa-calendar"></i> 2 days ago</span>
                            <span><i class="fas fa-users"></i> 45 applied</span>
                        </div>
                    </div>
                </div>
                
                <div class="notice-item">
                    <div class="notice-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div class="notice-content">
                        <h4>Pre-Placement Talk: Infosys</h4>
                        <p>Virtual session on company culture and hiring process</p>
                        <div class="notice-meta">
                            <span><i class="fas fa-calendar"></i> Tomorrow, 11 AM</span>
                            <span><i class="fas fa-video"></i> Online</span>
                        </div>
                    </div>
                </div>
                
                <div class="notice-item">
                    <div class="notice-icon">
                        <i class="fas fa-file-pdf"></i>
                    </div>
                    <div class="notice-content">
                        <h4>Resume Submission Deadline</h4>
                        <p>Submit updated resumes for upcoming placement drive</p>
                        <div class="notice-meta">
                            <span><i class="fas fa-calendar"></i> Due in 3 days</span>
                            <span><i class="fas fa-exclamation-triangle" style="color: #ffc107;"></i> Urgent</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-alt"></i> Upcoming Events</h3>
                    <a href="#" class="view-all">Calendar <i class="fas fa-arrow-right"></i></a>
                </div>
                
                <div class="event-item">
                    <div class="event-date">
                        <div class="day">15</div>
                        <div class="month">MAR</div>
                    </div>
                    <div class="event-details">
                        <h4>Amazon Placement Drive</h4>
                        <p><i class="fas fa-clock"></i> 10:00 AM - 4:00 PM</p>
                        <p><i class="fas fa-map-marker-alt"></i> Auditorium, Block A</p>
                    </div>
                </div>
                
                <div class="event-item">
                    <div class="event-date">
                        <div class="day">18</div>
                        <div class="month">MAR</div>
                    </div>
                    <div class="event-details">
                        <h4>Aptitude Test - Microsoft</h4>
                        <p><i class="fas fa-clock"></i> 2:00 PM - 4:00 PM</p>
                        <p><i class="fas fa-laptop"></i> Online</p>
                    </div>
                </div>
                
                <div class="event-item">
                    <div class="event-date">
                        <div class="day">20</div>
                        <div class="month">MAR</div>
                    </div>
                    <div class="event-details">
                        <h4>Mock Interview Session</h4>
                        <p><i class="fas fa-clock"></i> 3:00 PM - 5:00 PM</p>
                        <p><i class="fas fa-map-marker-alt"></i> Training Cell</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions" style="margin-top: 20px;">
            <?php if($studentData['resume']){ ?>

<a href="../../uploads/resumes/<?= $studentData['resume'] ?>" class="action-btn">
<i class="fas fa-file"></i> View Resume
</a>

<?php } else { ?>

<a href="../documents/upload.php" class="action-btn">
<i class="fas fa-upload"></i> Upload Resume
</a>

<?php } ?>
            <button class="action-btn secondary">
                <i class="fas fa-search"></i>
                Browse Jobs
            </button>
            <button class="action-btn secondary">
                <i class="fas fa-chart-bar"></i>
                View Analytics
            </button>
            <button class="action-btn">
                <i class="fas fa-edit"></i>
                Update Profile
            </button>
        </div>
    </main>
</div>



<script>
// Sidebar toggle for mobile (you can enhance this)
document.addEventListener('DOMContentLoaded', function() {
    // Add active class to nav items on click
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Check for notifications (you can add real notifications here)
    console.log('Dashboard loaded');
});
</script>

</body>
</html>