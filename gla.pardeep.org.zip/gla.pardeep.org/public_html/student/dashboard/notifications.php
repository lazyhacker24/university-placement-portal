<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';


/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: student/index.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */

/* =========================
   GET STUDENT DATA
========================= */
$stmt2 = $conn->prepare("SELECT full_name, roll_no, course FROM students WHERE id = ?");
$stmt2->bind_param("i", $_SESSION['student_id']);
$stmt2->execute();
$res2 = $stmt2->get_result();
$studentData = $res2->fetch_assoc();


/* =========================
   FETCH NOTIFICATIONS
========================= */
$stmt = $conn->prepare("SELECT * FROM notifications WHERE student_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while($row = $result->fetch_assoc()){
    $notifications[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Filter Tabs */
.filter-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.filter-tab {
    padding: 8px 20px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
}

.filter-tab.active {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    border-color: transparent;
}

.filter-tab:hover:not(.active) {
    background: #f0f0f0;
}

/* Notification List */
.notification-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.notification-item {
    display: flex;
    gap: 15px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 12px;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
}

.notification-item:hover {
    transform: translateX(5px);
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.notification-item.unread {
    background: white;
    border-left-color: var(--primary);
    box-shadow: 0 2px 8px rgba(30, 60, 114, 0.1);
}

.notification-icon {
    width: 45px;
    height: 45px;
    background: rgba(30, 60, 114, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--primary);
    font-size: 18px;
    flex-shrink: 0;
}

.notification-content {
    flex: 1;
}

.notification-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
}

.notification-title {
    font-weight: 600;
    font-size: 15px;
    color: var(--dark);
}

.notification-time {
    font-size: 12px;
    color: #999;
}

.notification-message {
    font-size: 13px;
    color: #666;
    margin-bottom: 8px;
}

.notification-meta {
    display: flex;
    gap: 15px;
    font-size: 11px;
    color: #999;
}

.notification-meta i {
    color: var(--primary);
    margin-right: 3px;
}

.unread-dot {
    width: 8px;
    height: 8px;
    background: var(--primary);
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

.btn-outline {
    background: white;
    color: var(--primary);
    border: 1px solid var(--primary);
}

.btn-outline:hover {
    background: var(--primary);
    color: white;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .notification-header {
        flex-direction: column;
        gap: 5px;
    }
    
    .action-buttons {
        flex-wrap: wrap;
    }
    
    .btn {
        flex: 1;
        text-align: center;
        justify-content: center;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">PK</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item active">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>Notifications</h2>
                <p>Stay updated with latest announcements and alerts</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="action-buttons">
            <button class="btn btn-primary"><i class="fas fa-check-double"></i> Mark All as Read</button>
            <button class="btn btn-outline"><i class="fas fa-cog"></i> Notification Settings</button>
        </div>
        
        <!-- Filter Tabs -->
        <div class="filter-tabs">
            <span class="filter-tab active">All</span>
            <span class="filter-tab">Unread</span>
            <span class="filter-tab">Placement Drives</span>
            <span class="filter-tab">Job Applications</span>
            <span class="filter-tab">Events</span>
            <span class="filter-tab">Announcements</span>
        </div>
        
        <!-- Today's Notifications -->
       <div class="notification-list">
<?php if(!empty($notifications)): ?>
    <?php foreach($notifications as $n): ?>
        <div class="notification-item <?= $n['is_read'] ? '' : 'unread' ?>" data-id="<?= $n['id'] ?>">
            
            <div class="notification-icon">
                <i class="fas fa-bell"></i>
            </div>

            <div class="notification-content">
                <div class="notification-header">
                    <span class="notification-title">
                        <?= htmlspecialchars($n['title']) ?>
                    </span>
                    <span class="notification-time">
                        <?= date('d M Y, h:i A', strtotime($n['created_at'])) ?>
                    </span>
                </div>

                <div class="notification-message">
                    <?= htmlspecialchars($n['message']) ?>
                </div>

                <div class="notification-meta">
                    <?php if($n['company']): ?>
                        <span><i class="fas fa-building"></i> <?= $n['company'] ?></span>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No notifications found</p>
<?php endif; ?>
      

            <!-- Load More -->
            <div style="text-align: center; margin-top: 20px;">
                <button class="btn btn-outline"><i class="fas fa-spinner"></i> Load More</button>
            </div>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>
// Filter tabs functionality
document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        // Here you would filter notifications based on category
        console.log('Filter by:', this.textContent);
    });
});

// Mark as read on click
document.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {

        let id = this.getAttribute('data-id');

        fetch('mark-read.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'id=' + id
        });

        this.classList.remove('unread');
    });
});

// Mark all as read
document.querySelector('.btn-primary').addEventListener('click', function() {

    fetch('mark-all-read.php', {
        method: 'POST'
    }).then(() => {
        document.querySelectorAll('.notification-item').forEach(item => {
            item.classList.remove('unread');
        });
    });

});

// Sidebar navigation
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>