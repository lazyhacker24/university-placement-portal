<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';

/* =========================
   LOGOUT PROCESSING
========================= */

// Clear all session variables
$_SESSION = array();

// Destroy the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: /student/index.php?message=logged_out');
exit();
?>