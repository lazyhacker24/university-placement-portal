<?php

require_once '../../config/session.php';
require_once '../../config/db.php';

if(!isset($_SESSION['student_id'])){
header("Location:/login.php");
exit;
}

$student_id = $_SESSION['student_id'];
$drive_id = $_GET['id'];

$stmt = $conn->prepare("
INSERT INTO applications (student_id, drive_id, status)
VALUES (?,?, 'applied')
");

$stmt->bind_param("ii",$student_id,$drive_id);
$stmt->execute();

header("Location: job-applications.php");
exit;