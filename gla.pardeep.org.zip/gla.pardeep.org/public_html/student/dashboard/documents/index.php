<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../../config/session.php'; 
require_once '../../../config/db.php';


/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: /login.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */

$stmt = $conn->prepare("SELECT full_name, roll_no, course FROM students WHERE id=?");
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();

$result = $stmt->get_result();
$studentData = $result->fetch_assoc();



if(!$studentData){
    die("Invalid student");
}


$stmt = $conn->prepare("SELECT * FROM student_documents WHERE student_id=? ORDER BY uploaded_at DESC");
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();

$result = $stmt->get_result();
$documents = $result->fetch_all(MYSQLI_ASSOC);


$storageQuery = $conn->prepare("
SELECT SUM(file_size) as total
FROM student_documents
WHERE student_id=?
");

$storageQuery->bind_param("i", $_SESSION['student_id']);
$storageQuery->execute();

$storageResult = $storageQuery->get_result();
$storageData = $storageResult->fetch_assoc();

$usedStorage = $storageData['total'] ?? 0;

$usedMB = round($usedStorage / (1024*1024),2);


$docTypes = [
"resume" => "Updated Resume/CV",
"aadhar" => "Aadhar Card",
"marksheet10" => "10th Marksheet",
"marksheet12" => "12th Marksheet",
"semester_marksheets" => "All Semester Marksheets",
"certificate" => "Internship Certificate",
"photo" => "Passport Size Photo"
];

$docStatus = [];

foreach($documents as $doc){
    $docStatus[$doc['document_type']] = $doc;
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Documents · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Document Grid */
.document-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.document-card {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    transition: transform 0.3s;
    cursor: pointer;
    border: 2px solid transparent;
}

.document-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary);
}

.document-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: white;
    font-size: 24px;
}

.document-card h4 {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 5px;
}

.document-card p {
    font-size: 12px;
    color: #666;
    margin-bottom: 10px;
}

.document-status {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
}

.status-verified {
    background: #d4edda;
    color: #155724;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

.status-missing {
    background: #f8d7da;
    color: #721c24;
}

/* Document List */
.document-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 10px;
    transition: background 0.3s;
}

.document-item:hover {
    background: #e9ecef;
}

.document-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.document-info i {
    font-size: 24px;
    color: var(--primary);
}

.document-details h4 {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 3px;
}

.document-details p {
    font-size: 12px;
    color: #666;
}

.document-actions {
    display: flex;
    gap: 10px;
}

.btn {
    padding: 8px 15px;
    border: none;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

.btn-outline {
    background: white;
    color: var(--primary);
    border: 1px solid var(--primary);
}

.btn-outline:hover {
    background: var(--primary);
    color: white;
}

.btn-danger {
    background: #dc3545;
    color: white;
}

.btn-danger:hover {
    background: #c82333;
}

/* Upload Area */
.upload-area {
    border: 2px dashed #ddd;
    border-radius: 12px;
    padding: 40px;
    text-align: center;
    background: #f8f9fa;
    cursor: pointer;
    transition: all 0.3s;
    margin-bottom: 20px;
}

.upload-area:hover {
    border-color: var(--primary);
    background: rgba(30, 60, 114, 0.05);
}

.upload-area i {
    font-size: 48px;
    color: var(--primary);
    margin-bottom: 15px;
}

.upload-area h4 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.upload-area p {
    color: #666;
    font-size: 13px;
}

/* Storage Info */
.storage-info {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
}

.storage-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.storage-bar {
    height: 8px;
    background: rgba(255,255,255,0.3);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 10px;
}

.storage-fill {
    height: 100%;
    background: white;
    width: 45%;
    border-radius: 4px;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .document-grid {
        grid-template-columns: 1fr;
    }
    
    .document-item {
        flex-direction: column;
        gap: 10px;
        align-items: flex-start;
    }
    
    .document-actions {
        width: 100%;
    }
    
    .btn {
        flex: 1;
        text-align: center;
        justify-content: center;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
<?= strtoupper(substr($studentData['full_name'],0,2)) ?>
</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="../index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="../my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="../job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="../placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="../my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="../documents.php" class="nav-item active">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="../notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="../help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>My Documents</h2>
                <p>Upload and manage your documents securely</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Storage Info -->
        <div class="storage-info">
            <div class="storage-header">
                <span>Storage Used</span>
                <?= $usedMB ?> MB of 100 MB
            </div>
            <div class="storage-bar">
                <?php $percent = min(($usedMB / 100) * 100, 100); ?>
<div class="storage-fill" style="width: <?= $percent ?>%"></div>
            </div>
            <?php $remaining = 100 - $usedMB; ?>
<p style="font-size: 12px; opacity: 0.9;">
Free storage: <?= max($remaining,0) ?> MB remaining
</p>
        </div>
        
        <!-- Quick Upload -->
      
      
        <?php

$categoryCount = [
"id" => 0,
"education" => 0,
"resume" => 0,
"certificate" => 0,
"photo" => 0
];

foreach($documents as $doc){

    if($doc['document_type']=="aadhar"){
        $categoryCount['id']++;
    }

    if(in_array($doc['document_type'],["marksheet10","marksheet12","semester_marksheets"])){
        $categoryCount['education']++;
    }

    if($doc['document_type']=="resume"){
        $categoryCount['resume']++;
    }

    if($doc['document_type']=="certificate"){
        $categoryCount['certificate']++;
    }

    if($doc['document_type']=="photo"){
        $categoryCount['photo']++;
    }
}
?>
        <!-- Document Categories -->
        <div class="document-grid">
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-id-card"></i>
                </div>
                <p><?= $categoryCount['id'] ?> documents</p>
                <?php $status = $categoryCount['id'] > 0 ? 'status-verified' : 'status-missing'; ?>
<span class="document-status <?= $status ?>">
<?= $categoryCount['id'] > 0 ? 'Uploaded' : 'Missing' ?>
</span>
            </div>
            
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <h4>Educational</h4>
                <p><?= $categoryCount['education'] ?> documents</p>

                <?php $status = $categoryCount['id'] > 0 ? 'status-verified' : 'status-missing'; ?>
<span class="document-status <?= $status ?>">
<?= $categoryCount['id'] > 0 ? 'Uploaded' : 'Missing' ?>
</span>
            </div>
            
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-file-pdf"></i>
                </div>
                <p><?= $categoryCount['resume'] ?> documents</p>

                <span class="document-status status-pending">Under Review</span>
            </div>
            
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-certificate"></i>
                </div>
                <p><?= $categoryCount['certificate'] ?> documents</p>

                <?php $status = $categoryCount['id'] > 0 ? 'status-verified' : 'status-missing'; ?>
<span class="document-status <?= $status ?>">
<?= $categoryCount['id'] > 0 ? 'Uploaded' : 'Missing' ?>
</span>
            </div>
            
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-image"></i>
                </div>
              <p><?= $categoryCount['photo'] ?> documents</p>
                <?php $status = $categoryCount['id'] > 0 ? 'status-verified' : 'status-missing'; ?>
<span class="document-status <?= $status ?>">
<?= $categoryCount['id'] > 0 ? 'Uploaded' : 'Missing' ?>
</span>
            </div>
            
            <div class="document-card">
                <div class="document-icon">
                    <i class="fas fa-file-signature"></i>
                </div>
                <h4>Others</h4>
                <p>1 document</p>
                <span class="document-status status-missing">Missing</span>
            </div>
        </div>
        
        <!-- Required Documents -->
       <?php
$totalDocs = count($docTypes);
$uploadedDocs = count($docStatus);
?>

<div class="card">
<div class="card-header">
<h3><i class="fas fa-exclamation-circle"></i> Required Documents for Placement</h3>
<span class="view-all">Complete <?= $uploadedDocs ?>/<?= $totalDocs ?></span>
</div>

<?php foreach($docTypes as $type => $label): ?>

<div class="document-item">

<div class="document-info">
<i class="fas fa-file-alt"></i>

<div class="document-details">
<h4><?= $label ?></h4>
<p>Required for placement verification</p>
</div>
</div>



<div class="document-actions">

<?php if(isset($docStatus[$type])): ?>

<a class="btn btn-outline"
href="<?= $docStatus[$type]['file_path'] ?>"
target="_blank">
<i class="fas fa-eye"></i> View
</a>

<?php if($docStatus[$type]['status']=="verified"): ?>

<span class="status-verified" style="padding:8px 15px">
Verified
</span>

<?php elseif($docStatus[$type]['status']=="pending"): ?>

<a class="btn btn-primary"
href="upload-document.php?type=<?= $type ?>">
<i class="fas fa-upload"></i> Update
</a>

<span class="status-pending" style="padding:8px 15px">
Pending
</span>

<?php else: ?>

<a class="btn btn-primary"
href="upload-document.php?type=<?= $type ?>">
<i class="fas fa-upload"></i> Re-upload
</a>

<span class="status-missing" style="padding:8px 15px">
Rejected
</span>

<?php endif; ?>

<?php else: ?>

<a class="btn btn-primary"
href="upload-document.php?type=<?= $type ?>">
<i class="fas fa-upload"></i> Upload
</a>

<span class="status-missing" style="padding:8px 15px">
Missing
</span>

<?php endif; ?>

</div>

</div> 

<?php endforeach; ?>

</div> <!-- card -->
        
        <!-- Recently Uploaded -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-clock"></i> Recently Uploaded</h3>
                <a href="#" class="view-all">View All</a>
            </div>
            
            <table class="table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8f9fa;">
                        <th style="padding: 12px; text-align: left;">Document Name</th>
                        <th style="padding: 12px; text-align: left;">Upload Date</th>
                        <th style="padding: 12px; text-align: left;">Size</th>
                        <th style="padding: 12px; text-align: left;">Status</th>
                        <th style="padding: 12px; text-align: left;">Action</th>
                    </tr>
                </thead>
               <tbody>

<?php if(!empty($documents)): ?>

<?php foreach($documents as $doc): ?>

<tr>

<td style="padding:12px;">
<?= htmlspecialchars($doc['file_name']) ?>
</td>

<td style="padding:12px;">
<?= date("M d, Y", strtotime($doc['uploaded_at'])) ?>
</td>

<td style="padding:12px;">
<?= round($doc['file_size']/1024,1) ?> KB
</td>

<td style="padding:12px;">

<?php if($doc['status']=="verified"): ?>

<span class="status-verified">Verified</span>

<?php elseif($doc['status']=="pending"): ?>

<span class="status-pending">Pending</span>

<?php else: ?>

<span class="status-missing">Rejected</span>

<?php endif; ?>

</td>

<td style="padding:12px;">

<a href="/download.php?id=<?= $doc['id'] ?>" target="_blank">

Download

</a>

</td>

</tr>

<?php endforeach; ?>

<?php else: ?>

<tr>
<td colspan="5" style="padding:12px;">No documents uploaded yet</td>
</tr>

<?php endif; ?>

</tbody>
            </table>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>

document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>