<?php

require '../../../config/session.php';
require '../../../config/db.php';

$id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM student_documents WHERE id=?");
$stmt->execute([$id]);

$doc = $stmt->fetch();

unlink($doc['file_path']);

$stmt = $conn->prepare("DELETE FROM student_documents WHERE id=?");
$stmt->execute([$id]);

header("Location: documents.php");