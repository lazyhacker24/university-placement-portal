<?php

require '../../../config/session.php';
require '../../../config/db.php';

if(!isset($_SESSION['student_id'])){
    header("Location:/login.php");
    exit();
}

$type = $_GET['type'] ?? '';

if($_SERVER['REQUEST_METHOD']=="POST"){

$student_id = $_SESSION['student_id'];
$type = $_POST['document_type'];

$file = $_FILES['document'];

$allowed = ['pdf','doc','docx','jpg','jpeg','png'];

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

if(!in_array($ext,$allowed)){
die("Invalid file type");
}

if($file['size'] > 5*1024*1024){
die("File too large");
}

$filename = time().'_'.$file['name'];

$uploadDir = "../../../uploads/documents/";

if(!is_dir($uploadDir)){
mkdir($uploadDir,0777,true);
}

$path = $uploadDir.$filename;

move_uploaded_file($file['tmp_name'],$path);

$stmt = $conn->prepare("
INSERT INTO student_documents
(student_id,document_type,file_name,file_path,file_size,status)
VALUES (?,?,?,?,?, 'pending')
ON DUPLICATE KEY UPDATE
file_name=VALUES(file_name),
file_path=VALUES(file_path),
file_size=VALUES(file_size),
status='pending'
");

$stmt->bind_param(
"isssi",
$student_id,
$type,
$filename,
$path,
$file['size']
);

$stmt->execute();

header("Location:documents.php");
exit();
}

?>

<h2>Upload Document</h2>

<form method="POST" enctype="multipart/form-data">

<input type="hidden" name="document_type" value="<?= htmlspecialchars($type) ?>">

<input type="file" name="document" required>

<br><br>

<button type="submit">Upload</button>

</form>