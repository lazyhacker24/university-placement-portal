<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';

/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: student/index.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


/* =========================
   GET STUDENT DATA
========================= */

$student_id = $_SESSION['student_id'];

/* =========================
   PERFORMANCE DATA
========================= */

// Aptitude Avg
$aptitudeQuery = $conn->prepare("
SELECT ROUND(AVG(percentage),2) as avg_score 
FROM student_tests 
WHERE student_id=? AND test_type='aptitude'
");
$aptitudeQuery->bind_param("i",$student_id);
$aptitudeQuery->execute();
$aptitudeData = $aptitudeQuery->get_result()->fetch_assoc();

// Technical Avg
$techQuery = $conn->prepare("
SELECT ROUND(AVG(percentage),2) as avg_score 
FROM student_tests 
WHERE student_id=? AND test_type='technical'
");
$techQuery->bind_param("i",$student_id);
$techQuery->execute();
$technicalData = $techQuery->get_result()->fetch_assoc();

// Rank
$rankQuery = $conn->prepare("
SELECT rank FROM student_rankings WHERE student_id=?
");
$rankQuery->bind_param("i",$student_id);
$rankQuery->execute();
$rank = $rankQuery->get_result()->fetch_assoc();

// Semester CGPA
$cgpaQuery = $conn->prepare("
SELECT semester, cgpa 
FROM student_academics 
WHERE student_id=? 
ORDER BY semester ASC
");
$cgpaQuery->bind_param("i",$student_id);
$cgpaQuery->execute();
$cgpaResult = $cgpaQuery->get_result();

// Latest Tests
$testQuery = $conn->prepare("
SELECT test_name, company, percentage, test_date 
FROM student_tests 
WHERE student_id=? 
ORDER BY test_date DESC LIMIT 5
");
$testQuery->bind_param("i",$student_id);
$testQuery->execute();
$testResults = $testQuery->get_result();
// Class Average
$classAvg = $conn->query("SELECT metric, average_value FROM class_average");
$classData = [];
while($row = $classAvg->fetch_assoc()){
    $classData[$row['metric']] = $row['average_value'];
}

$stmt = $conn->prepare("
SELECT full_name, roll_no, course, cgpa
FROM students
WHERE id=?
");

$stmt->bind_param("i",$student_id);
$stmt->execute();

$studentData = $stmt->get_result()->fetch_assoc();



$codingQuery = $conn->prepare("
SELECT ROUND(AVG(percentage),2) as avg_score 
FROM student_tests 
WHERE student_id=? AND test_type='coding'
");
$codingQuery->bind_param("i",$student_id);
$codingQuery->execute();
$codingData = $codingQuery->get_result()->fetch_assoc();


$improveQuery = $conn->prepare("
SELECT area_name FROM improvement_areas WHERE student_id=?
");
$improveQuery->bind_param("i",$student_id);
$improveQuery->execute();
$improvementData = $improveQuery->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Performance · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}

.stat-box {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    padding: 20px;
    border-radius: 12px;
    text-align: center;
}

.stat-box h4 {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 5px;
}

.stat-box p {
    font-size: 13px;
    opacity: 0.9;
}

/* Progress Bars */
.progress-item {
    margin-bottom: 20px;
}

.progress-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
    font-size: 14px;
}

.progress-bar {
    height: 8px;
    background: #eee;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    border-radius: 4px;
    transition: width 0.3s ease;
}

/* Chart Placeholder */
.chart-container {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 20px;
    text-align: center;
    color: #666;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Test Cards */
.test-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 10px;
}

.test-info h4 {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 5px;
}

.test-info p {
    font-size: 12px;
    color: #666;
}

.test-score {
    font-size: 18px;
    font-weight: 700;
    color: var(--primary);
}

/* Comparison Table */
.comparison-table {
    width: 100%;
    border-collapse: collapse;
}

.comparison-table th {
    text-align: left;
    padding: 12px;
    background: #f8f9fa;
    color: #666;
    font-weight: 600;
    font-size: 13px;
}

.comparison-table td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

.highlight {
    color: var(--primary);
    font-weight: 600;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
<?= strtoupper(substr($studentData['full_name'],0,2)) ?>
</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item active">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>My Performance</h2>
                <p>Track your academic and placement preparation progress</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Stats Overview -->
        <div class="stats-grid">
            <div class="stat-box">
                <h4><?= htmlspecialchars($studentData['cgpa']) ?></h4>
<p>Current CGPA</p>
            </div>
            <div class="stat-box" style="background: linear-gradient(135deg, #28a745, #20c997);">
                <h4><?= $aptitudeData['avg_score'] ?? 0 ?>%</h4>
<p>Aptitude Avg</p>
            </div>
            <div class="stat-box" style="background: linear-gradient(135deg, #ff7e5f, #feb47b);">
                <h4><?= $technicalData['avg_score'] ?? 0 ?>%</h4>
<p>Technical Score</p>
            </div>
            <div class="stat-box" style="background: linear-gradient(135deg, #6f42c1, #e83e8c);">
                <h4>#<?= $rank['rank'] ?? 'N/A' ?></h4>
<p>Class Rank</p>
            </div>
        </div>
        
        <!-- Academic Progress -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-line"></i> Academic Progress</h3>
                <select class="filter-select" style="padding: 5px 10px; border: 1px solid #ddd; border-radius: 5px;">
                    <option>All Semesters</option>
                    <option>Semester 1</option>
                    <option>Semester 2</option>
                    <option>Semester 3</option>
                    <option>Semester 4</option>
                </select>
            </div>
            
            
          <?php if($cgpaResult->num_rows > 0): ?>
    
    <?php while($row = $cgpaResult->fetch_assoc()): ?>
    <div class="progress-item">
        <div class="progress-header">
            <span>Semester <?= $row['semester'] ?></span>
            <span><?= $row['cgpa'] ?> CGPA</span>
        </div>
        <div class="progress-bar">
            <div class="progress-fill" style="width: <?= $row['cgpa'] * 10 ?>%"></div>
        </div>
    </div>
    <?php endwhile; ?>

<?php else: ?>

    <p style="color:#666;">No academic data found</p>

<?php endif; ?>
        
        <!-- Performance Chart -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Performance Trend</h3>
                <span class="view-all">Last 6 Semesters</span>
            </div>
            
            <div class="chart-container">
                <canvas id="cgpaChart"></canvas>
            </div>
        </div>
        
        <!-- Test Performance -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-tasks"></i> Test Performance</h3>
                <span class="view-all">View All Tests</span>
            </div>
            
            <?php if($testResults->num_rows > 0): ?>

    <?php while($t = $testResults->fetch_assoc()): ?>
    <div class="test-card">
        ...
    </div>
    <?php endwhile; ?>

<?php else: ?>

    <p style="color:#666;">No test data available</p>

<?php endif; ?>
        
        <!-- Comparison with Class Average -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-users"></i> vs Class Average</h3>
            </div>
            
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <th>Your Score</th>
                        <th>Class Average</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>CGPA</td>
                        <td class="highlight"><?= htmlspecialchars($studentData['cgpa']) ?></td>
                        <td><?= $classData['cgpa'] ?? 0 ?></td>
                        <?php
$status = ($studentData['cgpa'] ?? 0) > ($classData['cgpa'] ?? 0) ? 'Above Average' : 'Below Average';
?>
<td>
    <span style="color:<?= $status=='Above Average'?'green':'red' ?>;">
        <?= $status ?>
    </span>
</td>
                    </tr>
                    <tr>
                        <td>Aptitude Score</td>
                        <td class="highlight"><?= $aptitudeData['avg_score'] ?? 0 ?>%</td>
                        <td><?= $classData['aptitude'] ?? 0 ?>%</td>
                       <?php
$status = ($aptitudeData['avg_score'] ?? 0) > ($classData['aptitude'] ?? 0) ? 'Above Average' : 'Below Average';
?>
<td>
    <span style="color:<?= $status=='Above Average'?'green':'red' ?>;">
        <?= $status ?>
    </span>
</td>
                    </tr>
                    <tr>
                        <td>Technical Score</td>
                        <td class="highlight"><?= $technicalData['avg_score'] ?? 0 ?>%</td>
                        <td><?= $classData['technical'] ?? 0 ?>%</td>
                        <?php
$status = ($aptitudeData['avg_score'] ?? 0) > ($classData['aptitude'] ?? 0) ? 'Above Average' : 'Below Average';
?>
<td>
    <span style="color:<?= $status=='Above Average'?'green':'red' ?>;">
        <?= $status ?>
    </span>
</td>
                    </tr>
                    <tr>
                        <td>Coding Score</td>
                        <td class="highlight"><?= $codingData['avg_score'] ?? 0 ?>%</td>
<td><?= $classData['coding'] ?? 0 ?>%</td>
                        <?php
$status = ($aptitudeData['avg_score'] ?? 0) > ($classData['aptitude'] ?? 0) ? 'Above Average' : 'Below Average';
?>
<td>
    <span style="color:<?= $status=='Above Average'?'green':'red' ?>;">
        <?= $status ?>
    </span>
</td>
                    </tr>
                   <tr>
    <td>Attendance</td>
    <td class="highlight"><?= $classData['attendance'] ?? 0 ?>%</td>
    <td><?= $classData['attendance'] ?? 0 ?>%</td>
    <td><span style="color:#28a745;">Above Average</span></td>
</tr>
                </tbody>
            </table>
        </div>
        
        <!-- Improvement Areas -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-bullseye"></i> Areas for Improvement</h3>
            </div>
            
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                <?php while($imp = $improvementData->fetch_assoc()): ?>
<span style="background:#eee; padding:8px 15px; border-radius:20px;">
    <?= htmlspecialchars($imp['area_name']) ?>
</span>
<?php endwhile; ?>
            </div>
            
            <div style="margin-top: 20px;">
                <h4 style="font-size: 14px; margin-bottom: 10px;">Recommended Actions:</h4>
                <ul style="list-style: none; color: #666; font-size: 13px;">
                    <li style="margin-bottom: 8px;"><i class="fas fa-arrow-right" style="color: var(--primary);"></i> Practice more DSA problems on LeetCode</li>
                    <li style="margin-bottom: 8px;"><i class="fas fa-arrow-right" style="color: var(--primary);"></i> Attend system design workshop on March 15</li>
                    <li style="margin-bottom: 8px;"><i class="fas fa-arrow-right" style="color: var(--primary);"></i> Take mock tests to improve speed</li>
                </ul>
            </div>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const cgpaLabels = [];
const cgpaData = [];

<?php
mysqli_data_seek($cgpaResult, 0); // reset pointer
while($row = $cgpaResult->fetch_assoc()){
    echo "cgpaLabels.push('Sem ".$row['semester']."');";
    echo "cgpaData.push(".$row['cgpa'].");";
}
?>

new Chart(document.getElementById('cgpaChart'), {
    type: 'line',
    data: {
        labels: cgpaLabels,
        datasets: [{
            label: 'CGPA',
            data: cgpaData,
            borderWidth: 2
        }]
    }
});
</script>



<script>
// Filter functionality
document.querySelector('.filter-select').addEventListener('change', function() {
    console.log('Filter changed to:', this.value);
    // Here you would filter the data based on semester
});

// Sidebar navigation
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>