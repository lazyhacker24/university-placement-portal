<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../../config/session.php';
require_once '../../config/db.php';

if(!isset($_SESSION['student_id'])){
    header("Location: /student");
    exit;
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */
$student_id = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i",$student_id);
$stmt->execute();

$result = $stmt->get_result();
$studentData = $result->fetch_assoc();

if(!$studentData){
    die("Student not found");
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){

if($_POST['csrf_token'] !== $_SESSION['csrf_token']){
die("Invalid CSRF token");
}

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];
$address = $_POST['address'];

$stmt = $conn->prepare("
UPDATE students 
SET full_name=?, email=?, phone=?, dob=?, address=? 
WHERE id=?
");

$stmt->bind_param("sssssi",
$name,
$email,
$phone,
$dob,
$address,
$student_id
);

$stmt->execute();

header("Location: my-profile.php?updated=1");
exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

.view-all {
    color: var(--primary);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
    background: none;
    border: none;
    cursor: pointer;
}

/* Form Styles */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    color: #666;
    font-size: 13px;
    font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: 'Inter', sans-serif;
    font-size: 14px;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary);
}

.form-row {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.btn {
    padding: 12px 25px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

.btn-secondary {
    background: white;
    color: var(--primary);
    border: 1px solid var(--primary);
}

/* Profile Info */
.profile-info {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.info-group {
    margin-bottom: 15px;
}

.info-label {
    color: #666;
    font-size: 12px;
    margin-bottom: 5px;
}

.info-value {
    font-weight: 600;
    color: var(--dark);
    font-size: 15px;
}

/* Table Styles */
.table {
    width: 100%;
    border-collapse: collapse;
}

.table th {
    text-align: left;
    padding: 12px;
    background: #f8f9fa;
    color: #666;
    font-weight: 600;
    font-size: 13px;
}

.table td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

.table tr:last-child td {
    border-bottom: none;
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
<?= strtoupper(substr($studentData['full_name'] ?? 'ST',0,2)) ?>
</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['full_name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['course']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item active">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>My Profile</h2>
                <p>Manage your personal and academic information</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Profile Information -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-user-circle"></i> Personal Information</h3>
                <button class="view-all" onclick="enableEdit()"><i class="fas fa-edit"></i> Edit Profile</button>
            </div>
            
            <div class="profile-info" id="profileView">
                <div class="info-group">
                    <div class="info-label">Full Name</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['full_name']) ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Roll Number</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['roll_no']) ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Program</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['course']) ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Semester</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['semester']) ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Batch</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['batch_year'] ?? '') ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">CGPA</div>
                    <div class="info-value"><?= htmlspecialchars($studentData['cgpa']) ?></div>
                </div>
                <div class="info-group">
    <div class="info-label">Email</div>
    <div class="info-value">
        <?= htmlspecialchars($studentData['email'] ?? '') ?>
    </div>
</div>
                <div class="info-group">
    <div class="info-label">Phone</div>
    <div class="info-value">
        <?= htmlspecialchars($studentData['phone'] ?? '') ?>
    </div>
</div>
            </div>
            
            <!-- Edit Form (Hidden by default) -->
            <div id="profileEdit" style="display: none;">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="name" value="<?= htmlspecialchars($studentData['full_name']) ?>">
                        </div>
                        <div class="form-group">
    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($studentData['email'] ?? '') ?>">
</div>
</div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" value="<?= htmlspecialchars($studentData['phone'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" value="2003-05-15">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" rows="3">Mathura, Uttar Pradesh</textarea>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn">Save Changes</button>
                        <button type="button" class="btn btn-secondary" onclick="disableEdit()">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Academic Details -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-graduation-cap"></i> Academic Details</h3>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Qualification</th>
                        <th>Institute/Board</th>
                        <th>Year of Passing</th>
                        <th>Percentage/CGPA</th>
                    </tr>
                </thead>
                <tbody>

<tr>
<td>10th (SSC)</td>
<td>Board</td>
<td><?= htmlspecialchars($studentData['batch_year']-6 ?? '') ?></td>
<td><?= htmlspecialchars($studentData['tenth_percent'] ?? '') ?>%</td>
</tr>

<tr>
<td>12th (HSC)</td>
<td>Board</td>
<td><?= htmlspecialchars($studentData['batch_year']-4 ?? '') ?></td>
<td><?= htmlspecialchars($studentData['twelfth_percent'] ?? '') ?>%</td>
</tr>

<tr>
<td><?= htmlspecialchars($studentData['course'] ?? '') ?></td>
<td>GLA University</td>
<td><?= htmlspecialchars($studentData['batch_year'] ?? '') ?></td>
<td><?= htmlspecialchars($studentData['cgpa'] ?? '') ?> CGPA</td>
</tr>

</tbody>
            </table>
        </div>
        
        <!-- Skills -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-code"></i> Technical Skills</h3>
                <button class="view-all"><i class="fas fa-plus"></i> Add Skill</button>
            </div>
            
            <div style="display:flex;flex-wrap:wrap;gap:10px;">

<?php
if(!empty($studentData['skills'])){

$skills = explode(',', $studentData['skills']);

foreach($skills as $skill){
?>

<span style="background: rgba(30, 60, 114, 0.1); 
color: var(--primary); 
padding: 5px 15px; 
border-radius: 20px; 
font-size: 13px;">

<?= htmlspecialchars(trim($skill)) ?>

</span>

<?php } } ?>

</div>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>
function enableEdit() {
    document.getElementById('profileView').style.display = 'none';
    document.getElementById('profileEdit').style.display = 'block';
}

function disableEdit() {
    document.getElementById('profileView').style.display = 'grid';
    document.getElementById('profileEdit').style.display = 'none';
}

// Sidebar navigation active state
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            // Don't remove active if it's a link
            if(this.tagName === 'A') return;
            
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>