<?php
require_once __DIR__ . '/../../config/db.php';
session_start();

$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE student_id = ?");
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();

echo "done";
?>