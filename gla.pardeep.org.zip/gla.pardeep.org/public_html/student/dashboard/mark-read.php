<?php
require_once __DIR__ . '/../../config/db.php';
session_start();

if(isset($_POST['id'])){
    $id = intval($_POST['id']);

    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    echo "success";
}
?>