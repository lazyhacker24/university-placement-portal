<?php 
ini_set('display_errors',1); 
error_reporting(E_ALL); 

require_once '../../config/session.php'; 
require_once '../../config/db.php';

/* =========================
   CHECK IF LOGGED IN
========================= */
if(!isset($_SESSION['student_id'])) {
    header('Location: student/index.php');
    exit();
}

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   GET STUDENT DATA
========================= */
$studentData = [
    'name' => 'Pardeep Kumar',
    'roll_no' => 'GLA2011001',
    'program' => 'B.Tech Computer Science',
    'semester' => '6th Semester',
    'batch' => '2021-2025',
    'cgpa' => '8.7',
    'profile_completion' => 75
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Help & Support · GLA University</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/student-dashboard.css">
<style>
:root {
    --primary: #1e3c72;
    --secondary: #2a5298;
    --accent: #ff7e5f;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --light: #f8f9fa;
    --dark: #343a40;
    --sidebar-width: 280px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
}

.dot-pattern {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    position: relative;
    z-index: 1;
}

/* Sidebar Styles */
.sidebar {
    width: var(--sidebar-width);
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255,255,255,0.2);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.sidebar-header .logo-icon {
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: var(--primary);
    font-size: 24px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.sidebar-header h3 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
}

.sidebar-header p {
    font-size: 13px;
    opacity: 0.9;
}

.user-info {
    padding: 20px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.user-details h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--dark);
}

.user-details p {
    font-size: 13px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 5px;
}

.user-details p i {
    color: var(--primary);
    font-size: 12px;
}

.sidebar-nav {
    padding: 20px 0;
}

.nav-item {
    padding: 12px 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #666;
    transition: all 0.3s;
    cursor: pointer;
    border-left: 3px solid transparent;
    text-decoration: none;
}

.nav-item i {
    width: 20px;
    font-size: 16px;
    color: var(--primary);
}

.nav-item:hover {
    background: rgba(30, 60, 114, 0.05);
    border-left-color: var(--primary);
    color: var(--primary);
}

.nav-item.active {
    background: rgba(30, 60, 114, 0.1);
    border-left-color: var(--primary);
    color: var(--primary);
    font-weight: 500;
}

.nav-item .badge {
    margin-left: auto;
    background: var(--accent);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding: 20px 30px;
}

.top-bar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.page-title h2 {
    font-size: 22px;
    font-weight: 600;
    color: white;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.page-title p {
    font-size: 13px;
    color: rgba(255,255,255,0.9);
}

.top-bar-actions {
    display: flex;
    gap: 15px;
}

.notification-badge {
    position: relative;
    cursor: pointer;
}

.notification-badge i {
    font-size: 20px;
    color: white;
}

.badge-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--accent);
    color: white;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

/* Card Styles */
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-header h3 i {
    color: var(--primary);
}

/* Help Grid */
.help-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.help-card {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 25px 20px;
    text-align: center;
    transition: transform 0.3s;
    cursor: pointer;
    text-decoration: none;
    color: inherit;
    display: block;
}

.help-card:hover {
    transform: translateY(-5px);
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.help-card:hover i {
    color: white;
}

.help-card i {
    font-size: 36px;
    color: var(--primary);
    margin-bottom: 15px;
    transition: color 0.3s;
}

.help-card h4 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 5px;
}

.help-card p {
    font-size: 12px;
    color: #666;
}

.help-card:hover p {
    color: rgba(255,255,255,0.9);
}

/* FAQ Section */
.faq-item {
    border-bottom: 1px solid #eee;
    padding: 15px 0;
}

.faq-item:last-child {
    border-bottom: none;
}

.faq-question {
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    font-weight: 500;
    color: var(--dark);
}

.faq-question i {
    color: var(--primary);
    transition: transform 0.3s;
}

.faq-answer {
    margin-top: 10px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
    color: #666;
    font-size: 14px;
    display: none;
}

.faq-item.active .faq-answer {
    display: block;
}

.faq-item.active .faq-question i {
    transform: rotate(90deg);
}

/* Contact Info */
.contact-info {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 15px;
}

.contact-icon {
    width: 50px;
    height: 50px;
    background: rgba(30, 60, 114, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--primary);
    font-size: 20px;
}

.contact-details h4 {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 5px;
}

.contact-details p {
    font-size: 13px;
    color: #666;
}

.contact-details a {
    color: var(--primary);
    text-decoration: none;
}

/* Form Styles */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    color: #666;
    font-size: 13px;
    font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: 'Inter', sans-serif;
    font-size: 14px;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary);
}

.btn {
    padding: 12px 25px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    width: 100%;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
}

/* Floating Label */
#dashboardFloating {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 13px;
    color: var(--dark);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(5px);
}

#dashboardFloating i {
    color: var(--primary);
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .help-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 480px) {
    .help-grid {
        grid-template-columns: 1fr;
    }
}
</style>
</head>
<body>

<div class="dot-pattern"></div>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h3>GLA University</h3>
            <p>Smart Placement System</p>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">PK</div>
            <div class="user-details">
                <h4><?= htmlspecialchars($studentData['name']) ?></h4>
                <p><i class="fas fa-id-card"></i> <?= htmlspecialchars($studentData['roll_no']) ?></p>
                <p><i class="fas fa-book"></i> <?= htmlspecialchars($studentData['program']) ?></p>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="my-profile.php" class="nav-item">
                <i class="fas fa-user-graduate"></i>
                <span>My Profile</span>
            </a>
            <a href="job-applications.php" class="nav-item">
                <i class="fas fa-briefcase"></i>
                <span>Job Applications</span>
                <span class="badge">3</span>
            </a>
            <a href="placement-drives.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                <span>Placement Drives</span>
            </a>
            <a href="my-performance.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                <span>My Performance</span>
            </a>
            <a href="documents/index.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
                <span class="badge">2</span>
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="help-support.php" class="nav-item active">
                <i class="fas fa-question-circle"></i>
                <span>Help & Support</span>
            </a>
            <a href="logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h2>Help & Support</h2>
                <p>Get assistance and find answers to your questions</p>
            </div>
            <div class="top-bar-actions">
                <div class="notification-badge">
                    <i class="fas fa-bell"></i>
                    <span class="badge-count">5</span>
                </div>
                <div class="notification-badge">
                    <i class="fas fa-envelope"></i>
                    <span class="badge-count">2</span>
                </div>
            </div>
        </div>
        
        <!-- Quick Help Categories -->
        <div class="help-grid">
            <a href="#" class="help-card">
                <i class="fas fa-question-circle"></i>
                <h4>FAQs</h4>
                <p>Frequently asked questions</p>
            </a>
            <a href="#" class="help-card">
                <i class="fas fa-book-open"></i>
                <h4>User Guide</h4>
                <p>Learn how to use the system</p>
            </a>
            <a href="#" class="help-card">
                <i class="fas fa-video"></i>
                <h4>Video Tutorials</h4>
                <p>Watch step-by-step guides</p>
            </a>
            <a href="#" class="help-card">
                <i class="fas fa-headset"></i>
                <h4>Contact Support</h4>
                <p>Get in touch with our team</p>
            </a>
        </div>
        
        <!-- FAQ Section -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-question-circle"></i> Frequently Asked Questions</h3>
                <input type="text" placeholder="Search FAQs..." style="padding: 8px 15px; border: 1px solid #ddd; border-radius: 20px; font-size: 13px;">
            </div>
            
            <div class="faq-item active">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>How do I apply for a placement drive?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    To apply for a placement drive, go to the "Placement Drives" section, find the drive you're interested in, and click the "Register" button. Make sure your profile is complete and documents are uploaded before applying.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>What documents are required for placement?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    Required documents include: Updated Resume, Aadhar Card, PAN Card, 10th & 12th Marksheets, all Semester Marksheets, Passport size photo, and any internship/certificates.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>How can I check my application status?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    You can check your application status in the "Job Applications" section. The status will be updated as Pending, Under Review, Shortlisted, or Rejected.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>What is the eligibility criteria for placement drives?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    Eligibility criteria vary by company. Generally, students must have a minimum CGPA of 6.5-7.0, no active backlogs, and meet specific skill requirements mentioned in the drive details.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>How do I update my profile information?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    Go to "My Profile" section and click the "Edit Profile" button. You can update your personal information, academic details, and skills there. Don't forget to save your changes.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    <span>I forgot my password. What should I do?</span>
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="faq-answer">
                    Click on "Forgot Password" on the login page and follow the instructions. You'll receive an email with password reset link. Contact support if you face any issues.
                </div>
            </div>
        </div>
        
        <!-- Contact Support and Quick Links -->
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
            <!-- Contact Form -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-envelope"></i> Send a Message</h3>
                </div>
                
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    
                    <div class="form-group">
                        <label>Subject</label>
                        <select name="subject" required>
                            <option value="">Select a topic</option>
                            <option value="technical">Technical Issue</option>
                            <option value="account">Account Related</option>
                            <option value="placement">Placement Query</option>
                            <option value="document">Document Verification</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Message</label>
                        <textarea name="message" rows="5" placeholder="Describe your issue or question in detail..." required></textarea>
                    </div>
                    
                    <button type="submit" class="btn">Send Message</button>
                </form>
            </div>
            
            <!-- Contact Information -->
            <div>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-phone-alt"></i> Contact Info</h3>
                    </div>
                    
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Phone Support</h4>
                            <p><a href="tel:+911234567890">+91 12345 67890</a></p>
                            <p style="font-size: 11px;">Mon-Fri, 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                    
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Email Support</h4>
                            <p><a href="mailto:placement@gla.ac.in">placement@gla.ac.in</a></p>
                            <p style="font-size: 11px;">Response within 24 hours</p>
                        </div>
                    </div>
                    
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Visit Us</h4>
                            <p>Training & Placement Cell</p>
                            <p>GLA University, Mathura</p>
                        </div>
                    </div>
                    
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Office Hours</h4>
                            <p>Monday - Saturday</p>
                            <p>10:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-link"></i> Quick Links</h3>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <a href="#" style="color: var(--primary); text-decoration: none; padding: 8px; background: #f8f9fa; border-radius: 5px;">
                            <i class="fas fa-download"></i> Download User Manual
                        </a>
                        <a href="#" style="color: var(--primary); text-decoration: none; padding: 8px; background: #f8f9fa; border-radius: 5px;">
                            <i class="fas fa-video"></i> Video Tutorials
                        </a>
                        <a href="#" style="color: var(--primary); text-decoration: none; padding: 8px; background: #f8f9fa; border-radius: 5px;">
                            <i class="fas fa-bug"></i> Report a Problem
                        </a>
                        <a href="#" style="color: var(--primary); text-decoration: none; padding: 8px; background: #f8f9fa; border-radius: 5px;">
                            <i class="fas fa-comment"></i> Give Feedback
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Floating Label -->
<div id="dashboardFloating">
    <i class="fas fa-graduation-cap"></i>
    Student Dashboard · GLA University SPMS
</div>

<script>
// Toggle FAQ answers
function toggleFAQ(element) {
    const faqItem = element.closest('.faq-item');
    faqItem.classList.toggle('active');
}

// FAQ Search
document.querySelector('.card-header input').addEventListener('keyup', function(e) {
    const searchTerm = this.value.toLowerCase();
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question span').textContent.toLowerCase();
        const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
        
        if(question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
});

// Form submission
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Your message has been sent. Support team will respond within 24 hours.');
    this.reset();
});

// Sidebar navigation
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if(this.tagName === 'A') return;
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>