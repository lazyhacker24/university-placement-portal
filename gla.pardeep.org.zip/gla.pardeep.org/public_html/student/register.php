<?php
require_once '../config/session.php';

redirectIfLoggedIn();

if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token']=bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GLA University · Student Registration</title>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Poppins:wght@500;600&display=swap">

<link rel="stylesheet" href="/assets/css/student-login.css">
</head>

<body>

<div class="dot-pattern"></div>
<div class="student-bg"></div>

<div class="login-container">

<a href="/student/login.php" class="back-home">
<i class="fas fa-arrow-left"></i> Back to Login
</a>

<div class="login-card">

<div class="login-header">
<div class="logo-icon">
<i class="fas fa-user-plus"></i>
</div>

<h2>Student Registration</h2>
<p>GLA University · Smart Placement System</p>

<div class="role-badge">
<i class="fas fa-user-graduate"></i> New Student
</div>
</div>

<!-- REGISTER FORM -->
<form action="register_process.php" method="POST" id="registerForm">

<input type="hidden" name="csrf_token"
value="<?= $_SESSION['csrf_token']; ?>">

<div class="form-group">
<label>Full Name</label>
<div class="input-wrapper">
<i class="fas fa-user"></i>
<input type="text" name="full_name" required>
</div>
</div>

<div class="form-group">
<label>Roll Number</label>
<div class="input-wrapper">
<i class="fas fa-id-badge"></i>
<input type="text" name="roll_no" placeholder="GLA2011001" required>
</div>
</div>

<div class="form-group">
<label>Course</label>
<div class="input-wrapper">
<i class="fas fa-graduation-cap"></i>
<input type="text" name="course" placeholder="BCA / MCA / B.Tech" required>
</div>
</div>

<div class="form-group">
<label>Branch</label>
<div class="input-wrapper">
<i class="fas fa-code-branch"></i>
<input type="text" name="branch" required>
</div>
</div>

<div class="form-group">
<label>Email</label>
<div class="input-wrapper">
<i class="fas fa-envelope"></i>
<input type="email" name="email" required>
</div>
</div>

<div class="form-group">
<label>Phone</label>
<div class="input-wrapper">
<i class="fas fa-phone"></i>
<input type="tel" name="phone" required>
</div>
</div>

<div class="form-group">
<label>Password</label>
<div class="input-wrapper">
<i class="fas fa-key"></i>
<input type="password" name="password" id="password" required>
</div>
</div>

<div class="form-group">
<label>Confirm Password</label>
<div class="input-wrapper">
<i class="fas fa-check-circle"></i>
<input type="password" name="confirm_password" id="confirm_password" required>
</div>
</div>

<button type="submit" class="login-submit">
<i class="fas fa-user-check"></i> Register
</button>

<div class="new-user-section">
<p>Already registered?</p>
<a href="/student/login.php" class="register-link">
<i class="fas fa-sign-in-alt"></i> Login Here
</a>
</div>

</form>
</div>

<div style="text-align:center;margin-top:20px;">
<span class="version-note">
<i class="fas fa-shield-alt"></i>
GLA University SPMS · Student Portal
</span>
</div>

</div>

<!-- Floating Pill -->
<div id="studentFloating">
<i class="fas fa-user-plus"></i>
Student Registration © Pardeep Kumar
</div>

<script>
document.getElementById("registerForm").addEventListener("submit",function(e){

let p=document.getElementById("password").value;
let c=document.getElementById("confirm_password").value;

if(p!==c){
e.preventDefault();
alert("Passwords do not match!");
}
});
</script>

</body>
</html>