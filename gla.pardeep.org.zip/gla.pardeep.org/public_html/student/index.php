<?php
require_once '../config/session.php';

/* =========================
   REDIRECT IF LOGGED IN
========================= */
redirectIfLoggedIn();

/* =========================
   CSRF TOKEN
========================= */
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token']=bin2hex(random_bytes(32));
}

/* =========================
   FLASH MESSAGE
========================= */
$msg = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>GLA University · Student Login</title>

<link rel="stylesheet"
href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">

<link rel="stylesheet"
href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap">

<link rel="stylesheet" href="/assets/css/student-login.css">

</head>

<body>

<div class="dot-pattern"></div>
<div class="student-bg"></div>

<div class="login-container">

<a href="/" class="back-home">
<i class="fas fa-arrow-left"></i> Back to Home
</a>

<!-- ================= CARD ================= -->
<div class="login-card">

<?php if(!empty($msg)): ?>
<div class="login-error">
<?= htmlspecialchars($msg) ?>
</div>
<?php endif; ?>

<!-- HEADER -->
<div class="login-header">
<div class="logo-icon">
<i class="fas fa-graduation-cap"></i>
</div>

<h2>Student Login</h2>
<p>GLA University · Smart Placement System</p>

<div class="role-badge">
<i class="fas fa-user-graduate"></i> Student Access
</div>
</div>

<!-- ================= FORM ================= -->
<form id="studentLoginForm"
action="login_process.php"
method="POST"
autocomplete="off">

<input type="hidden"
name="csrf_token"
value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>">

<!-- Roll Number -->
<div class="form-group">
<label>
<i class="fas fa-id-card"></i> Roll Number
</label>

<div class="input-wrapper">
<i class="fas fa-id-badge"></i>
<input type="text"
name="roll_no"
id="rollno"
placeholder="e.g. GLA2011001"
required>
</div>

<div class="field-hint">
<i class="fas fa-info-circle"></i>
Enter your university roll number
</div>
</div>

<!-- Password -->
<div class="form-group">
<label>
<i class="fas fa-lock"></i> Password
</label>

<div class="input-wrapper">
<i class="fas fa-key"></i>
<input type="password"
name="password"
id="password"
required>
</div>
</div>

<!-- OPTIONS -->
<div class="login-options">
<a href="/student/forgot.php" class="link-btn">
<i class="fas fa-question-circle"></i>
Forgot Password?
</a>
</div>

<!-- LOGIN BUTTON -->
<button type="submit" class="login-submit">
<i class="fas fa-sign-in-alt"></i>
Student Login
</button>

<!-- REGISTER -->
<div class="new-user-section">
<p>Don't have a student account?</p>

<a href="/student/register.php" class="register-link">
<i class="fas fa-user-graduate"></i>
Register as Student
</a>
</div>

</form>
</div>

<!-- FOOTER NOTE -->
<div style="text-align:center;margin-top:20px;">
<span class="version-note">
<i class="fas fa-shield-alt"></i>
GLA University SPMS · Student Portal
</span>
</div>

</div>

<!-- FLOATING LABEL -->
<div id="studentFloating">
<i class="fas fa-graduation-cap"></i>
Student Login · © Pardeep Kumar · GLA University
</div>

<!-- ================= JS VALIDATION ================= -->
<script>
document.getElementById('studentLoginForm')
.addEventListener('submit',function(e){

const roll=document.getElementById('rollno').value.trim();
const pass=document.getElementById('password').value.trim();

if(!roll || !pass){
e.preventDefault();
alert("Please enter roll number and password");
}
});
</script>

</body>
</html>