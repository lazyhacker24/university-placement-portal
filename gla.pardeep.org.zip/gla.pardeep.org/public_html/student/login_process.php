<?php
require_once '../config/session.php';
require_once '../config/db.php';

if($_SERVER['REQUEST_METHOD']!=='POST'){
    header("Location: /student");
    exit;
}

if($_POST['csrf_token']!==$_SESSION['csrf_token']){
    die("Invalid request");
}

$roll=strtoupper(trim($_POST['roll_no']));
$password=$_POST['password'];

if(empty($roll)||empty($password)){
    setFlash("Please fill all fields.");
    header("Location: /student/index.php");
    exit;
}

$stmt=$conn->prepare("
SELECT id,full_name,password,status
FROM students WHERE roll_no=? LIMIT 1
");

$stmt->bind_param("s",$roll);
$stmt->execute();
$res=$stmt->get_result();

if($res->num_rows===0){
    setFlash("Student account not found.");
    header("Location: /student/index.php");
    exit;
}

$user=$res->fetch_assoc();

if(!password_verify($password,$user['password'])){
    setFlash("Incorrect password.");
    header("Location: /student/index.php");
    exit;
}

if($user['status']=="pending"){
    setFlash("Account awaiting approval.");
    header("Location: /student/index.php");
    exit;
}

if($user['status']=="rejected"){
    setFlash("Account rejected.");
    header("Location: /student/index.php");
    exit;
}

/* LOGIN SUCCESS */
session_regenerate_id(true);

$_SESSION['student_id']=$user['id'];
$_SESSION['user_name']=$user['full_name'];
$_SESSION['user_role']="student";

unset($_SESSION['csrf_token']);

header("Location: /student/dashboard/index.php");
exit;