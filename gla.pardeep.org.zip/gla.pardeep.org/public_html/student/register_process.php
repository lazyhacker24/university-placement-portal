<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../config/session.php';
require_once '../config/db.php';
require_once '../config/mail.php';

if($_SERVER['REQUEST_METHOD']!=='POST'){
    header("Location: register.php");
    exit;
}

/* CSRF CHECK */
if($_POST['csrf_token']!==$_SESSION['csrf_token']){
    die("Invalid request");
}

$name=trim($_POST['full_name']);
$roll=strtoupper(trim($_POST['roll_no']));
$course=trim($_POST['course']);
$branch=trim($_POST['branch']);
$email=trim($_POST['email']);
$phone=trim($_POST['phone']);
$pass=$_POST['password'];
$confirm=$_POST['confirm_password'];

if(empty($name)||empty($roll)||empty($email)||empty($pass)){
    setFlash("Please fill all fields.");
    header("Location: register.php");
    exit;
}

if($pass!==$confirm){
    setFlash("Passwords do not match.");
    header("Location: register.php");
    exit;
}

/* CHECK EXISTING */
$stmt=$conn->prepare("SELECT id FROM students WHERE roll_no=? OR email=?");
$stmt->bind_param("ss",$roll,$email);
$stmt->execute();
$res=$stmt->get_result();

if($res->num_rows>0){
    setFlash("Account already exists.");
    header("Location: register.php");
    exit;
}

/* HASH PASSWORD */
$hash=password_hash($pass,PASSWORD_DEFAULT);

/* INSERT */
$stmt=$conn->prepare("
INSERT INTO students
(full_name,roll_no,course,branch,email,phone,password,status,created_at)
VALUES (?,?,?,?,?,?,?,'pending',NOW())
");

$stmt->bind_param(
"sssssss",
$name,$roll,$course,$branch,$email,$phone,$hash
);

$stmt->execute();

/* =========================
   SEND REGISTRATION EMAIL
========================= */

$subject="GLA Placement Portal Registration";

$message="
<h3>Dear $name,</h3>

<p>Greetings from <b>GLA University Placement Cell</b>.</p>

<p>Your registration request has been received successfully.</p>

<p><b>Status:</b> Under Manual Verification</p>

<p>You will receive approval email once verified.</p>

<hr>
<p>Regards,<br>
GLA Placement Team</p>
";

sendMail($email,$name,$subject,$message);

setFlash("Registration submitted. Wait for Placement Officer approval.");
header("Location: login.php");
exit;