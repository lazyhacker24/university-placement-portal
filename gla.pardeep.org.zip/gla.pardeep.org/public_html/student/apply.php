<?php
require_once '../config/session.php';
require_once '../config/db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$student=$_SESSION['user_id'];
$job=(int)$_GET['job'];

$stmt=$conn->prepare("
INSERT IGNORE INTO applications(student_id,job_id)
VALUES (?,?)
");

$stmt->bind_param("ii",$student,$job);
$stmt->execute();

header("Location: dashboard.php");
exit;