<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get admin details
$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT * FROM admins WHERE id = $admin_id")->fetch_assoc();

// Get activity log
$activities = $conn->query("
    SELECT * FROM admin_logs 
    WHERE admin_id = $admin_id 
    ORDER BY created_at DESC 
    LIMIT 10
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile | GLA University</title>
    <link rel="stylesheet" href="assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .profile-header {
            background: white;
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 150px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
        }
        
        .profile-info {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 30px;
            margin-top: 70px;
        }
        
        .profile-avatar-large {
            width: 150px;
            height: 150px;
            background: white;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 64px;
            color: #1e3c72;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 5px solid white;
        }
        
        .profile-details h2 {
            font-size: 32px;
            font-weight: 700;
            color: white;
            margin-bottom: 5px;
        }
        
        .profile-details p {
            color: rgba(255,255,255,0.9);
            font-size: 16px;
        }
        
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
        }
        
        .profile-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .card-title {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .card-title i {
            font-size: 24px;
            color: #1e3c72;
        }
        
        .card-title h3 {
            font-size: 18px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .info-row {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            width: 120px;
            font-size: 14px;
            color: #64748b;
        }
        
        .info-value {
            flex: 1;
            font-size: 14px;
            font-weight: 500;
            color: #1e3c72;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 35px;
            height: 35px;
            background: #e8f0fe;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
        }
        
        .activity-desc {
            flex: 1;
            font-size: 13px;
            color: #475569;
        }
        
        .activity-time {
            font-size: 11px;
            color: #94a3b8;
        }
        
        .badge-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .badge {
            padding: 6px 15px;
            background: #e8f0fe;
            color: #1e3c72;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 500;
        }
        
        @media (max-width: 992px) {
            .profile-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .profile-info {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar"><?php include '../includes/sidebar.php'; ?></div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>My Profile</h1>
                    <p>Manage your personal information and preferences</p>
                </div>
            </div>
            <div class="header-right">
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Profile Header -->
            <div class="profile-header">
                <div class="profile-info">
                    <div class="profile-avatar-large">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="profile-details">
                        <h2><?php echo htmlspecialchars($admin['name'] ?? ''); ?></h2>
                        <p>Administrator · GLA University</p>
                        <div style="margin-top: 10px;">
                            <span class="badge"><?php echo ucfirst($admin['role'] ?? 'Super Admin'); ?></span>
                            <span class="badge">Active since <?php echo date('M Y', strtotime($admin['created_at'] ?? 'now')); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Profile Grid -->
            <div class="profile-grid">
                <!-- Personal Information -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-user-circle"></i>
                        <h3>Personal Information</h3>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label">Full Name</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['name'] ?? '' ); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['email'] ?? '' ); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Username</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['username']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['phone'] ?? '+91 98765 43210'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Department</span>
                        <span class="info-value">Placement Cell</span>
                    </div>
                </div>

                <!-- Account Statistics -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-chart-line"></i>
                        <h3>Account Statistics</h3>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label">Member Since</span>
                        <span class="info-value"><?php echo date('d M Y', strtotime($admin['created_at'] ?? '2025-01-01')); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Last Login</span>
                        <span class="info-value"><?php echo $_SESSION['last_login'] ?? date('d M Y, h:i A'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Login Count</span>
                        <span class="info-value"><?php echo $admin['login_count'] ?? '127'; ?> times</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Actions Performed</span>
                        <span class="info-value"><?php echo $activities->num_rows ?? '0'; ?> recent</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Account Status</span>
                        <span class="info-value" style="color: #10b981;">Active</span>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-history"></i>
                        <h3>Recent Activity</h3>
                    </div>
                    
                    <?php if ($activities && $activities->num_rows > 0): ?>
                        <?php while($activity = $activities->fetch_assoc()): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-<?php echo $activity['icon'] ?? 'circle'; ?>"></i>
                            </div>
                            <div class="activity-desc">
                                <?php echo htmlspecialchars($activity['description']); ?>
                            </div>
                            <div class="activity-time">
                                <?php echo date('h:i A', strtotime($activity['created_at'])); ?>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-check"></i>
                            </div>
                            <div class="activity-desc">
                                Logged in to dashboard
                            </div>
                            <div class="activity-time">
                                Just now
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-eye"></i>
                            </div>
                            <div class="activity-desc">
                                Viewed student reports
                            </div>
                            <div class="activity-time">
                                2 hours ago
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-edit"></i>
                            </div>
                            <div class="activity-desc">
                                Updated placement drive
                            </div>
                            <div class="activity-time">
                                Yesterday
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <a href="activity-log.php" style="display: block; text-align: center; margin-top: 15px; color: #1e3c72; text-decoration: none; font-size: 13px;">
                        View All Activity <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- Security Settings -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-shield-alt"></i>
                        <h3>Security</h3>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label">2FA Status</span>
                        <span class="info-value">
                            <span style="color: #10b981;">Enabled</span>
                        </span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Last Password Change</span>
                        <span class="info-value">15 Mar 2025</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Trusted Devices</span>
                        <span class="info-value">3 devices</span>
                    </div>
                    
                    <div style="margin-top: 20px;">
                        <a href="settings.php" class="save-btn" style="display: inline-flex; background: #1e3c72; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 13px; gap: 8px;">
                            <i class="fas fa-lock"></i> Manage Security
                        </a>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-address-card"></i>
                        <h3>Contact Information</h3>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['email'] ?? '' ); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Alternative Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['alt_email'] ?? 'Not set'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone</span>
                        <span class="info-value"><?php echo htmlspecialchars($admin['phone'] ?? '+91 98765 43210'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Office</span>
                        <span class="info-value">Placement Cell, GLA University</span>
                    </div>
                    
                    <div style="margin-top: 20px;">
                        <a href="edit-profile.php" class="save-btn" style="display: inline-flex; background: #1e3c72; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 13px; gap: 8px;">
                            <i class="fas fa-edit"></i> Edit Profile
                        </a>
                    </div>
                </div>

                <!-- System Access -->
                <div class="profile-card">
                    <div class="card-title">
                        <i class="fas fa-globe"></i>
                        <h3>System Access</h3>
                    </div>
                    
                    <div class="badge-container">
                        <span class="badge">Dashboard</span>
                        <span class="badge">Students</span>
                        <span class="badge">Companies</span>
                        <span class="badge">Drives</span>
                        <span class="badge">Applications</span>
                        <span class="badge">Reports</span>
                        <span class="badge">Settings</span>
                    </div>
                    
                    <div style="margin-top: 20px; padding: 15px; background: #f8fafc; border-radius: 10px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="font-size: 13px; color: #475569;">API Access</span>
                            <span style="font-size: 13px; font-weight: 600; color: #1e3c72;">Enabled</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="font-size: 13px; color: #475569;">API Key</span>
                            <span style="font-size: 13px; font-family: monospace;">gla_adm_<?php echo substr(md5($admin_id), 0, 8); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>