<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

/* ================= ERROR HANDLER ================= */
set_exception_handler(function($e){
    error_log($e);
    http_response_code(500);
    die("Something went wrong. Please try again later.");
});

/* ================= SESSION ================= */
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

/* ================= ADMIN AUTH ================= */
if(!isset($_SESSION['admin_id'])){
    header("Location: ../login.php");
    exit;
}

/* ================= DB ================= */
require_once __DIR__ . '/../config/db.php';

/* ================= MAILER ================= */
require_once __DIR__ . '/../api/mail/mailer.php';

/* ================= HELPER ================= */
if(!function_exists('e')){
    function e($v){
        return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
    }
}