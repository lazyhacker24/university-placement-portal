<?php

ini_set('display_errors',1);
error_reporting(E_ALL);


require_once '../config/db.php';
require_once '../config/session.php';

$username = trim($_POST['username']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM admins WHERE username=?");
$stmt->bind_param("s",$username);
$stmt->execute();

$result=$stmt->get_result();

if($result->num_rows==1){

    $admin=$result->fetch_assoc();

    if(password_verify($password,$admin['password'])){

        session_regenerate_id(true);

        $_SESSION['admin_id']=$admin['id'];
        $_SESSION['role']='admin';

        header("Location: dashboard.php");
        exit;
    }
}

header("Location: login.php");
exit;