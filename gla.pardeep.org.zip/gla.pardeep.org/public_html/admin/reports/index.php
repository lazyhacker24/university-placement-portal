<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get overall statistics
$total_students = $conn->query("SELECT COUNT(*) as c FROM students")->fetch_assoc()['c'] ?? 0;
$placed_students = $conn->query("SELECT COUNT(*) as c FROM students WHERE placement_status='Placed'")->fetch_assoc()['c'] ?? 0;
$total_companies = $conn->query("SELECT COUNT(*) as c FROM companies")->fetch_assoc()['c'] ?? 0;
$total_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives")->fetch_assoc()['c'] ?? 0;
$total_applications = $conn->query("SELECT COUNT(*) as c FROM applications")->fetch_assoc()['c'] ?? 0;

// Get branch-wise placement data
$branch_data = $conn->query("
    SELECT branch, 
           COUNT(*) as total,
           SUM(CASE WHEN placement_status='Placed' THEN 1 ELSE 0 END) as placed
    FROM students 
    WHERE branch IS NOT NULL
    GROUP BY branch
");

// Get monthly placement trends (last 6 months)
$monthly_trends = $conn->query("
    SELECT DATE_FORMAT(applied_date, '%Y-%m') as month,
           COUNT(*) as applications,
           SUM(CASE WHEN status='selected' THEN 1 ELSE 0 END) as placements
    FROM applications
    WHERE applied_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(applied_date, '%Y-%m')
    ORDER BY month DESC
");

// Get top companies by placements
$top_companies = $conn->query("
    SELECT c.company_name,
           COUNT(DISTINCT pd.id) as drives,
           COUNT(DISTINCT a.id) as applications,
           COUNT(DISTINCT CASE WHEN a.status='selected' THEN a.student_id END) as placements
    FROM companies c
    LEFT JOIN placement_drives pd ON c.company_id = pd.company_id
    LEFT JOIN applications a ON pd.id = a.drive_id
    GROUP BY c.company_id
    HAVING placements > 0
    ORDER BY placements DESC
    LIMIT 10
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports & Analytics | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .reports-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .export-buttons {
            display: flex;
            gap: 10px;
        }
        
        .export-btn {
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .pdf-btn {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        .excel-btn {
            background: #d1fae5;
            color: #065f46;
        }
        
        .print-btn {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .report-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .report-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .report-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }
        
        .report-icon.blue { background: #e8f0fe; color: #1e3c72; }
        .report-icon.green { background: #d1fae5; color: #065f46; }
        .report-icon.orange { background: #fef3c7; color: #92400e; }
        .report-icon.purple { background: #f3e8ff; color: #6b21a8; }
        
        .report-content {
            flex: 1;
        }
        
        .report-label {
            font-size: 13px;
            color: #64748b;
            display: block;
            margin-bottom: 5px;
        }
        
        .report-number {
            font-size: 32px;
            font-weight: 700;
            color: #1e3c72;
        }
        
        .charts-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .chart-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .chart-wrapper {
            height: 300px;
            position: relative;
        }
        
        .insights-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .insights-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .insights-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .insights-header i {
            font-size: 24px;
            color: #1e3c72;
        }
        
        .insights-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .stat-list {
            list-style: none;
        }
        
        .stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .stat-item:last-child {
            border-bottom: none;
        }
        
        .stat-name {
            color: #475569;
        }
        
        .stat-value {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .progress {
            width: 100px;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #1e3c72, #2a5298);
            border-radius: 3px;
        }
        
        .placement-rate {
            font-size: 24px;
            font-weight: 700;
            color: #10b981;
        }
        
        .summary-box {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-top: 30px;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            text-align: center;
        }
        
        .summary-item .value {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .summary-item .label {
            font-size: 14px;
            opacity: 0.8;
        }
        
        @media (max-width: 992px) {
            .report-grid,
            .charts-row,
            .insights-section {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar (same structure as before) -->
    <div class="sidebar"><?php include '../includes/sidebar.php'; ?></div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Reports & Analytics</h1>
                    <p>Comprehensive placement statistics and insights</p>
                </div>
            </div>
            <div class="header-right">
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Export Buttons -->
            <div class="reports-header">
                <h2>Placement Overview</h2>
                <div class="export-buttons">
                    <a href="export_pdf.php" class="export-btn pdf-btn">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </a>
                    <a href="export_excel.php" class="export-btn excel-btn">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </a>
                    <a href="#" onclick="window.print()" class="export-btn print-btn">
                        <i class="fas fa-print"></i> Print
                    </a>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="report-grid">
                <div class="report-card">
                    <div class="report-icon blue">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="report-content">
                        <span class="report-label">Total Students</span>
                        <span class="report-number"><?php echo $total_students; ?></span>
                    </div>
                </div>
                
                <div class="report-card">
                    <div class="report-icon green">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="report-content">
                        <span class="report-label">Placed Students</span>
                        <span class="report-number"><?php echo $placed_students; ?></span>
                    </div>
                </div>
                
                <div class="report-card">
                    <div class="report-icon orange">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="report-content">
                        <span class="report-label">Companies</span>
                        <span class="report-number"><?php echo $total_companies; ?></span>
                    </div>
                </div>
                
                <div class="report-card">
                    <div class="report-icon purple">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="report-content">
                        <span class="report-label">Applications</span>
                        <span class="report-number"><?php echo $total_applications; ?></span>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="charts-row">
                <!-- Branch-wise Placement Chart -->
                <div class="chart-container">
                    <div class="chart-header">
                        <h3>Branch-wise Placement</h3>
                        <i class="fas fa-ellipsis-v" style="color: #94a3b8;"></i>
                    </div>
                    <div class="chart-wrapper">
                        <canvas id="branchChart"></canvas>
                    </div>
                </div>

                <!-- Monthly Trends Chart -->
                <div class="chart-container">
                    <div class="chart-header">
                        <h3>Monthly Trends (Last 6 Months)</h3>
                        <i class="fas fa-ellipsis-v" style="color: #94a3b8;"></i>
                    </div>
                    <div class="chart-wrapper">
                        <canvas id="trendsChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Insights Section -->
            <div class="insights-section">
                <!-- Top Companies -->
                <div class="insights-card">
                    <div class="insights-header">
                        <i class="fas fa-trophy"></i>
                        <h3>Top Recruiting Companies</h3>
                    </div>
                    <ul class="stat-list">
                        <?php if ($top_companies && $top_companies->num_rows > 0): ?>
                            <?php while($company = $top_companies->fetch_assoc()): ?>
                            <li class="stat-item">
                                <span class="stat-name"><?php echo htmlspecialchars($company['company_name']); ?></span>
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <span class="stat-value"><?php echo $company['placements']; ?> placed</span>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: <?php echo min(100, ($company['placements'] * 10)); ?>%"></div>
                                    </div>
                                </div>
                            </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="stat-item">No placement data available</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Placement Summary -->
                <div class="insights-card">
                    <div class="insights-header">
                        <i class="fas fa-chart-pie"></i>
                        <h3>Placement Summary</h3>
                    </div>
                    <div style="text-align: center; padding: 20px;">
                        <div class="placement-rate">
                            <?php 
                            $placement_rate = $total_students > 0 ? round(($placed_students / $total_students) * 100, 1) : 0;
                            echo $placement_rate . '%';
                            ?>
                        </div>
                        <p style="color: #64748b; margin-bottom: 20px;">Overall Placement Rate</p>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                            <div>
                                <div style="font-size: 24px; font-weight: 700; color: #1e3c72;"><?php echo $total_drives; ?></div>
                                <div style="font-size: 13px; color: #64748b;">Total Drives</div>
                            </div>
                            <div>
                                <div style="font-size: 24px; font-weight: 700; color: #1e3c72;"><?php echo $total_applications; ?></div>
                                <div style="font-size: 13px; color: #64748b;">Applications</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Executive Summary -->
            <div class="summary-box">
                <div class="summary-grid">
                    <div class="summary-item">
                        <div class="value"><?php echo $total_students - $placed_students; ?></div>
                        <div class="label">Students Available</div>
                    </div>
                    <div class="summary-item">
                        <div class="value"><?php echo $total_companies; ?></div>
                        <div class="label">Active Partners</div>
                    </div>
                    <div class="summary-item">
                        <div class="value"><?php echo $total_drives; ?></div>
                        <div class="label">Placement Drives</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Branch-wise Chart
        const branchCtx = document.getElementById('branchChart').getContext('2d');
        <?php
        $branches = [];
        $totals = [];
        $placed = [];
        if ($branch_data && $branch_data->num_rows > 0) {
            while($row = $branch_data->fetch_assoc()) {
                $branches[] = $row['branch'];
                $totals[] = $row['total'];
                $placed[] = $row['placed'];
            }
        }
        ?>
        
        new Chart(branchCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($branches); ?>,
                datasets: [{
                    label: 'Total Students',
                    data: <?php echo json_encode($totals); ?>,
                    backgroundColor: 'rgba(30, 60, 114, 0.5)',
                    borderColor: '#1e3c72',
                    borderWidth: 1
                }, {
                    label: 'Placed Students',
                    data: <?php echo json_encode($placed); ?>,
                    backgroundColor: 'rgba(16, 185, 129, 0.5)',
                    borderColor: '#10b981',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Monthly Trends Chart
        const trendsCtx = document.getElementById('trendsChart').getContext('2d');
        <?php
        $months = [];
        $applications = [];
        $placements = [];
        if ($monthly_trends && $monthly_trends->num_rows > 0) {
            while($row = $monthly_trends->fetch_assoc()) {
                $months[] = date('M Y', strtotime($row['month'] . '-01'));
                $applications[] = $row['applications'];
                $placements[] = $row['placements'];
            }
        }
        ?>
        
        new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_reverse($months)); ?>,
                datasets: [{
                    label: 'Applications',
                    data: <?php echo json_encode(array_reverse($applications)); ?>,
                    borderColor: '#1e3c72',
                    backgroundColor: 'rgba(30, 60, 114, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Placements',
                    data: <?php echo json_encode(array_reverse($placements)); ?>,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
</body>
</html>