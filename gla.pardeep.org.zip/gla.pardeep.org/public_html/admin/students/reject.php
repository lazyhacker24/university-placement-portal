<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

$id=(int)$_GET['id'];

$conn->query("UPDATE students SET status='rejected' WHERE id=$id");

header("Location:list.php");