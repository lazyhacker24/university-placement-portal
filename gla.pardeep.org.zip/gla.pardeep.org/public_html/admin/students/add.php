<?php
require_once '../../config/session.php';
require_once '../../config/db.php';

// Check if user is logged in as placement officer
if(!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Get student ID from URL
$student_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($student_id <= 0) {
    header("Location: index.php?error=invalid");
    exit;
}

// Fetch student details with course information
$query = "
    SELECT s.*, 
           c.name as course_name,
           c.duration as course_duration,
           u.name as added_by_name
    FROM students s
    LEFT JOIN courses c ON s.course = c.name
    LEFT JOIN users u ON s.created_by = u.id
    WHERE s.id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows === 0) {
    header("Location: index.php?error=notfound");
    exit;
}

$student = $result->fetch_assoc();

// Fetch placement history if any
$placement_query = "
    SELECT p.*, cmp.name as company_name, cmp.logo as company_logo
    FROM placements p
    JOIN companies cmp ON p.company_id = cmp.id
    WHERE p.student_id = ?
    ORDER BY p.placement_date DESC
";

$placement_stmt = $conn->prepare($placement_query);
$placement_stmt->bind_param("i", $student_id);
$placement_stmt->execute();
$placements = $placement_stmt->get_result();
$has_placement = $placements->num_rows > 0;

// Fetch academic records if you have them
$academic_query = "
    SELECT * FROM academic_records 
    WHERE student_id = ? 
    ORDER BY semester ASC
";
$academic_stmt = $conn->prepare($academic_query);
$academic_stmt->bind_param("i", $student_id);
$academic_stmt->execute();
$academic_records = $academic_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details · Placement Officer</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #0b1120 0%, #19223c 100%);
            min-height: 100vh;
            color: white;
        }

        /* Navigation Bar (same as add student) */
        .navbar {
            background: rgba(18, 25, 45, 0.8);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-logo i {
            font-size: 1.8rem;
            color: #10b981;
        }

        .nav-logo span {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 600;
            font-size: 1.3rem;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-link {
            color: #b7c7e9;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 30px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
        }

        .nav-link i {
            font-size: 1rem;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            color: #b7c7e9;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: #10b981;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* Header with Actions */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .back-btn {
            width: 48px;
            height: 48px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background: #10b981;
            transform: translateX(-5px);
        }

        .header-title h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 2.2rem;
            color: white;
        }

        .header-title .enrollment {
            color: #10b981;
            font-size: 1rem;
            background: rgba(16, 185, 129, 0.15);
            padding: 4px 12px;
            border-radius: 30px;
            display: inline-block;
            margin-top: 8px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 14px 24px;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-edit {
            background: rgba(255, 255, 255, 0.05);
            border: 1.5px solid rgba(255, 255, 255, 0.1);
            color: white;
        }

        .btn-edit:hover {
            background: #3b82f6;
            border-color: #3b82f6;
            transform: translateY(-2px);
        }

        .btn-placement {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            box-shadow: 0 12px 30px -8px rgba(16, 185, 129, 0.4);
        }

        .btn-placement:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 35px -6px #10b98180;
        }

        /* Student Profile Card */
        .profile-card {
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 48px;
            padding: 40px;
            margin-bottom: 30px;
        }

        .profile-header {
            display: flex;
            gap: 30px;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #10b981, #3b82f6);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: 600;
            color: white;
            box-shadow: 0 20px 40px -10px rgba(16, 185, 129, 0.3);
        }

        .profile-info {
            flex: 1;
        }

        .profile-info h2 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .profile-meta {
            display: flex;
            gap: 20px;
            color: #b7c7e9;
            flex-wrap: wrap;
        }

        .profile-meta span {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .status-badge {
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .status-active {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .status-placed {
            background: rgba(59, 130, 246, 0.2);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        .status-inactive {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        /* Details Grid */
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .detail-item {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.03);
            border-radius: 24px;
            padding: 20px;
        }

        .detail-label {
            color: #5d6f94;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .detail-value {
            font-size: 1.2rem;
            font-weight: 600;
            word-break: break-word;
        }

        .detail-value.small {
            font-size: 1rem;
            color: #b7c7e9;
        }

        .resume-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #10b981;
            text-decoration: none;
            padding: 8px 16px;
            background: rgba(16, 185, 129, 0.1);
            border-radius: 30px;
            transition: all 0.3s;
        }

        .resume-link:hover {
            background: #10b981;
            color: white;
        }

        /* Section Cards */
        .section-card {
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 48px;
            padding: 30px;
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
        }

        .section-title i {
            color: #10b981;
        }

        /* Placement History */
        .placement-timeline {
            position: relative;
        }

        .timeline-item {
            display: flex;
            gap: 20px;
            padding: 20px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .timeline-item:last-child {
            border-bottom: none;
        }

        .timeline-icon {
            width: 50px;
            height: 50px;
            background: rgba(16, 185, 129, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #10b981;
            font-size: 1.5rem;
        }

        .timeline-content {
            flex: 1;
        }

        .timeline-content h4 {
            font-size: 1.2rem;
            margin-bottom: 5px;
        }

        .timeline-meta {
            display: flex;
            gap: 15px;
            color: #b7c7e9;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .package-badge {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            padding: 4px 12px;
            border-radius: 30px;
            font-weight: 600;
        }

        /* Academic Records */
        .academic-table {
            width: 100%;
            border-collapse: collapse;
        }

        .academic-table th {
            text-align: left;
            padding: 15px;
            color: #5d6f94;
            font-weight: 500;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .academic-table td {
            padding: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .academic-table tr:last-child td {
            border-bottom: none;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #5d6f94;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-meta {
                justify-content: center;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-briefcase"></i>
                <span>Placement Cell</span>
            </div>
            <div class="nav-links">
                <a href="../dashboard.php" class="nav-link">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
                <a href="index.php" class="nav-link active">
                    <i class="fas fa-users"></i> Students
                </a>
                <a href="../companies/index.php" class="nav-link">
                    <i class="fas fa-building"></i> Companies
                </a>
                <a href="../placements/index.php" class="nav-link">
                    <i class="fas fa-handshake"></i> Placements
                </a>
            </div>
            <div class="user-menu">
                <i class="fas fa-bell"></i>
                <div class="user-avatar">
                    PO
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-left">
                <a href="index.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="header-title">
                    <h1>Student Profile</h1>
                    <span class="enrollment">
                        <i class="fas fa-qrcode"></i> <?= htmlspecialchars($student['enrollment_no']) ?>
                    </span>
                </div>
            </div>
            <div class="action-buttons">
                <a href="edit.php?id=<?= $student['id'] ?>" class="btn btn-edit">
                    <i class="fas fa-edit"></i> Edit Details
                </a>
                <a href="../placements/add.php?student_id=<?= $student['id'] ?>" class="btn btn-placement">
                    <i class="fas fa-handshake"></i> Add Placement
                </a>
            </div>
        </div>

        <!-- Profile Card -->
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">
                    <?= strtoupper(substr($student['name'], 0, 2)) ?>
                </div>
                <div class="profile-info">
                    <h2><?= htmlspecialchars($student['name']) ?></h2>
                    <div class="profile-meta">
                        <span><i class="fas fa-envelope"></i> <?= htmlspecialchars($student['email']) ?></span>
                        <span><i class="fas fa-phone"></i> <?= htmlspecialchars($student['phone']) ?></span>
                        <span>
                            <span class="status-badge status-<?= $student['status'] ?? 'active' ?>">
                                <i class="fas fa-circle"></i> <?= ucfirst($student['status'] ?? 'Active') ?>
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Details Grid -->
            <div class="details-grid">
                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-graduation-cap"></i> Course</div>
                    <div class="detail-value"><?= htmlspecialchars($student['course'] ?? 'Not specified') ?></div>
                    <?php if(isset($student['course_duration'])): ?>
                        <div class="detail-value small">Duration: <?= $student['course_duration'] ?> years</div>
                    <?php endif; ?>
                </div>

                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-calendar"></i> Batch</div>
                    <div class="detail-value"><?= htmlspecialchars($student['batch'] ?? 'Not specified') ?></div>
                </div>

                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-layer-group"></i> Current Semester</div>
                    <div class="detail-value"><?= htmlspecialchars($student['semester'] ?? 'N/A') ?></div>
                </div>

                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-star"></i> CGPA</div>
                    <div class="detail-value"><?= number_format($student['cgpa'] ?? 0, 2) ?></div>
                </div>

                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-exclamation-triangle"></i> Backlogs</div>
                    <div class="detail-value"><?= $student['backlogs'] ?? '0' ?></div>
                </div>

                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-user-clock"></i> Added On</div>
                    <div class="detail-value"><?= date('d M Y', strtotime($student['created_at'])) ?></div>
                    <div class="detail-value small">by <?= htmlspecialchars($student['added_by_name'] ?? 'System') ?></div>
                </div>

                <?php if(!empty($student['resume_link'])): ?>
                <div class="detail-item" style="grid-column: span 2;">
                    <div class="detail-label"><i class="fas fa-file-pdf"></i> Resume</div>
                    <a href="<?= htmlspecialchars($student['resume_link']) ?>" target="_blank" class="resume-link">
                        <i class="fas fa-external-link-alt"></i> View Resume
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Placement History Section -->
        <div class="section-card">
            <div class="section-title">
                <i class="fas fa-briefcase"></i> Placement History
            </div>
            
            <?php if($has_placement): ?>
                <div class="placement-timeline">
                    <?php while($placement = $placements->fetch_assoc()): ?>
                        <div class="timeline-item">
                            <div class="timeline-icon">
                                <i class="fas fa-building"></i>
                            </div>
                            <div class="timeline-content">
                                <h4><?= htmlspecialchars($placement['company_name']) ?></h4>
                                <div class="timeline-meta">
                                    <span><i class="fas fa-calendar"></i> <?= date('d M Y', strtotime($placement['placement_date'])) ?></span>
                                    <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($placement['location'] ?? 'Not specified') ?></span>
                                </div>
                                <div>
                                    <span class="package-badge">
                                        <i class="fas fa-tag"></i> ₹<?= number_format($placement['package'] ?? 0) ?> LPA
                                    </span>
                                </div>
                                <?php if(!empty($placement['remarks'])): ?>
                                    <p style="color: #b7c7e9; margin-top: 10px;">
                                        <?= htmlspecialchars($placement['remarks']) ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-briefcase-slash"></i>
                    <h3>No Placement History</h3>
                    <p>This student hasn't been placed yet</p>
                    <a href="../placements/add.php?student_id=<?= $student['id'] ?>" class="btn btn-placement" style="margin-top: 20px; display: inline-flex;">
                        <i class="fas fa-plus"></i> Add Placement
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Academic Records Section -->
        <div class="section-card">
            <div class="section-title">
                <i class="fas fa-chart-line"></i> Academic Records
            </div>
            
            <?php if($academic_records->num_rows > 0): ?>
                <table class="academic-table">
                    <thead>
                        <tr>
                            <th>Semester</th>
                            <th>SGPA</th>
                            <th>CGPA</th>
                            <th>Backlogs</th>
                            <th>Year</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($record = $academic_records->fetch_assoc()): ?>
                            <tr>
                                <td><strong>Semester <?= $record['semester'] ?></strong></td>
                                <td><?= number_format($record['sgpa'] ?? 0, 2) ?></td>
                                <td><?= number_format($record['cgpa'] ?? 0, 2) ?></td>
                                <td><?= $record['backlogs'] ?? 0 ?></td>
                                <td><?= $record['academic_year'] ?? 'N/A' ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-chart-bar"></i>
                    <h3>No Academic Records</h3>
                    <p>Academic history not available for this student</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>