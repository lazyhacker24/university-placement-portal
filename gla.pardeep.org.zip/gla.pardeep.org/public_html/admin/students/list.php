<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

$res=$conn->query("SELECT * FROM students ORDER BY id DESC");
?>

<h2>Students</h2>

<table>

<tr>
<th>Name</th>
<th>Roll</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($s=$res->fetch_assoc()): ?>

<tr>
<td><?= $s['full_name'] ?></td>
<td><?= $s['roll_no'] ?></td>
<td><?= $s['status'] ?></td>

<td>

<?php if($s['status']=="pending"): ?>

<a href="action.php?id=<?=$s['id']?>&do=approve">Approve</a>
<a href="action.php?id=<?=$s['id']?>&do=reject">Reject</a>

<?php else: ?>
Completed
<?php endif; ?>

</td>
</tr>

<?php endwhile; ?>

</table>