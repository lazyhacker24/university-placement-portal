<?php
require_once '../includes/auth.php';
require_once '../../config/db.php';
require_once '../../config/mail.php';

$id=(int)$_GET['id'];
$action=$_GET['do'];

$status = ($action=="approve") ? "approved":"rejected";

$stmt=$conn->prepare("UPDATE students SET status=? WHERE id=?");
$stmt->bind_param("si",$status,$id);
$stmt->execute();

/* send email */
$res=$conn->query("SELECT email,full_name FROM students WHERE id=$id");
$u=$res->fetch_assoc();

if($status=="approved"){
$msg="Your account approved.";
}else{
$msg="Your account rejected.";
}

sendMail($u['email'],$u['full_name'],"Account Status",$msg);

header("Location: list.php");
exit;