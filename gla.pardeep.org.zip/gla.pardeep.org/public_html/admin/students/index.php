<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get statistics
$total_students = $conn->query("SELECT COUNT(*) as c FROM students")->fetch_assoc()['c'] ?? 0;
$placed_students = $conn->query("SELECT COUNT(*) as c FROM students WHERE placement_status='Placed'")->fetch_assoc()['c'] ?? 0;
$pending_students = $conn->query("SELECT COUNT(*) as c FROM students WHERE placement_status='Pending'")->fetch_assoc()['c'] ?? 0;

// Get students list
$students = $conn->query("
    SELECT s.*, 
           (SELECT COUNT(*) FROM applications WHERE student_id = s.id) as applications
    FROM students s 
    ORDER BY s.created_at DESC
");

// Get branches for filter
$branches = $conn->query("SELECT DISTINCT branch FROM students WHERE branch IS NOT NULL");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Students Management | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Additional styles for students page */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .add-btn {
            background: #1e3c72;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .add-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .filter-select {
            padding: 10px 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #475569;
            background: white;
            cursor: pointer;
        }
        
        .filter-select:focus {
            outline: none;
            border-color: #1e3c72;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge.placed {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-badge.pending {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .status-badge.applied {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            transition: all 0.3s;
        }
        
        .edit-btn {
            background: #fef3c7;
            color: #92400e;
        }
        
        .edit-btn:hover {
            background: #fde68a;
        }
        
        .view-btn {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .view-btn:hover {
            background: #bae6fd;
        }
        
        .delete-btn {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        .delete-btn:hover {
            background: #fecaca;
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .student-name {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .student-email {
            font-size: 12px;
            color: #64748b;
        }
        
        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 25px;
        }
        
        .page-link {
            padding: 8px 14px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            transition: all 0.3s;
        }
        
        .page-link.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        }
        
        .page-link:hover {
            background: #f1f5f9;
        }
    </style>
</head>
<body>
    <!-- Sidebar (same as dashboard) -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
            <div class="version-badge">v2.0</div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="../dashboard.php">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="index.php" class="active">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students; ?></div>
            </a>
            <a href="../companies/">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies ?? 0; ?></div>
            </a>
            <a href="../drives/">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $active_drives ?? 0; ?></div>
            </a>
            <a href="../applications/">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications ?? 0; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="../reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="../settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="../help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="../profile.php">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="../logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Students Management</h1>
                    <p>Manage student profiles, applications, and placement status</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search students..." id="searchInput">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Students</span>
                        <h3 class="stat-number"><?php echo $total_students; ?></h3>
                    </div>
                </div>

                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Placed Students</span>
                        <h3 class="stat-number"><?php echo $placed_students; ?></h3>
                    </div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Pending</span>
                        <h3 class="stat-number"><?php echo $pending_students; ?></h3>
                    </div>
                </div>

                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Applications</span>
                        <h3 class="stat-number"><?php echo $total_applications ?? 0; ?></h3>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="filter-section">
                    <select class="filter-select" id="branchFilter">
                        <option value="">All Branches</option>
                        <?php while($branch = $branches->fetch_assoc()): ?>
                            <option value="<?php echo $branch['branch']; ?>"><?php echo $branch['branch']; ?></option>
                        <?php endwhile; ?>
                    </select>
                    <select class="filter-select" id="statusFilter">
                        <option value="">All Status</option>
                        <option value="Placed">Placed</option>
                        <option value="Pending">Pending</option>
                        <option value="Applied">Applied</option>
                    </select>
                </div>
                <a href="add.php" class="add-btn">
                    <i class="fas fa-plus"></i> Add New Student
                </a>
            </div>

            <!-- Students Table -->
            <div class="table-card">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Enrollment No.</th>
                                <th>Branch</th>
                                <th>Semester</th>
                                <th>Status</th>
                                <th>Applications</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($students && $students->num_rows > 0): ?>
                                <?php while($student = $students->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-avatar">
                                                <?php echo strtoupper(substr($student['full_name'] ?? 'S', 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="student-name"><?php echo htmlspecialchars($student['full_name'] ?? 'N/A'); ?></div>
                                                <div class="student-email"><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($student['enrollment_no'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($student['branch'] ?? 'N/A'); ?></td>
                                    <td><?php echo $student['semester'] ?? 'N/A'; ?></td>
                                    <td>
                                        <?php
                                        $status = $student['placement_status'] ?? 'Pending';
                                        $statusClass = '';
                                        if($status == 'Placed') $statusClass = 'placed';
                                        elseif($status == 'Pending') $statusClass = 'pending';
                                        else $statusClass = 'applied';
                                        ?>
                                        <span class="status-badge <?php echo $statusClass; ?>">
                                            <?php echo $status; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $student['applications'] ?? 0; ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view.php?id=<?php echo $student['id']; ?>" class="action-btn view-btn">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?php echo $student['id']; ?>" class="action-btn edit-btn">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="delete.php?id=<?php echo $student['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="no-data">No students found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="pagination">
                    <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                    <a href="#" class="page-link active">1</a>
                    <a href="#" class="page-link">2</a>
                    <a href="#" class="page-link">3</a>
                    <a href="#" class="page-link">4</a>
                    <a href="#" class="page-link">5</a>
                    <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Filter functionality
        document.getElementById('branchFilter').addEventListener('change', filterTable);
        document.getElementById('statusFilter').addEventListener('change', filterTable);

        function filterTable() {
            let branchFilter = document.getElementById('branchFilter').value;
            let statusFilter = document.getElementById('statusFilter').value;
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let branch = row.cells[2]?.textContent || '';
                let status = row.cells[4]?.textContent || '';
                let show = true;
                
                if (branchFilter && !branch.includes(branchFilter)) show = false;
                if (statusFilter && !status.includes(statusFilter)) show = false;
                
                row.style.display = show ? '' : 'none';
            });
        }
    </script>
</body>
</html>