<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../../config/session.php';
require_once '../../config/db.php';

if(!isset($_SESSION['admin_id'])){
header("Location: ../login.php");
exit;
}

/* GET MAIL LOGS */

$result = $conn->query("
SELECT * FROM mail_logs
ORDER BY sent_at DESC
");
?>

<!DOCTYPE html>
<html>
<head>

<title>Mail Logs | GLA Admin</title>

<link rel="stylesheet" href="../assets/css/admin-dashboard.css">

<style>

body{
font-family:Arial;
background:#f5f7fb;
padding:30px;
}

.table{
background:white;
border-radius:10px;
padding:20px;
box-shadow:0 5px 20px rgba(0,0,0,0.05);
}

table{
width:100%;
border-collapse:collapse;
}

th{
background:#1e3c72;
color:white;
padding:12px;
font-size:14px;
}

td{
padding:12px;
border-bottom:1px solid #eee;
font-size:13px;
}

.status-sent{
color:#10b981;
font-weight:bold;
}

.status-failed{
color:#ef4444;
font-weight:bold;
}

h1{
margin-bottom:20px;
color:#1e3c72;
}

</style>

</head>

<body>

<h1>Mail Logs</h1>

<div class="table">

<table>

<tr>
<th>ID</th>
<th>Email</th>
<th>Subject</th>
<th>Type</th>
<th>Status</th>
<th>Error</th>
<th>Date</th>
</tr>

<?php
if($result && $result->num_rows > 0){

while($row = $result->fetch_assoc()){
?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo htmlspecialchars($row['recipient_email']); ?></td>

<td><?php echo htmlspecialchars($row['subject']); ?></td>

<td><?php echo htmlspecialchars($row['mail_type']); ?></td>

<td class="status-<?php echo $row['status']; ?>">
<?php echo $row['status']; ?>
</td>

<td><?php echo htmlspecialchars($row['error']); ?></td>

<td><?php echo $row['sent_at']; ?></td>

</tr>

<?php
}

}else{

echo "<tr><td colspan='7'>No mail logs found</td></tr>";

}
?>

</table>

</div>

</body>
</html>