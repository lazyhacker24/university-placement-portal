<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get statistics
$total_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives")->fetch_assoc()['c'] ?? 0;
$active_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives WHERE drive_status='active'")->fetch_assoc()['c'] ?? 0;
$upcoming_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives WHERE deadline >= CURDATE()")->fetch_assoc()['c'] ?? 0;
$completed_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives WHERE drive_status='completed'")->fetch_assoc()['c'] ?? 0;

// Get drives list
$drives = $conn->query("
    SELECT pd.*, 
           c.company_name, 
           c.location as company_location,
           c.industry,
           COUNT(DISTINCT a.id) as applications,
           COUNT(DISTINCT CASE WHEN a.status = 'selected' THEN a.id END) as selected
    FROM placement_drives pd
    JOIN companies c ON pd.company_id = c.company_id
    LEFT JOIN applications a ON pd.id = a.drive_id
    GROUP BY pd.id
    ORDER BY 
        CASE WHEN pd.drive_status = 'active' THEN 1 ELSE 2 END,
        pd.deadline ASC
");

// Get companies for filter
$companies = $conn->query("SELECT company_id, company_name FROM companies ORDER BY company_name");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Placement Drives | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .add-btn {
            background: #1e3c72;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .add-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .filter-select {
            padding: 10px 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #475569;
            background: white;
            cursor: pointer;
            min-width: 150px;
        }
        
        .drive-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
            border-left: 4px solid transparent;
            transition: all 0.3s;
        }
        
        .drive-card:hover {
            transform: translateX(5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        }
        
        .drive-card.active {
            border-left-color: #10b981;
        }
        
        .drive-card.upcoming {
            border-left-color: #f59e0b;
        }
        
        .drive-card.completed {
            border-left-color: #64748b;
        }
        
        .drive-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .drive-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .company-logo {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }
        
        .drive-info h3 {
            font-size: 18px;
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 4px;
        }
        
        .drive-info .company-name {
            font-size: 14px;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .drive-status {
            padding: 6px 15px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .drive-status.active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .drive-status.upcoming {
            background: #fef3c7;
            color: #92400e;
        }
        
        .drive-status.completed {
            background: #e2e8f0;
            color: #475569;
        }
        
        .drive-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
            padding: 15px;
            background: #f8fafc;
            border-radius: 12px;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .detail-icon {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
            font-size: 18px;
        }
        
        .detail-text {
            display: flex;
            flex-direction: column;
        }
        
        .detail-label {
            font-size: 11px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .detail-value {
            font-size: 16px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .drive-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 15px;
        }
        
        .stats-mini {
            display: flex;
            gap: 20px;
        }
        
        .stat-mini-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        
        .stat-mini-item i {
            color: #1e3c72;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .action-btn {
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .view-btn {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .edit-btn {
            background: #fef3c7;
            color: #92400e;
        }
        
        .delete-btn {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        .applications-btn {
            background: #e8f0fe;
            color: #1e3c72;
        }
        
        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 30px;
        }
        
        .page-link {
            padding: 8px 14px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            transition: all 0.3s;
        }
        
        .page-link.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        }
        
        .no-data {
            text-align: center;
            padding: 50px;
            background: white;
            border-radius: 15px;
            color: #94a3b8;
        }
        
        @media (max-width: 768px) {
            .drive-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .drive-footer {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .stats-mini {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
            <div class="version-badge">v2.0</div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="../dashboard.php">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="../students/">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students ?? 0; ?></div>
            </a>
            <a href="../companies/">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies ?? 0; ?></div>
            </a>
            <a href="index.php" class="active">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $active_drives; ?></div>
            </a>
            <a href="../applications/">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications ?? 0; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="../reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="../settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="../help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="../profile.php">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="../logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Placement Drives</h1>
                    <p>Manage and track all placement drives</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search drives..." id="searchInput">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Drives</span>
                        <h3 class="stat-number"><?php echo $total_drives; ?></h3>
                    </div>
                </div>

                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-play-circle"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Active Drives</span>
                        <h3 class="stat-number"><?php echo $active_drives; ?></h3>
                    </div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Upcoming</span>
                        <h3 class="stat-number"><?php echo $upcoming_drives; ?></h3>
                    </div>
                </div>

                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Completed</span>
                        <h3 class="stat-number"><?php echo $completed_drives; ?></h3>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="filter-section">
                    <select class="filter-select" id="companyFilter">
                        <option value="">All Companies</option>
                        <?php while($company = $companies->fetch_assoc()): ?>
                            <option value="<?php echo $company['company_name']; ?>">
                                <?php echo htmlspecialchars($company['company_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <select class="filter-select" id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="upcoming">Upcoming</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <a href="add.php" class="add-btn">
                    <i class="fas fa-plus"></i> Create New Drive
                </a>
            </div>

            <!-- Drives List -->
            <div class="drives-list" id="drivesList">
                <?php if ($drives && $drives->num_rows > 0): ?>
                    <?php while($drive = $drives->fetch_assoc()): 
                        $isActive = $drive['drive_status'] == 'active';
                        $isUpcoming = strtotime($drive['deadline']) > time() && $drive['drive_status'] == 'upcoming';
                        $isCompleted = $drive['drive_status'] == 'completed';
                        $cardClass = $isActive ? 'active' : ($isUpcoming ? 'upcoming' : ($isCompleted ? 'completed' : ''));
                    ?>
                    <div class="drive-card <?php echo $cardClass; ?>" data-company="<?php echo $drive['company_name']; ?>" data-status="<?php echo $drive['drive_status']; ?>">
                        <div class="drive-header">
                            <div class="drive-title">
                                <div class="company-logo">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div class="drive-info">
                                    <h3><?php echo htmlspecialchars($drive['title']); ?></h3>
                                    <div class="company-name">
                                        <i class="fas fa-building"></i>
                                        <?php echo htmlspecialchars($drive['company_name']); ?>
                                        <i class="fas fa-map-marker-alt" style="margin-left: 10px;"></i>
                                        <?php echo htmlspecialchars($drive['company_location'] ?? 'N/A'); ?>
                                    </div>
                                </div>
                            </div>
                            <span class="drive-status <?php echo $drive['drive_status']; ?>">
                                <?php echo ucfirst($drive['drive_status']); ?>
                            </span>
                        </div>

                        <div class="drive-details">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-calendar"></i>
                                </div>
                                <div class="detail-text">
                                    <span class="detail-label">Deadline</span>
                                    <span class="detail-value"><?php echo date('d M Y', strtotime($drive['deadline'])); ?></span>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-users"></i>
                                </div>
                                <div class="detail-text">
                                    <span class="detail-label">Eligibility</span>
                                    <span class="detail-value"><?php echo htmlspecialchars($drive['eligibility'] ?? 'All Branches'); ?></span>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-graduation-cap"></i>
                                </div>
                                <div class="detail-text">
                                    <span class="detail-label">Min CGPA</span>
                                    <span class="detail-value"><?php echo $drive['min_cgpa'] ?? 'N/A'; ?></span>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-briefcase"></i>
                                </div>
                                <div class="detail-text">
                                    <span class="detail-label">Package</span>
                                    <span class="detail-value"><?php echo htmlspecialchars($drive['package'] ?? 'Negotiable'); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="drive-footer">
                            <div class="stats-mini">
                                <div class="stat-mini-item">
                                    <i class="fas fa-file-alt"></i>
                                    <span><?php echo $drive['applications']; ?> Applications</span>
                                </div>
                                <div class="stat-mini-item">
                                    <i class="fas fa-check-circle"></i>
                                    <span><?php echo $drive['selected']; ?> Selected</span>
                                </div>
                            </div>
                            
                            <div class="action-buttons">
                                <a href="applications.php?id=<?php echo $drive['id']; ?>" class="action-btn applications-btn">
                                    <i class="fas fa-eye"></i> Applications
                                </a>
                                <a href="view.php?id=<?php echo $drive['id']; ?>" class="action-btn view-btn">
                                    <i class="fas fa-info-circle"></i> Details
                                </a>
                                <a href="edit.php?id=<?php echo $drive['id']; ?>" class="action-btn edit-btn">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="delete.php?id=<?php echo $drive['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this drive?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-briefcase" style="font-size: 48px; margin-bottom: 15px; opacity: 0.3;"></i>
                        <p>No placement drives found</p>
                        <a href="add.php" class="add-btn" style="display: inline-block; margin-top: 15px;">
                            <i class="fas fa-plus"></i> Create Your First Drive
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div class="pagination">
                <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                <a href="#" class="page-link active">1</a>
                <a href="#" class="page-link">2</a>
                <a href="#" class="page-link">3</a>
                <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let cards = document.querySelectorAll('.drive-card');
            
            cards.forEach(card => {
                let text = card.textContent.toLowerCase();
                card.style.display = text.includes(searchText) ? 'block' : 'none';
            });
        });

        // Filter functionality
        document.getElementById('companyFilter').addEventListener('change', filterDrives);
        document.getElementById('statusFilter').addEventListener('change', filterDrives);

        function filterDrives() {
            let companyFilter = document.getElementById('companyFilter').value.toLowerCase();
            let statusFilter = document.getElementById('statusFilter').value.toLowerCase();
            let cards = document.querySelectorAll('.drive-card');
            
            cards.forEach(card => {
                let company = card.getAttribute('data-company').toLowerCase();
                let status = card.getAttribute('data-status').toLowerCase();
                let show = true;
                
                if (companyFilter && !company.includes(companyFilter)) show = false;
                if (statusFilter && !status.includes(statusFilter)) show = false;
                
                card.style.display = show ? 'block' : 'none';
            });
        }
    </script>
</body>
</html>