<div class="sidebar">
    <div class="logo">GLA Admin</div>

    <ul class="nav-links">
        <li><a href="/admin/dashboard.php">Dashboard</a></li>
        <li><a href="/admin/students/">Students</a></li>
        <li><a href="/admin/companies/">Companies</a></li>
        <li><a href="/admin/settings/">Settings</a></li>
        <li><a href="/admin/logout.php" class="logout">Logout</a></li>
    </ul>
</div>