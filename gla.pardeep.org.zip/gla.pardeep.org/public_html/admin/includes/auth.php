<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config/session.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: /admin/login.php");
    exit;
}
?>