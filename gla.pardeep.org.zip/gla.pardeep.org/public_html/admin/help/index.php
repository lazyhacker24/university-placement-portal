<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once '../includes/auth.php';
require_once '../../config/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Help & Support | GLA University</title>
    <!-- Correct CSS path - going up one level to assets -->
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Additional styles specific to help page */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f7fb;
            display: flex;
            min-height: 100vh;
        }

        .help-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .help-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .help-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 30px rgba(0,0,0,0.05);
        }
        
        .help-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 36px;
        }
        
        .help-card h3 {
            font-size: 20px;
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 10px;
        }
        
        .help-card p {
            color: #64748b;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .faq-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .faq-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .faq-header i {
            font-size: 28px;
            color: #1e3c72;
        }
        
        .faq-header h2 {
            font-size: 24px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .faq-item {
            border-bottom: 1px solid #e2e8f0;
            padding: 20px 0;
        }
        
        .faq-item:last-child {
            border-bottom: none;
        }
        
        .faq-question {
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        
        .faq-question h4 {
            font-size: 16px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .faq-question i {
            color: #1e3c72;
            transition: transform 0.3s;
        }
        
        .faq-answer {
            display: none;
            padding-top: 15px;
            color: #64748b;
            font-size: 14px;
            line-height: 1.8;
        }
        
        .faq-answer.show {
            display: block;
        }
        
        .contact-section {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .contact-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .contact-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }
        
        .contact-info {
            flex: 1;
        }
        
        .contact-info h4 {
            font-size: 16px;
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 5px;
        }
        
        .contact-info p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .contact-info a {
            color: #1e3c72;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }
        
        .video-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        
        .video-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .video-thumbnail {
            height: 140px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
        }
        
        .video-info {
            padding: 15px;
        }
        
        .video-info h4 {
            font-size: 14px;
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 5px;
        }
        
        .video-info p {
            font-size: 12px;
            color: #64748b;
        }
        
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            background: #f5f7fb;
        }
        
        .dashboard-container {
            padding: 30px;
        }
        
        @media (max-width: 992px) {
            .help-grid,
            .video-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
            
            .help-grid,
            .contact-section,
            .video-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Include sidebar with correct path -->
    <?php include '../includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Help & Support</h1>
                    <p>Find answers and get assistance</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search help articles...">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Help Categories -->
            <div class="help-grid">
                <div class="help-card" onclick="location.href='getting-started.php'">
                    <div class="help-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3>Getting Started</h3>
                    <p>Learn the basics of SPMS and how to navigate the system</p>
                </div>
                
                <div class="help-card" onclick="location.href='students-guide.php'">
                    <div class="help-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h3>Student Management</h3>
                    <p>Guide to managing student profiles and applications</p>
                </div>
                
                <div class="help-card" onclick="location.href='companies-guide.php'">
                    <div class="help-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3>Companies & Drives</h3>
                    <p>How to manage companies and placement drives</p>
                </div>
                
                <div class="help-card" onclick="location.href='reports-guide.php'">
                    <div class="help-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3>Reports & Analytics</h3>
                    <p>Understanding placement statistics and reports</p>
                </div>
                
                <div class="help-card" onclick="location.href='settings-guide.php'">
                    <div class="help-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <h3>System Settings</h3>
                    <p>Configure system preferences and security</p>
                </div>
                
                <div class="help-card" onclick="location.href='troubleshooting.php'">
                    <div class="help-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <h3>Troubleshooting</h3>
                    <p>Common issues and their solutions</p>
                </div>
            </div>

            <!-- FAQ Section -->
            <div class="faq-section">
                <div class="faq-header">
                    <i class="fas fa-question-circle"></i>
                    <h2>Frequently Asked Questions</h2>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <h4>How do I add a new student?</h4>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        To add a new student, go to the Students section and click on "Add New Student". 
                        Fill in the required information including name, enrollment number, branch, and semester. 
                        Make sure to verify the email address before saving.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <h4>How to create a placement drive?</h4>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Navigate to Placement Drives and click "Create New Drive". Select the company, 
                        enter drive details like title, deadline, eligibility criteria, and package. 
                        Set the drive status to active when ready to accept applications.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <h4>How to generate placement reports?</h4>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Go to the Reports section where you'll find various analytics including branch-wise 
                        placement, company-wise statistics, and monthly trends. You can export reports as 
                        PDF or Excel using the export buttons.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFAQ(this)">
                        <h4>What to do if I forget my password?</h4>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Use the "Forgot Password" option on the login page. You'll receive a password reset 
                        link on your registered email. If you don't receive the email, contact the system 
                        administrator at admin@gla.ac.in.
                    </div>
                </div>
            </div>

            <!-- Contact Support -->
            <div class="contact-section">
                <div class="contact-card">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Email Support</h4>
                        <p>support@gla.ac.in</p>
                        <p>Response within 24 hours</p>
                    </div>
                </div>
                
                <div class="contact-card">
                    <div class="contact-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Phone Support</h4>
                        <p>+91 12345 67890</p>
                        <p>Mon-Fri, 9 AM - 6 PM</p>
                    </div>
                </div>
                
                <div class="contact-card">
                    <div class="contact-icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Live Chat</h4>
                        <p>Chat with our support team</p>
                        <a href="#">Start Chat →</a>
                    </div>
                </div>
                
                <div class="contact-card">
                    <div class="contact-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Documentation</h4>
                        <p>Read the full documentation</p>
                        <a href="docs.php">View Docs →</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        function toggleFAQ(element) {
            element.classList.toggle('active');
            const answer = element.nextElementSibling;
            answer.classList.toggle('show');
            
            const icon = element.querySelector('i');
            if (answer.classList.contains('show')) {
                icon.style.transform = 'rotate(180deg)';
            } else {
                icon.style.transform = 'rotate(0deg)';
            }
        }
    </script>
</body>
</html>