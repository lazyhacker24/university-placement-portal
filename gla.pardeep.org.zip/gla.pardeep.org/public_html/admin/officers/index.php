<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

require_once '../../config/session.php';
require_once '../../config/db.php';
require_once '../includes/auth.php';
require_once '../../api/mail/officer_mail.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: ../login.php");
    exit;
}

/* ================= AJAX REQUESTS ================= */

if(isset($_POST['action'])){

    header('Content-Type: application/json');

    $action = $_POST['action'];

    /* ADD OFFICER */
    if($action === 'add'){

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $department = trim($_POST['department']);
    $status = trim($_POST['status']);

    /* GENERATE STAFF ID */

    $next_id = $conn->query("SELECT AUTO_INCREMENT 
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'placement_officers'")
->fetch_assoc()['AUTO_INCREMENT'];

$staff_id = "GLA-PO-" . str_pad($next_id,4,"0",STR_PAD_LEFT);

        if(!$name || !$email){
            echo json_encode(["success"=>false,"message"=>"Name and email required"]);
            exit;
        }

        /* check email */
        $stmt = $conn->prepare("SELECT id FROM placement_officers WHERE email=?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            echo json_encode(["success"=>false,"message"=>"Email already exists"]);
            exit;
        }

        $password = NULL;

       $stmt = $conn->prepare("
INSERT INTO placement_officers
(staff_id,name,email,phone,department,status,created_at)
VALUES (?,?,?,?,?,?,NOW())
");

        $stmt->bind_param("ssssss",$staff_id,$name,$email,$phone,$department,$status);

     if($stmt->execute()){

$officer_id = $stmt->insert_id;

/* TOKEN GENERATE */

$token = bin2hex(random_bytes(32));
$expires = date("Y-m-d H:i:s", strtotime("+5 minutes"));

$stmt2 = $conn->prepare("INSERT INTO officer_password_tokens (officer_id,token,expires_at) VALUES (?,?,?)");
$stmt2->bind_param("iss",$officer_id,$token,$expires);
$stmt2->execute();

/* SEND EMAIL */

$mailSent = sendOfficerWelcome($name,$email,$phone,$staff_id,$token);

if(!$mailSent){
echo json_encode([
"success"=>false,
"message"=>"Officer added but email failed"
]);
exit;
}

echo json_encode([
"success"=>true,
"message"=>"Officer added successfully"
]);
exit;

}else{

echo json_encode([
"success"=>false,
"message"=>$conn->error
]);
exit;

}
    }

    /* EDIT OFFICER */

    if($action === 'edit'){

        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $department = trim($_POST['department']);
        $status = trim($_POST['status']);

        $stmt = $conn->prepare("SELECT id FROM placement_officers WHERE email=? AND id!=?");
        $stmt->bind_param("si",$email,$id);
        $stmt->execute();
        $res = $stmt->get_result();

        if($res->num_rows > 0){
            echo json_encode(["success"=>false,"message"=>"Email already exists"]);
            exit;
        }

        $stmt = $conn->prepare("
        UPDATE placement_officers 
        SET name=?, email=?, phone=?, department=?, status=? 
        WHERE id=?
        ");

        $stmt->bind_param("sssssi",$name,$email,$phone,$department,$status,$id);

        if($stmt->execute()){
            echo json_encode(["success"=>true,"message"=>"Officer updated"]);
        }else{
            echo json_encode(["success"=>false,"message"=>$conn->error]);
        }

        exit;
    }

    /* CHANGE STATUS */

    if($action === 'update_status'){

        $id = intval($_POST['id']);
        $status = $_POST['status'];

        $stmt = $conn->prepare("UPDATE placement_officers SET status=? WHERE id=?");
        $stmt->bind_param("si",$status,$id);

        if($stmt->execute()){
            echo json_encode(["success"=>true,"message"=>"Status updated"]);
        }else{
            echo json_encode(["success"=>false,"message"=>$conn->error]);
        }

        exit;
    }

    /* DELETE */

    if($action === 'delete'){

        $id = intval($_POST['id']);

        $stmt = $conn->prepare("DELETE FROM placement_officers WHERE id=?");
        $stmt->bind_param("i",$id);

        if($stmt->execute()){
            echo json_encode(["success"=>true,"message"=>"Officer deleted"]);
        }else{
            echo json_encode(["success"=>false,"message"=>$conn->error]);
        }

        exit;
    }

    /* GET OFFICER */

    if($action === 'get'){

        $id = intval($_POST['id']);

        $stmt = $conn->prepare("SELECT * FROM placement_officers WHERE id=?");
        $stmt->bind_param("i",$id);
        $stmt->execute();

        $res = $stmt->get_result();

        if($res->num_rows){
            echo json_encode(["success"=>true,"data"=>$res->fetch_assoc()]);
        }else{
            echo json_encode(["success"=>false,"message"=>"Officer not found"]);
        }

        exit;
    }
}

/* ================= PAGE DATA ================= */

/* sidebar stats */

$total_students = $conn->query("SELECT COUNT(*) c FROM students")->fetch_assoc()['c'] ?? 0;
$total_companies = $conn->query("SELECT COUNT(*) c FROM companies")->fetch_assoc()['c'] ?? 0;
$total_applications = $conn->query("SELECT COUNT(*) c FROM applications")->fetch_assoc()['c'] ?? 0;
$active_drives = $conn->query("SELECT COUNT(*) c FROM placement_drives WHERE status='active'")->fetch_assoc()['c'] ?? 0;

/* officer stats */

$total_officers = $conn->query("SELECT COUNT(*) c FROM placement_officers")->fetch_assoc()['c'] ?? 0;

$active_officers = $conn->query("SELECT COUNT(*) c FROM placement_officers WHERE status='active'")->fetch_assoc()['c'] ?? 0;

$inactive_officers = $conn->query("SELECT COUNT(*) c FROM placement_officers WHERE status='inactive'")->fetch_assoc()['c'] ?? 0;

/* officers list */

$officers = $conn->query("SELECT * FROM placement_officers ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Placement Officers | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f7fb;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles - These are critical for proper display */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0a1a2f 0%, #1e3c72 100%);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .shield-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #ffd700, #ffa500);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #1e3c72;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
        }

        .logo-text .gla {
            font-size: 24px;
            font-weight: 800;
            color: white;
        }

        .logo-text .admin {
            font-size: 12px;
            opacity: 0.7;
            text-transform: uppercase;
        }

        .admin-profile {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .profile-image {
            width: 50px;
            height: 50px;
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #ffd700;
        }

        .profile-info h4 {
            font-size: 16px;
            font-weight: 600;
            color: white;
        }

        .profile-info p {
            font-size: 12px;
            opacity: 0.7;
            color: white;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-title {
            padding: 15px 25px 5px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            color: rgba(255,255,255,0.5);
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 25px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            gap: 12px;
            transition: all 0.3s;
        }

        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .sidebar-menu a.active {
            background: linear-gradient(90deg, rgba(255,255,255,0.15), transparent);
            color: white;
            border-left: 4px solid #ffd700;
        }

        .menu-icon {
            width: 30px;
            font-size: 18px;
        }

        .menu-badge {
            margin-left: auto;
            background: rgba(255,255,255,0.2);
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 11px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .storage-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 12px;
            color: rgba(255,255,255,0.7);
        }

        .storage-info i {
            font-size: 20px;
        }

        .progress-bar {
            height: 4px;
            background: rgba(255,255,255,0.2);
            border-radius: 2px;
            margin: 5px 0;
        }

        .progress {
            height: 100%;
            background: #ffd700;
            border-radius: 2px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            background: #f5f7fb;
        }

        .top-header {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #1e3c72;
            cursor: pointer;
        }

        .page-title h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e3c72;
        }

        .page-title p {
            font-size: 13px;
            color: #64748b;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }

        .search-box input {
            padding: 10px 15px 10px 45px;
            border: 1px solid #e2e8f0;
            border-radius: 30px;
            width: 250px;
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: #1e3c72;
        }

        .notifications {
            position: relative;
            cursor: pointer;
        }

        .notifications i {
            font-size: 20px;
            color: #64748b;
        }

        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ef4444;
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 10px;
        }

        .header-date {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 15px;
            background: #f8fafc;
            border-radius: 30px;
            font-size: 13px;
            color: #475569;
        }

        .dashboard-container {
            padding: 30px;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.03);
        }

        .stat-card .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stat-card.primary .stat-icon {
            background: #e8f0fe;
            color: #1e3c72;
        }

        .stat-card.success .stat-icon {
            background: #d1fae5;
            color: #10b981;
        }

        .stat-card.warning .stat-icon {
            background: #fef3c7;
            color: #f59e0b;
        }

        .stat-content .stat-label {
            font-size: 13px;
            color: #64748b;
        }

        .stat-number {
            font-size: 28px;
            font-weight: 700;
            color: #1e3c72;
        }

        /* Action Bar */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .add-btn {
            background: #1e3c72;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .add-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }

        .filter-section {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .filter-select {
            padding: 10px 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #475569;
            background: white;
            cursor: pointer;
        }

        /* Officers Table */
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.03);
        }

        .table-responsive {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            padding: 15px;
            font-size: 13px;
            font-weight: 600;
            color: #64748b;
            border-bottom: 2px solid #e2e8f0;
        }

        .data-table td {
            padding: 15px;
            font-size: 14px;
            color: #475569;
            border-bottom: 1px solid #e2e8f0;
        }

        .data-table tbody tr:hover {
            background: #f8fafc;
        }

        .officer-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .officer-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }

        .officer-details .name {
            font-weight: 600;
            color: #1e3c72;
        }

        .officer-details .email {
            font-size: 12px;
            color: #64748b;
        }

        .staff-id {
            font-family: monospace;
            font-size: 13px;
            color: #475569;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .status-badge.active {
            background: #d1fae5;
            color: #065f46;
        }

        .status-badge.inactive {
            background: #fee2e2;
            color: #b91c1c;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            background: transparent;
            color: #64748b;
        }

        .action-btn:hover {
            background: #f1f5f9;
        }

        .action-btn.view:hover {
            color: #1e3c72;
        }

        .action-btn.edit:hover {
            color: #f59e0b;
        }

        .action-btn.delete:hover {
            color: #ef4444;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.3s ease;
        }

        @keyframes modalSlide {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            padding: 20px 25px;
            border-bottom: 2px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e3c72;
        }

        .modal-close {
            width: 35px;
            height: 35px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .modal-close:hover {
            background: #fee2e2;
            color: #ef4444;
        }

        .modal-body {
            padding: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #1e3c72;
        }

        .modal-footer {
            padding: 20px 25px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #1e3c72;
            color: white;
        }

        .btn-primary:hover {
            background: #2a5298;
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        /* Toast */
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 3000;
            border-left: 4px solid;
        }

        .toast.success {
            border-left-color: #10b981;
        }

        .toast.success i {
            color: #10b981;
        }

        .toast.error {
            border-left-color: #ef4444;
        }

        .toast.error i {
            color: #ef4444;
        }

        .no-data {
            text-align: center;
            padding: 50px;
            color: #94a3b8;
        }

        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
            }
            .menu-toggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar (Hardcoded to ensure it appears) -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="../dashboard.php">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="../students/">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students ?? 0; ?></div>
            </a>
            <a href="../companies/">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies ?? 0; ?></div>
            </a>
            <a href="../drives/">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $active_drives ?? 0; ?></div>
            </a>
            <a href="../applications/">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications ?? 0; ?></div>
            </a>
            <a href="index.php" class="active">
                <div class="menu-icon"><i class="fas fa-user-tie"></i></div>
                <span>Placement Officers</span>
                <div class="menu-badge"><?php echo $total_officers; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="../reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="../settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="../help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="../profile.php">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="../logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Placement Officers</h1>
                    <p>Manage placement officers and their permissions</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search officers...">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Officers</span>
                        <h3 class="stat-number"><?php echo $total_officers; ?></h3>
                    </div>
                </div>

                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Active</span>
                        <h3 class="stat-number"><?php echo $active_officers; ?></h3>
                    </div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Inactive</span>
                        <h3 class="stat-number"><?php echo $inactive_officers; ?></h3>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="filter-section">
                    <select class="filter-select" id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <button class="add-btn" onclick="openAddModal()">
                    <i class="fas fa-plus"></i> Add Placement Officer
                </button>
            </div>

            <!-- Officers Table -->
            <div class="table-card">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Officer</th>
                                <th>Staff ID</th>
                                <th>Department</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="officersTableBody">
                            <?php if ($officers && $officers->num_rows > 0): ?>
                                <?php while($officer = $officers->fetch_assoc()): ?>
                                <tr data-id="<?php echo $officer['id']; ?>">
                                    <td>
                                        <div class="officer-info">
                                            <div class="officer-avatar">
                                                <?php echo strtoupper(substr($officer['name'], 0, 1)); ?>
                                            </div>
                                            <div class="officer-details">
                                                <div class="name"><?php echo htmlspecialchars($officer['name']); ?></div>
                                                <div class="email"><?php echo htmlspecialchars($officer['email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="staff-id"><?php echo $officer['staff_id']; ?></td>
                                    <td><?php echo htmlspecialchars($officer['department'] ?? 'Placement Cell'); ?></td>
                                    <td><?php echo htmlspecialchars($officer['phone'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $officer['status']; ?>">
                                            <?php echo ucfirst($officer['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="action-btn view" onclick="viewOfficer(<?php echo $officer['id']; ?>)" title="View">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="action-btn edit" onclick="editOfficer(<?php echo $officer['id']; ?>)" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($officer['status'] == 'active'): ?>
                                            <button class="action-btn" onclick="blockOfficer(<?php echo $officer['id']; ?>)" title="Block">
                                                <i class="fas fa-ban" style="color: #64748b;"></i>
                                            </button>
                                            <?php else: ?>
                                            <button class="action-btn" onclick="unblockOfficer(<?php echo $officer['id']; ?>)" title="Unblock">
                                                <i class="fas fa-check-circle" style="color: #10b981;"></i>
                                            </button>
                                            <?php endif; ?>
                                            <button class="action-btn delete" onclick="deleteOfficer(<?php echo $officer['id']; ?>)" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="no-data">No placement officers found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit Modal -->
    <div class="modal" id="officerModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Add Placement Officer</h2>
                <div class="modal-close" onclick="closeModal()">
                    <i class="fas fa-times"></i>
                </div>
            </div>
            <div class="modal-body">
                <form id="officerForm">
                    <input type="hidden" id="officerId" name="id">
                    
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="name" required placeholder="Enter full name">
                    </div>
                    
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="email" required placeholder="Enter email address">
                    </div>
                    
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" id="phone" placeholder="Enter phone number">
                    </div>
                    
                    <div class="form-group">
                        <label>Department</label>
                        <select id="department">
                            <option value="Placement Cell">Placement Cell</option>
                            <option value="Training Department">Training Department</option>
                            <option value="Career Services">Career Services</option>
                            <option value="Corporate Relations">Corporate Relations</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="statusGroup" style="display: none;">
                        <label>Status</label>
                        <select id="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button class="btn btn-primary" onclick="saveOfficer()">Save Officer</button>
            </div>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal" id="deleteModal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h2>Confirm Delete</h2>
                <div class="modal-close" onclick="closeDeleteModal()">
                    <i class="fas fa-times"></i>
                </div>
            </div>
            <div class="modal-body" style="text-align: center;">
                <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: #ef4444; margin-bottom: 15px;"></i>
                <p style="margin-bottom: 10px;">Are you sure you want to delete this officer?</p>
                <p style="color: #64748b;">This action cannot be undone.</p>
                <input type="hidden" id="deleteOfficerId">
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                <button class="btn btn-danger" onclick="confirmDelete()">Delete</button>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal" id="viewModal">
        <div class="modal-content" style="max-width: 450px;">
            <div class="modal-header">
                <h2>Officer Details</h2>
                <div class="modal-close" onclick="closeViewModal()">
                    <i class="fas fa-times"></i>
                </div>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Content will be filled by JavaScript -->
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="closeViewModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="toast" style="display: none;">
        <i class="fas"></i>
        <span id="toastMessage"></span>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let rows = document.querySelectorAll('#officersTableBody tr');
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Filter by status
        document.getElementById('statusFilter').addEventListener('change', function() {
            let status = this.value.toLowerCase();
            let rows = document.querySelectorAll('#officersTableBody tr');
            
            rows.forEach(row => {
                if (!status) {
                    row.style.display = '';
                    return;
                }
                let rowStatus = row.querySelector('.status-badge').textContent.toLowerCase().trim();
                row.style.display = rowStatus.includes(status) ? '' : 'none';
            });
        });

        // Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Add Placement Officer';
            document.getElementById('officerForm').reset();
            document.getElementById('officerId').value = '';
            document.getElementById('statusGroup').style.display = 'none';
            document.getElementById('officerModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('officerModal').classList.remove('show');
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.remove('show');
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('show');
        }

        function showToast(message, type) {
            const toast = document.getElementById('toast');
            const icon = toast.querySelector('i');
            const span = document.getElementById('toastMessage');
            
            icon.className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
            toast.className = 'toast ' + type;
            span.textContent = message;
            toast.style.display = 'flex';
            
            setTimeout(() => {
                toast.style.display = 'none';
            }, 3000);
        }

        // View Officer
        function viewOfficer(id) {
            const formData = new URLSearchParams({ action: 'get', id: id });
            
            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const o = data.data;
                    const html = `
                        <div style="text-align: center; margin-bottom: 20px;">
                            <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #1e3c72, #2a5298); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; color: white; font-size: 32px; font-weight: 600;">
                                ${o.name.charAt(0).toUpperCase()}
                            </div>
                            <h3 style="color: #1e3c72; margin-bottom: 5px;">${o.name}</h3>
                            <p style="color: #64748b;">${o.email}</p>
                        </div>
                        <div style="background: #f8fafc; border-radius: 10px; padding: 15px;">
                            <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e2e8f0;">
                                <span style="color: #64748b;">Staff ID</span>
                                <span style="font-weight: 600; color: #1e3c72;">${o.staff_id}</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e2e8f0;">
                                <span style="color: #64748b;">Department</span>
                                <span style="font-weight: 600; color: #1e3c72;">${o.department || 'Placement Cell'}</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e2e8f0;">
                                <span style="color: #64748b;">Phone</span>
                                <span style="font-weight: 600; color: #1e3c72;">${o.phone || 'N/A'}</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                                <span style="color: #64748b;">Status</span>
                                <span class="status-badge ${o.status}" style="padding: 4px 12px;">${o.status.charAt(0).toUpperCase() + o.status.slice(1)}</span>
                            </div>
                        </div>
                    `;
                    document.getElementById('viewModalBody').innerHTML = html;
                    document.getElementById('viewModal').classList.add('show');
                } else {
                    showToast(data.message, 'error');
                }
            });
        }

        // Edit Officer
        function editOfficer(id) {
            const formData = new URLSearchParams({ action: 'get', id: id });
            
            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('modalTitle').textContent = 'Edit Officer';
                    document.getElementById('officerId').value = data.data.id;
                    document.getElementById('name').value = data.data.name;
                    document.getElementById('email').value = data.data.email;
                    document.getElementById('phone').value = data.data.phone || '';
                    document.getElementById('department').value = data.data.department || 'Placement Cell';
                    document.getElementById('status').value = data.data.status;
                    document.getElementById('statusGroup').style.display = 'block';
                    document.getElementById('officerModal').classList.add('show');
                } else {
                    showToast(data.message, 'error');
                }
            });
        }

        // Save Officer (Add/Edit)
        function saveOfficer() {
            const id = document.getElementById('officerId').value;
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const department = document.getElementById('department').value;
            const status = id ? document.getElementById('status').value : 'active';

            if (!name || !email) {
                showToast('Please fill all required fields', 'error');
                return;
            }

            const action = id ? 'edit' : 'add';
            const formData = new URLSearchParams({
                action: action,
                name: name,
                email: email,
                phone: phone,
                department: department,
                status: status
            });

            if (id) {
                formData.append('id', id);
            }

            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    closeModal();
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                showToast('Error saving officer', 'error');
            });
        }

        // Block Officer
        function blockOfficer(id) {
            if (!confirm('Are you sure you want to block this officer?')) return;
            
            const formData = new URLSearchParams({
                action: 'update_status',
                id: id,
                status: 'inactive'
            });

            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.message, 'error');
                }
            });
        }

        // Unblock Officer
        function unblockOfficer(id) {
            if (!confirm('Are you sure you want to unblock this officer?')) return;
            
            const formData = new URLSearchParams({
                action: 'update_status',
                id: id,
                status: 'active'
            });

            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.message, 'error');
                }
            });
        }

        // Delete Officer
        function deleteOfficer(id) {
            document.getElementById('deleteOfficerId').value = id;
            document.getElementById('deleteModal').classList.add('show');
        }

        function confirmDelete() {
            const id = document.getElementById('deleteOfficerId').value;
            
            const formData = new URLSearchParams({
                action: 'delete',
                id: id
            });

            fetch('index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    closeDeleteModal();
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.message, 'error');
                }
            });
        }
    </script>
</body>
</html>