<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Initialize message variables
$message = '';
$error = '';

// Get admin ID safely
$admin_id = isset($_SESSION['admin_id']) ? intval($_SESSION['admin_id']) : 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Update Profile
    if (isset($_POST['update_profile'])) {
        $name = $conn->real_escape_string(trim($_POST['name']));

        if (empty($name)) {
            $error = 'Username cannot be empty';
        } else {
            $update = $conn->query("UPDATE admins SET username='$name' WHERE id=$admin_id");

            if ($update) {
                $_SESSION['admin_name'] = $name;
                $message = 'Profile updated successfully';
            } else {
                $error = 'Failed to update profile';
            }
        }
    }

    // Change Password
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];

        $result = $conn->query("SELECT password FROM admins WHERE id=$admin_id");

        if ($result && $result->num_rows > 0) {
            $admin_data = $result->fetch_assoc();

            if ($new != $confirm) {
                $error = 'New passwords do not match';
            } elseif (strlen($new) < 6) {
                $error = 'Password must be at least 6 characters';
            } elseif (!password_verify($current, $admin_data['password'])) {
                $error = 'Current password is incorrect';
            } else {
                $hashed = password_hash($new, PASSWORD_DEFAULT);
                $update = $conn->query("UPDATE admins SET password='$hashed' WHERE id=$admin_id");

                if ($update) {
                    $message = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
            }
        } else {
            $error = 'Admin not found';
        }
    }
}


// Get admin data
$admin = null;
$admin_result = $conn->query("SELECT * FROM admins WHERE id=$admin_id");

if ($admin_result && $admin_result->num_rows > 0) {
    $admin = $admin_result->fetch_assoc();
} else {
    session_destroy();
    header("Location: ../login.php?error=admin_not_found");
    exit;

}

// Check if settings table exists
$settings = [];

// Try to get settings from database if table exists
$table_check = $conn->query("SHOW TABLES LIKE 'settings'");
if ($table_check && $table_check->num_rows > 0) {
    $settings_result = $conn->query("SELECT * FROM settings");
    while($row = $settings_result->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['value'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Settings | GLA University</title>
    <!-- Correct CSS path -->
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f7fb;
            display: flex;
            min-height: 100vh;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            background: #f5f7fb;
        }

        .dashboard-container {
            padding: 30px;
        }

        .settings-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .settings-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        }
        
        .settings-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .settings-header i {
            font-size: 24px;
            color: #1e3c72;
        }
        
        .settings-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e3c72;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #1e3c72;
            box-shadow: 0 0 0 3px rgba(30,60,114,0.1);
        }
        
        .form-group input[readonly] {
            background: #f8fafc;
            cursor: not-allowed;
        }
        
        .save-btn {
            background: #1e3c72;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }
        
        .save-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }
        
        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .message.success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .message.error {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        
        .info-box {
            background: #f8fafc;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 500;
            color: #475569;
        }
        
        .info-value {
            color: #1e3c72;
            font-weight: 600;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #cbd5e1;
            transition: .4s;
            border-radius: 24px;
        }
        
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .toggle-slider {
            background-color: #1e3c72;
        }
        
        input:checked + .toggle-slider:before {
            transform: translateX(26px);
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
            }
            
            .settings-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Include sidebar -->
    <?php include '../includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Settings</h1>
                    <p>Configure system preferences and account settings</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search settings...">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <?php if ($message): ?>
                <div class="message success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="message error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="settings-container">
                <!-- Profile Settings -->
                <div class="settings-card">
                    <div class="settings-header">
                        <i class="fas fa-user-circle"></i>
                        <h2>Profile Settings</h2>
                    </div>
                    
                    <form method="POST">
               <div class="form-group">
    <label>Username</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
</div>
                    
                        
                        <button type="submit" name="update_profile" class="save-btn">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                    
                    <div class="info-box">
                        <h4 style="margin-bottom: 10px; color: #1e3c72;">Account Info</h4>
                        <div class="info-item">
                            <span class="info-label">Member Since</span>
                            <span class="info-value"><?php echo isset($admin['created_at']) ? date('d M Y', strtotime($admin['created_at'])) : '15 Jan 2025'; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Last Login</span>
                            <span class="info-value"><?php echo date('d M Y, h:i A'); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="settings-card">
                    <div class="settings-header">
                        <i class="fas fa-lock"></i>
                        <h2>Change Password</h2>
                    </div>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" name="change_password" class="save-btn">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                    
                    <div class="info-box" style="margin-top: 20px;">
                        <small style="color: #64748b;">Password must be at least 6 characters long and include a mix of letters and numbers.</small>
                    </div>
                </div>

                <!-- System Settings -->
                <div class="settings-card">
                    <div class="settings-header">
                        <i class="fas fa-cog"></i>
                        <h2>System Settings</h2>
                    </div>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label>System Name</label>
                            <input type="text" name="site_name" value="<?php echo htmlspecialchars($settings['site_name'] ?? 'SPMS v2.0'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Contact Email</label>
                            <input type="email" name="contact_email" value="<?php echo htmlspecialchars($settings['contact_email'] ?? 'admin@gla.ac.in'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Current Placement Year</label>
                            <select name="placement_year">
                                <option value="2024" <?php echo ($settings['placement_year'] ?? '') == '2024' ? 'selected' : ''; ?>>2024</option>
                                <option value="2025" <?php echo ($settings['placement_year'] ?? '') == '2025' ? 'selected' : ''; ?>>2025</option>
                                <option value="2026" <?php echo ($settings['placement_year'] ?? '') == '2026' ? 'selected' : ''; ?>>2026</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label style="display: flex; justify-content: space-between; align-items: center;">
                                <span>Maintenance Mode</span>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="maintenance_mode" <?php echo ($settings['maintenance_mode'] ?? '0') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </label>
                        </div>
                        
                        <button type="submit" name="update_system" class="save-btn">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>

                <!-- Backup & Maintenance -->
                <div class="settings-card">
                    <div class="settings-header">
                        <i class="fas fa-database"></i>
                        <h2>Backup & Maintenance</h2>
                    </div>
                    
                    <div style="padding: 20px 0;">
                        <div class="info-item">
                            <span class="info-label">Last Backup</span>
                            <span class="info-value"><?php echo date('d M Y, H:i'); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Database Size</span>
                            <span class="info-value">45 MB</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Backup Schedule</span>
                            <span class="info-value">Daily</span>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <a href="backup.php" class="save-btn" style="background: #10b981;">
                            <i class="fas fa-download"></i> Download Backup
                        </a>
                        <a href="optimize.php" class="save-btn" style="background: #f59e0b;">
                            <i class="fas fa-broom"></i> Optimize
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>