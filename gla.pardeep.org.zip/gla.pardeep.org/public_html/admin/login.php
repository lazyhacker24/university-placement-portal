<!DOCTYPE html>
<html>
<head>
    <title>GLA University | Quantum Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Space Grotesk', 'Segoe UI', sans-serif;
            min-height: 100vh;
            background: #030014;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        /* Cyber Grid Background */
        #cyber-grid {
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(0, 255, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
            transform: perspective(500px) rotateX(60deg);
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: perspective(500px) rotateX(60deg) translateY(0); }
            100% { transform: perspective(500px) rotateX(60deg) translateY(50px); }
        }

        /* Floating Orbs */
        .orb {
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 30%, rgba(74, 108, 247, 0.3), transparent 70%);
            filter: blur(50px);
            animation: orbFloat 15s ease-in-out infinite;
            z-index: 0;
        }

        .orb-1 { top: -100px; left: -100px; animation-delay: 0s; }
        .orb-2 { bottom: -100px; right: -100px; background: radial-gradient(circle at 30% 30%, rgba(255, 70, 150, 0.3), transparent 70%); animation-delay: -5s; }
        .orb-3 { top: 50%; left: 50%; transform: translate(-50%, -50%); width: 500px; height: 500px; opacity: 0.5; animation-delay: -2s; }

        @keyframes orbFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Main Container */
        .quantum-container {
            width: 100%;
            max-width: 1200px;
            position: relative;
            z-index: 10;
        }

        /* Main Content Container */
        .main-content {
            width: 100%;
            background: rgba(10, 10, 30, 0.85);
            backdrop-filter: blur(10px);
            border: 2px solid rgba(74, 108, 247, 0.3);
            border-radius: 30px;
            box-shadow: 
                0 0 50px rgba(74, 108, 247, 0.3),
                inset 0 0 30px rgba(74, 108, 247, 0.2);
            display: flex;
            overflow: hidden;
            position: relative;
        }

        /* Left Side - Holographic Logo */
        .holographic-side {
            flex: 1.2;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, rgba(74, 108, 247, 0.1), rgba(0, 0, 0, 0.5));
            border-right: 1px solid rgba(74, 108, 247, 0.3);
        }

        .holographic-side::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(
                from 0deg,
                #ff6b6b,
                #4ecdc4,
                #45b7d1,
                #96ceb4,
                #ffeaa7,
                #ff6b6b
            );
            animation: hologram 10s linear infinite;
            opacity: 0.1;
            mix-blend-mode: overlay;
        }

        @keyframes hologram {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .glowing-logo {
            position: relative;
            z-index: 2;
            animation: logoGlow 3s ease-in-out infinite;
            margin-bottom: 30px;
        }

        @keyframes logoGlow {
            0%, 100% { filter: drop-shadow(0 0 20px #4a6cf7); }
            50% { filter: drop-shadow(0 0 50px #9f7aea); }
        }

        .glowing-logo img {
            width: 220px;
            height: auto;
            animation: logoPulse 3s ease-in-out infinite;
        }

        @keyframes logoPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .quantum-text {
            text-align: center;
            z-index: 2;
        }

        .quantum-text h1 {
            font-size: 52px;
            font-weight: 900;
            background: linear-gradient(
                135deg,
                #fff,
                #a5b4fc,
                #4a6cf7
            );
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
            line-height: 1.2;
        }

        .quantum-text .location {
            color: rgba(255, 255, 255, 0.7);
            font-size: 18px;
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-bottom: 15px;
        }

        .quantum-badge {
            display: inline-block;
            padding: 8px 20px;
            background: rgba(74, 108, 247, 0.2);
            border: 1px solid rgba(74, 108, 247, 0.5);
            border-radius: 50px;
            color: #a5b4fc;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .particle-field {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: white;
            border-radius: 50%;
            animation: particleFly 10s linear infinite;
        }

        @keyframes particleFly {
            from {
                transform: translateY(100vh) rotate(0deg);
                opacity: 1;
            }
            to {
                transform: translateY(-100vh) rotate(720deg);
                opacity: 0;
            }
        }

        /* Right Side - Quantum Login */
        .quantum-login-side {
            flex: 1;
            padding: 60px 50px;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(20px);
            position: relative;
            overflow-y: auto;
        }

        .quantum-header {
            margin-bottom: 40px;
        }

        .quantum-header h2 {
            font-size: 42px;
            color: white;
            margin-bottom: 10px;
            position: relative;
            display: inline-block;
        }

        .quantum-header h2 span {
            background: linear-gradient(135deg, #4a6cf7, #9f7aea);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .quantum-header p {
            color: rgba(255, 255, 255, 0.5);
            font-size: 14px;
            letter-spacing: 2px;
            position: relative;
            padding-left: 15px;
        }

        .quantum-header p::before {
            content: '→';
            position: absolute;
            left: 0;
            color: #4a6cf7;
            animation: arrow 1s infinite;
        }

        @keyframes arrow {
            0%, 100% { transform: translateX(0); }
            50% { transform: translateX(5px); }
        }

        /* Error Message */
        .error-message {
            background: rgba(255, 0, 0, 0.1);
            border: 1px solid #ff3333;
            color: #ff3333;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 14px;
            backdrop-filter: blur(5px);
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Success Message */
        .success-message {
            background: rgba(0, 255, 0, 0.1);
            border: 1px solid #33ff33;
            color: #33ff33;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 14px;
            backdrop-filter: blur(5px);
        }

        /* Quantum Input Fields */
        .quantum-field {
            margin-bottom: 30px;
        }

        .quantum-field label {
            display: block;
            color: #4a6cf7;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .input-container {
            position: relative;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(74, 108, 247, 0.3);
            transition: all 0.3s;
        }

        .input-container:focus-within {
            border-color: #4a6cf7;
            box-shadow: 0 0 20px rgba(74, 108, 247, 0.3);
            background: rgba(74, 108, 247, 0.1);
        }

        .input-container input {
            width: 100%;
            padding: 16px 20px;
            background: transparent;
            border: none;
            font-size: 16px;
            color: white;
            position: relative;
            z-index: 2;
        }

        .input-container input:focus {
            outline: none;
        }

        .input-container input::placeholder {
            color: rgba(255, 255, 255, 0.3);
            font-size: 14px;
        }

        /* Quantum Button */
        .quantum-button {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #4a6cf7, #6f4ef7);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            margin: 30px 0;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }

        .quantum-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent,
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transition: left 0.5s;
        }

        .quantum-button:hover::before {
            left: 100%;
        }

        .quantum-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(74, 108, 247, 0.5);
        }

        .quantum-button:active {
            transform: translateY(0);
        }

        /* Holographic Footer */
        .holographic-footer {
            margin-top: 30px;
            padding-top: 25px;
            text-align: center;
            border-top: 1px solid rgba(74, 108, 247, 0.3);
            position: relative;
        }

        .holographic-footer p {
            color: rgba(255, 255, 255, 0.5);
            font-size: 14px;
        }

        .holographic-footer .signature {
            color: #4a6cf7;
            font-weight: 600;
            position: relative;
        }

        .holographic-footer .signature::before,
        .holographic-footer .signature::after {
            content: '⚡';
            margin: 0 5px;
            opacity: 0.5;
        }

        /* Floating Interface Elements */
        .float-element {
            position: absolute;
            background: rgba(74, 108, 247, 0.1);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(74, 108, 247, 0.3);
            border-radius: 30px;
            padding: 10px 20px;
            color: white;
            font-size: 14px;
            z-index: 100;
            animation: elementFloat 6s ease-in-out infinite;
        }

        .float-1 {
            top: 15%;
            right: 5%;
            animation-delay: 0s;
        }

        .float-2 {
            bottom: 15%;
            left: 5%;
            animation-delay: -2s;
        }

        .float-3 {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -4s;
        }

        @keyframes elementFloat {
            0%, 100% { transform: translateY(0) translateX(0); }
            50% { transform: translateY(-15px) translateX(5px); }
        }

        /* Responsive Design */
        @media (max-width: 1000px) {
            .main-content {
                flex-direction: column;
            }
            
            .holographic-side {
                border-right: none;
                border-bottom: 1px solid rgba(74, 108, 247, 0.3);
                padding: 40px 30px;
            }
            
            .float-element {
                display: none;
            }
            
            .glowing-logo img {
                width: 180px;
            }
            
            .quantum-text h1 {
                font-size: 42px;
            }
        }

        @media (max-width: 480px) {
            .quantum-login-side {
                padding: 40px 25px;
            }
            
            .quantum-header h2 {
                font-size: 32px;
            }
            
            .quantum-button {
                padding: 16px;
                font-size: 16px;
            }
            
            .holographic-side {
                padding: 30px 20px;
            }
            
            .quantum-text h1 {
                font-size: 36px;
            }
            
            .quantum-text .location {
                font-size: 14px;
                letter-spacing: 2px;
            }
        }

        /* Loading State */
        .quantum-button.loading {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .quantum-button.loading::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            border: 2px solid transparent;
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        @keyframes spin {
            to { transform: translateY(-50%) rotate(360deg); }
        }
    </style>
</head>
<body>
    <div id="cyber-grid"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>

    <!-- Floating UI Elements -->
    <div class="float-element float-1">
        <span>🔮 QUANTUM SECURE</span>
    </div>
    <div class="float-element float-2">
        <span>⚡ GLA NETWORK</span>
    </div>
    <div class="float-element float-3">
        <span>🌐 ENCRYPTED</span>
    </div>

    <div class="quantum-container">
        <!-- Main Content -->
        <div class="main-content">
            <!-- Left Side - Logo Section -->
            <div class="holographic-side">
                <div class="glowing-logo">
                    <img src="/assets/img/gla-logo.png" 
                         alt="GLA University Logo"
                         onerror="this.src='https://via.placeholder.com/200x200?text=GLA+University'">
                </div>
                
                <div class="quantum-text">
                    <h1>GLA UNIVERSITY</h1>
                    <div class="location">MATHURA · INDIA</div>
                    <div class="quantum-badge">ESTABLISHED 2010</div>
                </div>

                <div class="particle-field" id="particle-field"></div>
            </div>

            <!-- Right Side - Login Form -->
            <div class="quantum-login-side">
                <?php
                session_start();
                $error = isset($_SESSION['login_error']) ? $_SESSION['login_error'] : '';
                unset($_SESSION['login_error']);
                
                $success = isset($_SESSION['login_success']) ? $_SESSION['login_success'] : '';
                unset($_SESSION['login_success']);
                ?>
                
                <?php if($error): ?>
                <div class="error-message">⚠️ <?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="success-message">✓ <?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <div class="quantum-header">
                    <h2>QUANTUM <span>ACCESS</span></h2>
                    <p>ADMIN AUTHENTICATION REQUIRED</p>
                </div>

                <form method="POST" action="login_process.php" id="loginForm">
                    <div class="quantum-field">
                        <label>USERNAME</label>
                        <div class="input-container">
                            <input type="text" name="username" 
                                   placeholder="Enter your username" 
                                   required
                                   autocomplete="off">
                        </div>
                    </div>

                    <div class="quantum-field">
                        <label>PASSWORD</label>
                        <div class="input-container">
                            <input type="password" name="password" 
                                   placeholder="Enter your password" 
                                   required>
                        </div>
                    </div>

                    <button type="submit" class="quantum-button" id="loginBtn">
                        ⚡ INITIALIZE LOGIN ⚡
                    </button>

                    <div class="holographic-footer">
                        <p>© 2026 <span class="signature">Pardeep Kumar</span> · All Rights Reserved</p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Particle System
        function createParticles() {
            const field = document.getElementById('particle-field');
            if (!field) return;
            
            for (let i = 0; i < 30; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 10 + 's';
                particle.style.animationDuration = (5 + Math.random() * 10) + 's';
                particle.style.background = `hsl(${Math.random() * 60 + 200}, 70%, 60%)`;
                field.appendChild(particle);
            }
        }

        // Form Loading State
        document.getElementById('loginForm')?.addEventListener('submit', function(e) {
            const btn = document.getElementById('loginBtn');
            btn.classList.add('loading');
            btn.textContent = 'PROCESSING...';
        });

        window.onload = function() {
            createParticles();
        };
    </script>
</body>
</html>