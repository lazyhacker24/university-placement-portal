<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'includes/auth.php';
require_once '../config/db.php';

// Get statistics
$total_students = $conn->query("SELECT COUNT(*) as c FROM students")->fetch_assoc()['c'] ?? 0;
$total_officers = $conn->query("SELECT COUNT(*) as c FROM placement_officers")->fetch_assoc()['c'] ?? 0;
$total_companies = $conn->query("SELECT COUNT(*) as c FROM companies")->fetch_assoc()['c'] ?? 0;
$total_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives")->fetch_assoc()['c'] ?? 0;
$total_applications = $conn->query("SELECT COUNT(*) as c FROM applications")->fetch_assoc()['c'] ?? 0;
$placed_students = $conn->query("SELECT COUNT(*) as c FROM students WHERE placement_status='Placed'")->fetch_assoc()['c'] ?? 0;
$active_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives WHERE drive_status='active'")->fetch_assoc()['c'] ?? 0;

// Get recent activities
$recent_activities = $conn->query("
    (SELECT CONCAT(full_name, ' registered') as activity, created_at, 'student' as type FROM students)
    UNION ALL
    (SELECT CONCAT(company_name, ' added') as activity, created_at, 'company' as type FROM companies)
    UNION ALL
    (SELECT CONCAT('Drive: ', title) as activity, created_at, 'drive' as type FROM placement_drives)
    ORDER BY created_at DESC
    LIMIT 10
");

$upcoming_drives = $conn->query("
    SELECT pd.title, c.company_name, pd.deadline as drive_date
    FROM placement_drives pd
    JOIN companies c ON pd.company_id = c.company_id
    WHERE pd.deadline >= CURDATE()
    ORDER BY pd.deadline ASC
    LIMIT 5
");

$top_companies = $conn->query("
    SELECT c.company_name, COUNT(a.id) as applications
    FROM companies c
    LEFT JOIN placement_drives pd ON c.company_id = pd.company_id
    LEFT JOIN applications a ON pd.id = a.drive_id
    GROUP BY c.company_id
    ORDER BY applications DESC
    LIMIT 5
");

// Get placement statistics by branch
$branch_stats = $conn->query("
    SELECT branch, COUNT(*) as total, 
    SUM(CASE WHEN placement_status='Placed' THEN 1 ELSE 0 END) as placed 
    FROM students 
    WHERE branch IS NOT NULL
    GROUP BY branch 
    LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard | GLA University</title>
    <link rel="stylesheet" href="assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Left Sidebar with Shield Menu -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
            <div class="version-badge">v2.0</div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="dashboard.php" class="active">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="students/">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students; ?></div>
            </a>
            <a href="officers/">
                <div class="menu-icon"><i class="fas fa-user-tie"></i></div>
                <span>Officers</span>
                <div class="menu-badge"><?php echo $total_officers; ?></div>
            </a>
            <a href="companies/">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies; ?></div>
            </a>
            <a href="drives/">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $active_drives; ?></div>
            </a>
            <a href="applications/">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="profile">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Dashboard Overview</h1>
                    <p>Welcome back, <?php echo $_SESSION['admin_name'] ?? 'Admin'; ?>! Here's what's happening today.</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search...">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Welcome Banner -->
            <div class="welcome-banner">
                <div class="banner-content">
                    <h2>GLA University Placement System</h2>
                    <p>Manage students, companies, and placement drives efficiently</p>
                </div>
                <div class="banner-stats">
                    <div class="banner-stat">
                        <span class="stat-value"><?php echo $placed_students; ?></span>
                        <span class="stat-label">Placed</span>
                    </div>
                    <div class="banner-stat">
                        <span class="stat-value"><?php echo $active_drives; ?></span>
                        <span class="stat-label">Active Drives</span>
                    </div>
                    <div class="banner-stat">
                        <span class="stat-value"><?php echo $total_companies; ?></span>
                        <span class="stat-label">Partners</span>
                    </div>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Students</span>
                        <h3 class="stat-number"><?php echo $total_students; ?></h3>
                        <div class="stat-trend positive">
                            <i class="fas fa-arrow-up"></i> +12% this month
                        </div>
                    </div>
                </div>

                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Companies</span>
                        <h3 class="stat-number"><?php echo $total_companies; ?></h3>
                        <div class="stat-trend positive">
                            <i class="fas fa-arrow-up"></i> +5 new
                        </div>
                    </div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Placement Drives</span>
                        <h3 class="stat-number"><?php echo $total_drives; ?></h3>
                        <div class="stat-trend">
                            <i class="fas fa-clock"></i> <?php echo $active_drives; ?> active
                        </div>
                    </div>
                </div>

                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Applications</span>
                        <h3 class="stat-number"><?php echo $total_applications; ?></h3>
                        <div class="stat-trend positive">
                            <i class="fas fa-arrow-up"></i> +23%
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts and Analytics Row -->
            <div class="analytics-row">
                <div class="chart-card">
                    <div class="card-header">
                        <h3>Placement Statistics by Branch</h3>
                        <div class="card-actions">
                            <i class="fas fa-ellipsis-v"></i>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="branchChart"></canvas>
                    </div>
                </div>

                <div class="stats-mini-grid">
                    <div class="mini-stat">
                        <div class="mini-stat-icon placed">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="mini-stat-content">
                            <span class="mini-stat-label">Placed Students</span>
                            <span class="mini-stat-value"><?php echo $placed_students; ?></span>
                        </div>
                    </div>
                    <div class="mini-stat">
                        <div class="mini-stat-icon pending">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="mini-stat-content">
                            <span class="mini-stat-label">Pending</span>
                            <span class="mini-stat-value"><?php echo $total_students - $placed_students; ?></span>
                        </div>
                    </div>
                    <div class="mini-stat">
                        <div class="mini-stat-icon companies">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="mini-stat-content">
                            <span class="mini-stat-label">Active Companies</span>
                            <span class="mini-stat-value"><?php echo $total_companies; ?></span>
                        </div>
                    </div>
                    <div class="mini-stat">
                        <div class="mini-stat-icon drives">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="mini-stat-content">
                            <span class="mini-stat-label">Upcoming Drives</span>
                            <span class="mini-stat-value"><?php echo $upcoming_drives->num_rows; ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tables Row -->
            <div class="tables-row">
                <!-- Upcoming Drives -->
                <div class="table-card">
                    <div class="card-header">
                        <h3>Upcoming Placement Drives</h3>
                        <a href="drives/" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Drive Name</th>
                                    <th>Company</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($upcoming_drives && $upcoming_drives->num_rows > 0): ?>
                                    <?php while($drive = $upcoming_drives->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($drive['title']); ?></td>
                                        <td><?php echo htmlspecialchars($drive['company_name']); ?></td>
                                        <td><?php echo date('d M Y', strtotime($drive['drive_date'])); ?></td>
                                        <td><span class="badge badge-upcoming">Upcoming</span></td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="no-data">No upcoming drives</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Top Companies -->
                <div class="table-card">
                    <div class="card-header">
                        <h3>Top Recruiting Companies</h3>
                        <a href="companies/" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Company</th>
                                    <th>Applications</th>
                                    <th>Performance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($top_companies && $top_companies->num_rows > 0): ?>
                                    <?php while($company = $top_companies->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($company['company_name']); ?></td>
                                        <td><?php echo $company['applications']; ?></td>
                                        <td>
                                            <div class="progress-bar small">
                                                <div class="progress" style="width: <?php echo min(100, ($company['applications'] * 10)); ?>%"></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3" class="no-data">No data available</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="activity-card">
                <div class="card-header">
                    <h3>Recent Activities</h3>
                    <div class="activity-filters">
                        <span class="filter active">All</span>
                        <span class="filter">Students</span>
                        <span class="filter">Companies</span>
                        <span class="filter">Drives</span>
                    </div>
                </div>
                <div class="activity-timeline">
                    <?php if ($recent_activities && $recent_activities->num_rows > 0): ?>
                        <?php while($activity = $recent_activities->fetch_assoc()): ?>
                        <div class="timeline-item <?php echo $activity['type']; ?>">
                            <div class="timeline-icon">
                                <?php if($activity['type'] == 'student'): ?>
                                    <i class="fas fa-user-graduate"></i>
                                <?php elseif($activity['type'] == 'company'): ?>
                                    <i class="fas fa-building"></i>
                                <?php else: ?>
                                    <i class="fas fa-briefcase"></i>
                                <?php endif; ?>
                            </div>
                            <div class="timeline-content">
                                <p><?php echo htmlspecialchars($activity['activity']); ?></p>
                                <span class="timeline-time"><?php echo date('d M Y, h:i A', strtotime($activity['created_at'])); ?></span>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="no-data">No recent activities</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js for analytics -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Branch Statistics Chart
        const ctx = document.getElementById('branchChart').getContext('2d');
        
        <?php
        $branches = [];
        $totals = [];
        $placed = [];
        if ($branch_stats && $branch_stats->num_rows > 0) {
            while($stat = $branch_stats->fetch_assoc()) {
                $branches[] = $stat['branch'] ?? 'Unknown';
                $totals[] = $stat['total'] ?? 0;
                $placed[] = $stat['placed'] ?? 0;
            }
        } else {
            $branches = ['No Data'];
            $totals = [0];
            $placed = [0];
        }
        ?>
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($branches); ?>,
                datasets: [{
                    label: 'Total Students',
                    data: <?php echo json_encode($totals); ?>,
                    backgroundColor: 'rgba(30, 60, 114, 0.5)',
                    borderColor: '#1e3c72',
                    borderWidth: 1
                }, {
                    label: 'Placed Students',
                    data: <?php echo json_encode($placed); ?>,
                    backgroundColor: 'rgba(16, 185, 129, 0.5)',
                    borderColor: '#10b981',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>