<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get statistics
$total_applications = $conn->query("SELECT COUNT(*) as c FROM applications")->fetch_assoc()['c'] ?? 0;
$pending_applications = $conn->query("SELECT COUNT(*) as c FROM applications WHERE status='pending'")->fetch_assoc()['c'] ?? 0;
$shortlisted = $conn->query("SELECT COUNT(*) as c FROM applications WHERE status='shortlisted'")->fetch_assoc()['c'] ?? 0;
$selected = $conn->query("SELECT COUNT(*) as c FROM applications WHERE status='selected'")->fetch_assoc()['c'] ?? 0;

// Get applications list
$applications = $conn->query("
    SELECT a.*, 
           s.full_name as student_name, s.enrollment_no, s.branch, s.semester,
           c.company_name,
           pd.title as drive_title, pd.deadline
    FROM applications a
    JOIN students s ON a.student_id = s.id
    JOIN placement_drives pd ON a.drive_id = pd.id
    JOIN companies c ON pd.company_id = c.company_id
    ORDER BY a.applied_date DESC
");

// Get status counts for chart
$status_stats = $conn->query("
    SELECT status, COUNT(*) as count 
    FROM applications 
    GROUP BY status
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Applications Management | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Additional styles for applications page */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .filter-select {
            padding: 10px 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #475569;
            background: white;
            cursor: pointer;
        }
        
        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .student-name {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .student-detail {
            font-size: 12px;
            color: #64748b;
        }
        
        .company-badge {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .drive-title {
            font-weight: 500;
            color: #2c3e50;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-badge.pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-badge.shortlisted {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-badge.selected {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-badge.rejected {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            transition: all 0.3s;
        }
        
        .view-btn {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .update-btn {
            background: #fef3c7;
            color: #92400e;
        }
        
        .date-badge {
            font-size: 12px;
            color: #64748b;
        }
        
        /* Mini stats cards */
        .stats-mini-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 25px;
        }
        
        .page-link {
            padding: 8px 14px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            transition: all 0.3s;
        }
        
        .page-link.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        }
        
        @media (max-width: 768px) {
            .stats-mini-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar (same as dashboard) -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
            <div class="version-badge">v2.0</div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="../dashboard.php">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="../students/">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students ?? 0; ?></div>
            </a>
            <a href="../companies/">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies ?? 0; ?></div>
            </a>
            <a href="../drives/">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $total_drives ?? 0; ?></div>
            </a>
            <a href="index.php" class="active">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="../reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="../settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="../help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="../profile.php">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="../logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Applications Management</h1>
                    <p>Track and manage student applications</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search applications..." id="searchInput">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Statistics Mini Cards -->
            <div class="stats-mini-grid">
                <div class="mini-stat">
                    <div class="mini-stat-icon" style="background: #e8f0fe; color: #1e3c72;">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="mini-stat-content">
                        <span class="mini-stat-label">Total</span>
                        <span class="mini-stat-value"><?php echo $total_applications; ?></span>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-icon" style="background: #fef3c7; color: #92400e;">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="mini-stat-content">
                        <span class="mini-stat-label">Pending</span>
                        <span class="mini-stat-value"><?php echo $pending_applications; ?></span>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-icon" style="background: #dbeafe; color: #1e40af;">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="mini-stat-content">
                        <span class="mini-stat-label">Shortlisted</span>
                        <span class="mini-stat-value"><?php echo $shortlisted; ?></span>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-icon" style="background: #d1fae5; color: #065f46;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="mini-stat-content">
                        <span class="mini-stat-label">Selected</span>
                        <span class="mini-stat-value"><?php echo $selected; ?></span>
                    </div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <select class="filter-select" id="statusFilter">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="selected">Selected</option>
                    <option value="rejected">Rejected</option>
                </select>
                <select class="filter-select" id="branchFilter">
                    <option value="">All Branches</option>
                    <?php
                    $branches = $conn->query("SELECT DISTINCT branch FROM students WHERE branch IS NOT NULL");
                    while($branch = $branches->fetch_assoc()):
                    ?>
                        <option value="<?php echo $branch['branch']; ?>"><?php echo $branch['branch']; ?></option>
                    <?php endwhile; ?>
                </select>
                <select class="filter-select" id="dateFilter">
                    <option value="">Sort by Date</option>
                    <option value="newest">Newest First</option>
                    <option value="oldest">Oldest First</option>
                </select>
            </div>

            <!-- Applications Table -->
            <div class="table-card">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Company & Drive</th>
                                <th>Applied Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($applications && $applications->num_rows > 0): ?>
                                <?php while($app = $applications->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-avatar">
                                                <?php echo strtoupper(substr($app['student_name'] ?? 'S', 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="student-name"><?php echo htmlspecialchars($app['student_name']); ?></div>
                                                <div class="student-detail">
                                                    <?php echo $app['enrollment_no']; ?> • <?php echo $app['branch']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="company-badge"><?php echo htmlspecialchars($app['company_name']); ?></div>
                                        <div class="drive-title"><?php echo htmlspecialchars($app['drive_title']); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo date('d M Y', strtotime($app['applied_date'])); ?></div>
                                        <div class="date-badge"><?php echo date('h:i A', strtotime($app['applied_date'])); ?></div>
                                    </td>
                                    <td>
                                        <?php
                                        $status = $app['status'] ?? 'pending';
                                        $statusClass = $status;
                                        ?>
                                        <span class="status-badge <?php echo $statusClass; ?>">
                                            <?php echo ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view.php?id=<?php echo $app['id']; ?>" class="action-btn view-btn">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <a href="update.php?id=<?php echo $app['id']; ?>" class="action-btn update-btn">
                                                <i class="fas fa-edit"></i> Update
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="no-data">No applications found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="pagination">
                    <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                    <a href="#" class="page-link active">1</a>
                    <a href="#" class="page-link">2</a>
                    <a href="#" class="page-link">3</a>
                    <a href="#" class="page-link">4</a>
                    <a href="#" class="page-link">5</a>
                    <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Filter functionality
        document.getElementById('statusFilter').addEventListener('change', filterTable);
        document.getElementById('branchFilter').addEventListener('change', filterTable);

        function filterTable() {
            let statusFilter = document.getElementById('statusFilter').value.toLowerCase();
            let branchFilter = document.getElementById('branchFilter').value;
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let status = row.cells[3]?.textContent.toLowerCase().trim() || '';
                let branch = row.cells[0]?.textContent || '';
                let show = true;
                
                if (statusFilter && !status.includes(statusFilter)) show = false;
                if (branchFilter && !branch.includes(branchFilter)) show = false;
                
                row.style.display = show ? '' : 'none';
            });
        }

        // Date sorting
        document.getElementById('dateFilter').addEventListener('change', function() {
            let sortOrder = this.value;
            if (!sortOrder) return;
            
            let tbody = document.querySelector('tbody');
            let rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {
                let dateA = new Date(a.cells[2]?.textContent.trim());
                let dateB = new Date(b.cells[2]?.textContent.trim());
                
                return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
            });
            
            rows.forEach(row => tbody.appendChild(row));
        });
    </script>
</body>
</html>