<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{
            margin:0;
            background:#efefef;
            font-family: "Segoe UI", Tahoma, Arial, sans-serif;
            color:#333;
        }
        .page{
            padding:40px 60px;
        }
        h1{
            font-size:22px;
            font-weight:600;
            margin-bottom:20px;
        }
        p{
            font-size:14px;
            line-height:1.6;
            margin:8px 0;
        }
        ul{
            margin-top:8px;
            padding-left:18px;
        }
        li{
            margin:6px 0;
            font-size:14px;
        }
        .section-title{
            font-weight:600;
            margin-top:22px;
        }
        a{
            color:#0066cc;
            text-decoration:none;
        }
        a:hover{
            text-decoration:underline;
        }
    </style>
</head>
<body>
    <div class="page">
        <h1>Page Not Found</h1>

        <ul>
            <li>This page may have moved or is no longer available.</li>
        </ul>

        <p class="section-title">Please try one of the following:</p>

        <p>Check the web address you entered to make sure it is correct</p>

        <p>
            Try to access the page directly from the 
            <a href="#">Home</a> page instead of using a bookmark.
            If the page has moved, reset your bookmark
        </p>

        <p>
            If you are searching for a Help page, click the back button on your web browser
            and select another Help page
        </p>
    </div>
</body>
</html>