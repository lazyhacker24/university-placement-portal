<?php
session_start();
require '../../config/db.php';

if(!isset($_SESSION['admin_id'])) exit("Unauthorized");

$id = (int)$_GET['id'];

$res = $conn->query("SELECT company_uid, doc_file FROM companies WHERE id=$id");
$c = $res->fetch_assoc();

$path = "../../assets/company_docs/".$c['company_uid']."/".$c['doc_file'];

if(!$c['doc_file']) die("No documents uploaded");
?>

<h2>Uploaded Documents</h2>
<a href="<?= $path ?>" download>Download ZIP</a>