<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
require_once '../../config/db.php';

// Get statistics
$total_companies = $conn->query("SELECT COUNT(*) as c FROM companies")->fetch_assoc()['c'] ?? 0;
$active_companies = $conn->query("SELECT COUNT(company_id) as c FROM placement_drives WHERE drive_status='active'")->fetch_assoc()['c'] ?? 0;
$total_drives = $conn->query("SELECT COUNT(*) as c FROM placement_drives")->fetch_assoc()['c'] ?? 0;

// Get companies list
$companies = $conn->query("
    SELECT c.*, 
           COUNT(DISTINCT pd.id) as drives,
           COUNT(DISTINCT a.id) as applications
    FROM companies c
    LEFT JOIN placement_drives pd ON c.id = pd.company_id
    LEFT JOIN applications a ON pd.id = a.drive_id
    GROUP BY c.id
    ORDER BY c.created_at DESC
");

// Get industries for filter
$industries = $conn->query("SELECT DISTINCT industry FROM companies WHERE industry IS NOT NULL");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Companies Management | GLA University</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Additional styles for companies page */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .add-btn {
            background: #1e3c72;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .add-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .filter-select {
            padding: 10px 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #475569;
            background: white;
            cursor: pointer;
        }
        
        .company-logo {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
        }
        
        .company-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .company-name {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .company-email {
            font-size: 12px;
            color: #64748b;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge.active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-badge.inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            transition: all 0.3s;
        }
        
        .edit-btn {
            background: #fef3c7;
            color: #92400e;
        }
        
        .view-btn {
            background: #e0f2fe;
            color: #0369a1;
        }
        
        .delete-btn {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        .drives-count {
            font-weight: 600;
            color: #1e3c72;
        }
        
        .applications-count {
            font-weight: 600;
            color: #10b981;
        }
        
        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 25px;
        }
        
        .page-link {
            padding: 8px 14px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            transition: all 0.3s;
        }
        
        .page-link.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        
        }

    .status-badge.pending { background:#fef3c7; color:#92400e; }
    .status-badge.email_not_verified { background:#e0e7ff; color:#3730a3; }
    .status-badge.docs_requested { background:#fde68a; color:#92400e; }
    .status-badge.docs_submitted { background:#dbeafe; color:#1e40af; }
    .status-badge.approved { background:#d1fae5; color:#065f46; }
    .status-badge.rejected { background:#fee2e2; color:#991b1b; }

    </style>
</head>
<body>
    <!-- Sidebar (same as dashboard) -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="shield-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">
                    <span class="gla">GLA</span>
                    <span class="admin">ADMIN</span>
                </div>
            </div>
            <div class="version-badge">v2.0</div>
        </div>

        <div class="admin-profile">
            <div class="profile-image">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="profile-info">
                <h4><?php echo $_SESSION['admin_name'] ?? 'Admin User'; ?></h4>
                <p>Administrator</p>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <a href="../dashboard.php">
                <div class="menu-icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
                <div class="menu-badge">9+</div>
            </a>
            <a href="../students/">
                <div class="menu-icon"><i class="fas fa-user-graduate"></i></div>
                <span>Students</span>
                <div class="menu-badge"><?php echo $total_students ?? 0; ?></div>
            </a>
            <a href="index.php" class="active">
                <div class="menu-icon"><i class="fas fa-building"></i></div>
                <span>Companies</span>
                <div class="menu-badge"><?php echo $total_companies; ?></div>
            </a>
            <a href="../drives/">
                <div class="menu-icon"><i class="fas fa-briefcase"></i></div>
                <span>Placement Drives</span>
                <div class="menu-badge"><?php echo $total_drives; ?></div>
            </a>
            <a href="../applications/">
                <div class="menu-icon"><i class="fas fa-file-signature"></i></div>
                <span>Applications</span>
                <div class="menu-badge"><?php echo $total_applications ?? 0; ?></div>
            </a>

            <div class="menu-title">MANAGEMENT</div>
            <a href="../reports/">
                <div class="menu-icon"><i class="fas fa-chart-pie"></i></div>
                <span>Reports</span>
            </a>
            <a href="../settings/">
                <div class="menu-icon"><i class="fas fa-cog"></i></div>
                <span>Settings</span>
            </a>
            <a href="../help/">
                <div class="menu-icon"><i class="fas fa-question-circle"></i></div>
                <span>Help & Support</span>
            </a>

            <div class="menu-title">ACCOUNT</div>
            <a href="../profile.php">
                <div class="menu-icon"><i class="fas fa-user-circle"></i></div>
                <span>My Profile</span>
            </a>
            <a href="../logout.php" class="logout">
                <div class="menu-icon"><i class="fas fa-sign-out-alt"></i></div>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="storage-info">
                <i class="fas fa-database"></i>
                <div class="storage-details">
                    <span>Database Usage</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: 45%"></div>
                    </div>
                    <small>45% Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Companies Management</h1>
                    <p>Manage partner companies and their placement drives</p>
                </div>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search companies..." id="searchInput">
                </div>
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                <div class="header-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d M Y'); ?>
                </div>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="dashboard-container">
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Companies</span>
                        <h3 class="stat-number"><?php echo $total_companies; ?></h3>
                    </div>
                </div>

                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Active Drives</span>
                        <h3 class="stat-number"><?php echo $active_companies; ?></h3>
                    </div>
                </div>

                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Total Drives</span>
                        <h3 class="stat-number"><?php echo $total_drives; ?></h3>
                    </div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <span class="stat-label">Active Partners</span>
                        <h3 class="stat-number"><?php echo $active_companies; ?></h3>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="filter-section">
                    <select class="filter-select" id="industryFilter">
                        <option value="">All Industries</option>
                        <?php while($industry = $industries->fetch_assoc()): ?>
                            <option value="<?php echo $industry['industry']; ?>"><?php echo $industry['industry']; ?></option>
                        <?php endwhile; ?>
                    </select>
                    <select class="filter-select" id="statusFilter">
                        <option value="">All Status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                <a href="add.php" class="add-btn">
                    <i class="fas fa-plus"></i> Add New Company
                </a>
            </div>

            <!-- Companies Table -->
            <div class="table-card">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Company</th>
                                <th>Industry</th>
                                <th>Location</th>
                                <th style="min-width:120px">Contact</th>
                                <th>Drives</th>
                                <th>Applications</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($companies && $companies->num_rows > 0): ?>
                                <?php while($company = $companies->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="company-info">
                                            <div class="company-logo">
                                                <i class="fas fa-building"></i>
                                            </div>
                                            <div>
                                                <div class="company-name"><?php echo htmlspecialchars($company['company_name'] ?? 'N/A'); ?></div>
                                                <div class="company-email"><?php echo htmlspecialchars($company['email'] ?? 'N/A'); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($company['industry'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($company['location'] ?? 'N/A'); ?></td>
                                    <td>
    <?php if(!empty($company['hr_name'])): ?>
        <div><?php echo htmlspecialchars($company['hr_name']); ?></div>
    <?php endif; ?>

    <?php if(!empty($company['phone'])): ?>
        <small><?php echo htmlspecialchars($company['phone']); ?></small>
    <?php else: ?>
        <small>N/A</small>
    <?php endif; ?>
</td>
                                    <td><span class="drives-count"><?php echo $company['drives'] ?? 0; ?></span></td>
                                    <td><span class="applications-count"><?php echo $company['applications'] ?? 0; ?></span></td>
                                    <td>
                                        <?php
                                        $status = !empty($company['status']) ? $company['status'] : 'pending_verification';
                                        $statusClass = $status;
                                        $statusText = ucwords(str_replace('_',' ',$status));
                                        ?>
                                        <span class="status-badge <?php echo $statusClass; ?>">
                                                 <?php echo $statusText; ?>
                                                </span>
                                    </td>
                                    <td>
<div class="action-menu">
    <button class="menu-btn" onclick="toggleMenu(this)">
        <i class="fas fa-ellipsis-v"></i>
    </button>

    <div class="menu-dropdown">
        <a href="view.php?id=<?php echo $company['id']; ?>">
            <i class="fas fa-eye"></i> View
        </a>

        <?php if($status=='pending_verification'): ?>
            <a href="actions/approve.php?id=<?php echo $company['id']; ?>" class="success">
                <i class="fas fa-check"></i> Approve
            </a>
            <a href="actions/request_docs.php?id=<?php echo $company['id']; ?>" class="warning">
                <i class="fas fa-file-alt"></i> Ask Documents
            </a>
            <a href="actions/reject.php?id=<?php echo $company['id']; ?>" class="danger">
                <i class="fas fa-times"></i> Reject
            </a>
        <?php elseif($status=='docs_submitted'): ?>
            <a href="actions/approve.php?id=<?php echo $company['id']; ?>" class="success">
                <i class="fas fa-check"></i> Approve
            </a>
            <a href="actions/reject.php?id=<?php echo $company['id']; ?>" class="danger">
                <i class="fas fa-times"></i> Reject
            </a>
        <?php endif; ?>
    </div>
</div>
</td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="no-data">No companies found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="pagination">
                    <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                    <a href="#" class="page-link active">1</a>
                    <a href="#" class="page-link">2</a>
                    <a href="#" class="page-link">3</a>
                    <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Filter functionality
        document.getElementById('industryFilter').addEventListener('change', filterTable);
        document.getElementById('statusFilter').addEventListener('change', filterTable);

        function filterTable() {
            let industryFilter = document.getElementById('industryFilter').value;
            let statusFilter = document.getElementById('statusFilter').value;
            let rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let industry = row.cells[1]?.textContent || '';
                let status = row.cells[6]?.textContent || '';
                let show = true;
                
                if (industryFilter && !industry.includes(industryFilter)) show = false;
                if (statusFilter && !status.includes(statusFilter)) show = false;
                
                row.style.display = show ? '' : 'none';
            });
        }

 function toggleMenu(btn){
    document.querySelectorAll('.menu-dropdown').forEach(m=>m.style.display='none');
    btn.nextElementSibling.style.display='block';
}
window.onclick=function(e){
    if(!e.target.closest('.action-menu')){
        document.querySelectorAll('.menu-dropdown').forEach(m=>m.style.display='none');
    }
}
    </script>
</body>
</html>