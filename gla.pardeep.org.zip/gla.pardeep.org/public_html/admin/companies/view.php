<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require '../_core.php';


/* ================= ADMIN LOGIN CHECK ================= */
if(!isset($_SESSION['admin_id'])){
    header("Location: ../login.php");
    exit;
}

/* ================= VALIDATE COMPANY ID ================= */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id <= 0){
    header("Location: index.php");
    exit;
}

/* ================= FETCH COMPANY DATA ================= */
$stmt = $conn->prepare("
SELECT c.*,
COUNT(DISTINCT pd.id) AS total_jobs,
COUNT(DISTINCT a.id) AS total_applications
FROM companies c
LEFT JOIN placement_drives pd ON pd.company_id = c.id
LEFT JOIN applications a ON a.drive_id = pd.id
WHERE c.id = ?
GROUP BY c.id
LIMIT 1
");
$stmt->bind_param("i",$id);
$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows == 0){
    die("Company not found");
}

$company = $res->fetch_assoc();

/* ================= FETCH COMPANY HISTORY ================= */
$historyStmt = $conn->prepare("
SELECT * FROM company_history 
WHERE company_id = ? 
ORDER BY created_at DESC 
LIMIT 50
");
$historyStmt->bind_param("i",$id);
$historyStmt->execute();
$history = $historyStmt->get_result();

/* ================= FETCH EMAIL LOGS ================= */
$emailStmt = $conn->prepare("
SELECT * FROM email_logs 
WHERE user_email = ? 
ORDER BY sent_at DESC 
LIMIT 20
");
$emailStmt->bind_param("s", $company['email']);
$emailStmt->execute();
$emailLogs = $emailStmt->get_result();

/* ================= FETCH DOCUMENT REQUESTS ================= */
$docStmt = $conn->prepare("
SELECT * FROM company_documents 
WHERE company_id = ? 
ORDER BY submitted_at DESC
");
$docStmt->bind_param("i",$id);
$docStmt->execute();
$docRequests = $docStmt->get_result();

/* ================= ACTIVE JOBS ================= */
$stmt2 = $conn->prepare("SELECT COUNT(*) c FROM placement_drives WHERE company_id=? AND drive_status='active'");
$stmt2->bind_param("i",$id);
$stmt2->execute();
$active = $stmt2->get_result()->fetch_assoc()['c'] ?? 0;


$status = strtolower(trim($company['status'] ?? 'pending'));
$company['status'] = $status; // sync everywhere

/* Map old statuses to new workflow */

$statusClass = [
    'pending' => 'status-badge status-pending',
    'docs_requested' => 'status-badge status-warning',
    'docs_submitted' => 'status-badge status-info',
    'officer_approved' => 'status-badge status-success',
    'rejected' => 'status-badge status-rejected',
    'active' => 'status-badge status-success',
    'suspended' => 'status-badge status-warning',
    'blocked' => 'status-badge status-rejected',
];

$statusText = strtoupper(str_replace('_',' ',$status));
$badgeClass = $statusClass[$status] ?? 'status-badge status-pending';

/* ================= NEXT STEP HELPER ================= */
$nextStep = [
    'pending' => '⏳ Waiting for company email verification',
    'docs_requested' => '⏳ Waiting for company to upload documents',
    'docs_submitted' => '🔍 Admin should review uploaded documents',
    'officer_approved' => '⏳ Final admin approval pending',
    'rejected' => '❌ Application rejected',
    'active' => '🟢 Company is LIVE and visible to students',
    'suspended' => '⏸ Company temporarily suspended',
    'blocked' => '🚫 Company blocked by admin',
];

/* ================= DOCUMENT TYPES ================= */
$documentTypes = [
    'hr_id_proof' => 'HR ID Proof (Aadhar/PAN/Passport)',
    'company_registration' => 'Company Registration Certificate',
    'gst_certificate' => 'GST Certificate',
    'university_agreement' => 'University Agreement Form',
    'incorpation_certificate' => 'Incorporation Certificate',
    'tax_document' => 'Tax Document (ITR/TDS)'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Details | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 30px 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Top Bar */
        .top-bar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }

        .back-link {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #4a5568;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 8px 16px;
            border-radius: 12px;
            background: rgba(102, 126, 234, 0.1);
        }

        .back-link:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: translateX(-5px);
        }

        .admin-badge {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 8px 20px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Company Header */
        .company-header {
            background: white;
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .company-info h2 {
            font-size: 32px;
            color: #1e293b;
            margin-bottom: 15px;
        }

        .company-meta {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }

        .next-step-info {
            margin-top: 15px;
            padding: 15px 20px;
            background: #f8fafc;
            border-radius: 16px;
            color: #475569;
            font-size: 15px;
        }

        /* 3-Dot Menu */
        .menu-container {
            position: relative;
        }

        .menu-trigger {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            padding: 10px;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            color: #64748b;
        }

        .menu-trigger:hover {
            background: #f1f5f9;
            color: #1e293b;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            min-width: 280px;
            z-index: 1000;
            display: none;
            overflow: hidden;
        }

        .dropdown-menu.show {
            display: block;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #1e293b;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            font-size: 14px;
        }

        .menu-item:hover {
            background: linear-gradient(135deg, #667eea10, #764ba210);
        }

        .menu-item i {
            width: 20px;
            color: #667eea;
        }

        .menu-item.danger {
            color: #dc2626;
        }

        .menu-item.danger i {
            color: #dc2626;
        }

        .menu-divider {
            height: 1px;
            background: #e2e8f0;
            margin: 8px 0;
        }

        /* Status Badges */
        .status-badge {
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
            display: inline-block;
        }

        .status-pending { background: #94a3b8; color: white; }
        .status-warning { background: #f59e0b; color: white; }
        .status-info { background: #3b82f6; color: white; }
        .status-success { background: #10b981; color: white; }
        .status-approved { background: #059669; color: white; }
        .status-rejected { background: #dc2626; color: white; }

        /* Cards */
        .card {
            background: white;
            border-radius: 24px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 20px;
            color: #1e293b;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
        }

        .card-title i {
            color: #667eea;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .info-item {
            background: #f8fafc;
            padding: 20px;
            border-radius: 16px;
        }

        .info-label {
            color: #64748b;
            font-size: 13px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 25px;
            border-radius: 16px;
            text-align: center;
        }

        .stat-number {
            font-size: 36px;
            font-weight: 700;
            margin: 10px 0;
        }

        /* Timeline */
        .timeline {
            position: relative;
            padding: 20px 0;
        }

        .timeline-item {
            padding: 20px 0 20px 40px;
            border-left: 2px solid #e2e8f0;
            position: relative;
            margin-left: 20px;
        }

        .timeline-item::before {
            content: '';
            width: 12px;
            height: 12px;
            background: #667eea;
            border-radius: 50%;
            position: absolute;
            left: -7px;
            top: 24px;
        }

        .timeline-date {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 5px;
        }

        .timeline-title {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 5px;
        }

        .timeline-details {
            color: #475569;
            font-size: 14px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 24px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #64748b;
        }

        /* Document Checkboxes */
        .doc-checkbox {
            display: block;
            margin: 15px 0;
            padding: 15px;
            background: #f8fafc;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .doc-checkbox:hover {
            background: #f1f5f9;
        }

        .doc-checkbox input {
            margin-right: 15px;
        }

        /* Buttons */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-danger {
            background: #dc2626;
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .company-header {
                flex-direction: column;
                gap: 20px;
            }
            
            .menu-container {
                align-self: flex-end;
            }
        }
    </style>
</head>
<body>

<div class="container">

    <!-- Top Bar -->
    <div class="top-bar">
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            <span>Back to Companies</span>
        </a>
        <div class="admin-badge">
            <i class="fas fa-shield-alt"></i>
            <span>Admin Panel</span>
        </div>
    </div>

    <!-- Company Header with 3-Dot Menu -->
    <div class="company-header">
        <div class="company-info">
            <h2><i class="fas fa-building" style="color: #667eea; margin-right: 10px;"></i><?= e($company['company_name']) ?></h2>
            <div class="company-meta">

<?php
$iconMap = [
    'pending' => 'clock',
    'docs_requested' => 'file-circle-question',
    'docs_submitted' => 'file-circle-check',
    'officer_approved' => 'user-check',
    'active' => 'circle-check',
    'suspended' => 'pause-circle',
    'blocked' => 'ban',
    'rejected' => 'circle-xmark'
];
$icon = $iconMap[$status] ?? 'clock';
?>

<span class="<?= $badgeClass ?>" style="display:inline-flex;align-items:center;gap:8px;">
    <i class="fas fa-<?= $icon ?>"></i>
    <?= $statusText ?>
</span>

<?php if($status == 'docs_submitted'): ?>
    <a href="documents.php?id=<?= $id ?>" 
       style="padding:8px 14px;border-radius:20px;
              background:#e0f2fe;color:#0369a1;font-size:13px;
              font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:6px;">
        <i class="fas fa-eye"></i> View Documents
    </a>
<?php endif; ?>

<span class="company-uid" style="background:#f1f5f9;padding:8px 15px;border-radius:30px;">
    <i class="fas fa-fingerprint" style="color:#667eea;"></i>
    <?= e($company['company_uid']) ?: 'UID Not Assigned' ?>
</span>

</div>
            <div class="next-step-info">
                <i class="fas fa-info-circle" style="color: #667eea;"></i>
                <?= $nextStep[$status] ?? '—' ?>
            </div>
        </div>
        
        <!-- 3-Dot Menu -->
        <div class="menu-container">
            <button class="menu-trigger" onclick="toggleMenu()">
                <i class="fas fa-ellipsis-vertical"></i>
            </button>
           
    <div class="dropdown-menu" id="actionMenu">

        <?php if($status == 'email_pending'): ?>
            <button class="menu-item" onclick="goAction('resend_verification')">
                <i class="fas fa-envelope"></i> Resend Verification Email
            </button>
        <?php endif; ?>

        <?php if($status == 'email_verified'): ?>
            <button class="menu-item" onclick="showDocRequestModal()">
                <i class="fas fa-file-alt"></i> Request Documents
            </button>
        <?php endif; ?>

        <?php if($status == 'docs_requested'): ?>
            <button class="menu-item" onclick="goAction('resend_docs')">
                <i class="fas fa-redo"></i> Resend Document Request
            </button>
        <?php endif; ?>

       <?php if($company['status'] == 'docs_submitted'): ?>

    <button class="menu-item" onclick="window.location.href='documents.php?id=<?= $id ?>'">
        <i class="fas fa-eye"></i> View Uploaded Documents
    </button>

    <button class="menu-item" onclick="showDocRequestModal()">
        <i class="fas fa-plus-circle"></i> Request Additional Documents
    </button>

    <button class="menu-item" onclick="goAction('approve_docs')">
        <i class="fas fa-check-circle"></i> Approve Documents
    </button>

    <button class="menu-item danger" onclick="showRejectModal()">
        <i class="fas fa-times-circle"></i> Reject Documents
    </button>
<?php endif; ?>

    <?php if($company['status'] == 'officer_approved'): ?>
    <button class="menu-item" onclick="goAction('final_approve')">
        <i class="fas fa-award"></i> Final Approve Company
    </button>
<?php endif; ?>

        <?php if($company['status'] == 'active'): ?>

    <button class="menu-item" onclick="goAction('suspend_company')">
        <i class="fas fa-pause-circle"></i> Suspend Company
    </button>

    <button class="menu-item danger" onclick="goAction('block_company')">
        <i class="fas fa-ban"></i> Block Company
    </button>

<?php endif; ?>

        <div class="menu-divider"></div>

        <?php if($company['status'] == 'blocked'): ?>

    <button class="menu-item" onclick="goAction('activate_company')">
        <i class="fas fa-check-circle"></i> Activate Company
    </button>

    <button class="menu-item danger" onclick="goAction('delete_company')">
        <i class="fas fa-trash"></i> Delete Company
    </button>

<?php endif; ?>

        <?php if($company['status'] == 'suspended'): ?>

    <button class="menu-item" onclick="goAction('activate_company')">
        <i class="fas fa-check-circle"></i> Activate Company
    </button>

    <button class="menu-item danger" onclick="goAction('block_company')">
        <i class="fas fa-ban"></i> Block Company
    </button>

<?php endif; ?>

        <button class="menu-item" onclick="window.location.href='edit.php?id=<?= $id ?>'">
            <i class="fas fa-edit"></i> Edit Company Details
        </button>

        <button class="menu-item" onclick="window.location.href='jobs.php?company_id=<?= $id ?>'">
            <i class="fas fa-briefcase"></i> View Job Posts
        </button>

        <button class="menu-item" onclick="window.location.href='applications.php?company_id=<?= $id ?>'">
            <i class="fas fa-users"></i> View Applications
        </button>

        <?php if(in_array($company['status'], ['pending','docs_requested','docs_submitted'])): ?>
            <div class="menu-divider"></div>
            <button class="menu-item danger" onclick="showRejectModal()">
                <i class="fas fa-ban"></i> Reject Application
            </button>
        <?php endif; ?>

    </div>
</div>
</div>
    <!-- Company Information Card -->
    <div class="card">
        <h3 class="card-title">
            <i class="fas fa-info-circle"></i>
            Company Information
        </h3>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label"><i class="fas fa-industry"></i> Industry</div>
                <div class="info-value"><?= e($company['industry']) ?: 'Not specified' ?></div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-user-tie"></i> HR Name</div>
                <div class="info-value"><?= e($company['hr_name']) ?: 'Not provided' ?></div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-envelope"></i> Email</div>
                <div class="info-value">
                    <a href="mailto:<?= e($company['email']) ?>" style="color: #667eea;">
                        <?= e($company['email']) ?>
                    </a>
                </div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-phone"></i> Phone</div>
                <div class="info-value">
                    <a href="tel:<?= e($company['phone']) ?>" style="color: #667eea;">
                        <?= e($company['phone']) ?: 'Not provided' ?>
                    </a>
                </div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-calendar-plus"></i> Registered On</div>
                <div class="info-value"><?= date('d M Y, h:i A', strtotime($company['created_at'])) ?></div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-history"></i> Last Updated</div>
                <div class="info-value">
<?= !empty($company['approved_at']) 
    ? date('d M Y, h:i A', strtotime($company['approved_at'])) 
    : 'Never' ?>
</div>
            </div>
        </div>
    </div>

    <!-- Statistics Card -->
    <div class="card">
        <h3 class="card-title">
            <i class="fas fa-chart-bar"></i>
            Statistics
        </h3>
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-briefcase fa-2x"></i>
                <div class="stat-number"><?= $company['total_jobs'] ?></div>
                <div>Total Jobs</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-play-circle fa-2x"></i>
                <div class="stat-number"><?= $active ?></div>
                <div>Active Jobs</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-users fa-2x"></i>
                <div class="stat-number"><?= $company['total_applications'] ?></div>
                <div>Applications</div>
            </div>
        </div>
    </div>

    <!-- Recent History Timeline -->
    <div class="card">
        <h3 class="card-title">
            <i class="fas fa-history"></i>
            Recent Activity
        </h3>
        <div class="timeline">
            <?php 
            $count = 0;
            while($log = $history->fetch_assoc()): 
                if($count++ >= 10) break;
            ?>
            <div class="timeline-item">
                <div class="timeline-date">
                    <i class="far fa-clock"></i>
                    <?= date('d M Y, h:i A', strtotime($log['created_at'])) ?>
                </div>
                <div class="timeline-title">
                    <?= ucfirst(str_replace('_', ' ', $log['action_type'])) ?>
                </div>
                <div class="timeline-details">
                    <?= e($log['details']) ?> 
                    <span style="color: #94a3b8;">by <?= e($log['action_by']) ?></span>
                </div>
            </div>
            <?php endwhile; ?>
            <?php if($count == 0): ?>
                <div style="text-align: center; padding: 40px; color: #94a3b8;">
                    <i class="fas fa-history fa-3x"></i>
                    <p style="margin-top: 15px;">No activity recorded yet</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Email Logs -->
    <div class="card">
        <h3 class="card-title">
            <i class="fas fa-envelope"></i>
            Email Communications
        </h3>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8fafc;">
                        <th style="padding: 15px; text-align: left;">Date</th>
                        <th style="padding: 15px; text-align: left;">Type</th>
                        <th style="padding: 15px; text-align: left;">Subject</th>
                        <th style="padding: 15px; text-align: left;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($email = $emailLogs->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 15px;"><?= date('d M Y, h:i A', strtotime($email['sent_at'])) ?></td>
                        <td style="padding: 12px 15px;"><?= ucfirst(str_replace('_', ' ', $email['email_type'])) ?></td>
                        <td style="padding: 12px 15px;"><?= e($email['subject']) ?></td>
                        <td style="padding: 12px 15px;">
                            <span style="color: <?= $email['status'] == 'sent' ? '#10b981' : '#ef4444' ?>">
                                <i class="fas fa-<?= $email['status'] == 'sent' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                                <?= ucfirst($email['status']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Document Request Modal -->
<div class="modal" id="docRequestModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-file-alt" style="color: #667eea;"></i> Request Documents</h3>
            <button class="close-modal" onclick="closeModal('docRequestModal')">&times;</button>
        </div>
        <form action="actions/request_documents.php" method="POST">
            <input type="hidden" name="company_id" value="<?= $id ?>">
            
            <p style="margin-bottom: 20px; color: #475569;">Select documents to request from company:</p>
            
            <?php foreach($documentTypes as $key => $label): ?>
            <label class="doc-checkbox">
                <input type="checkbox" name="documents[]" value="<?= $key ?>">
                <span><?= $label ?></span>
            </label>
            <?php endforeach; ?>
            
            <div style="margin-top: 25px; display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 2;">
                    <i class="fas fa-paper-plane"></i> Send Request
                </button>
                <button type="button" class="btn" style="flex: 1; background: #f1f5f9;" onclick="closeModal('docRequestModal')">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal" id="rejectModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-exclamation-triangle" style="color: #dc2626;"></i> Reject Company</h3>
            <button class="close-modal" onclick="closeModal('rejectModal')">&times;</button>
        </div>
        <form action="actions/reject.php" method="POST">
            <input type="hidden" name="company_id" value="<?= $id ?>">
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 10px; font-weight: 600;">Rejection Reason:</label>
                <select name="rejection_reason" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <option value="incomplete_documents">Incomplete Documents</option>
                    <option value="invalid_documents">Invalid Documents</option>
                    <option value="not_eligible">Not Eligible as per University Policy</option>
                    <option value="other">Other (specify below)</option>
                </select>
            </div>
            
            <div style="margin-bottom: 20px;">
                <textarea name="custom_reason" placeholder="Additional comments..." 
                          style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; min-height: 100px;"></textarea>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-danger" style="flex: 2;">
                    <i class="fas fa-ban"></i> Reject Company
                </button>
                <button type="button" class="btn" style="flex: 1; background: #f1f5f9;" onclick="closeModal('rejectModal')">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Toggle 3-dot menu
    function goAction(action){
    let msg = {
    'resend_verification': 'Resend verification email?',
    'resend_docs': 'Resend document request?',
    'approve_docs': 'Approve uploaded documents?',
    'final_approve': 'Final approve this company?',
    'suspend_company': 'Suspend this company?',
    'block_company': 'Block this company?',
    'activate_company': 'Activate this company?',
    'delete_company': 'Permanently delete this company?'
};

    if(confirm(msg[action])){
        window.location.href = 'actions/' + action + '.php?id=<?= $id ?>';
    }
}
    function toggleMenu() {
        document.getElementById('actionMenu').classList.toggle('show');
    }

    // Close menu when clicking outside
    window.onclick = function(event) {
        if (!event.target.matches('.menu-trigger') && !event.target.matches('.menu-trigger *')) {
            var dropdowns = document.getElementsByClassName("dropdown-menu");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }

    // Modal functions
    function showDocRequestModal() {
        document.getElementById('docRequestModal').classList.add('show');
        document.getElementById('actionMenu').classList.remove('show');
    }

    function showRejectModal() {
        document.getElementById('rejectModal').classList.add('show');
        document.getElementById('actionMenu').classList.remove('show');
    }

    function closeModal(modalId) {
        document.getElementById(modalId).classList.remove('show');
    }

    function viewDocuments() {
        window.location.href = 'documents.php?id=<?= $id ?>';
    }

    function showApproveModal() {
        if(confirm('Are you sure you want to approve the documents? This will send an approval email to the company.')) {
            window.location.href = 'actions/approve_docs.php?id=<?= $id ?>';
        }
    }

    function showFinalApproveModal() {
        if(confirm('Are you sure you want to final approve this company? This will send a final approval email with agreement details.')) {
            window.location.href = 'actions/final_approve.php?id=<?= $id ?>';
        }
    }
</script>

</body>
</html>