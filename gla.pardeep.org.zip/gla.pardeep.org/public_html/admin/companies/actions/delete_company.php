$conn->query("DELETE FROM companies WHERE id=$id");
header("Location: ../index.php");