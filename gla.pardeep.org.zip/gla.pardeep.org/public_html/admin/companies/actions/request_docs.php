<?php
require '_workflow.php';

$id = (int)($_POST['company_id'] ?? 0);

$conn->query("UPDATE companies SET status='docs_requested' WHERE id=$id");

$c = getCompany($id);
$mail = sendDocsRequestMail($c['email'],$c['company_name']);

logHistory($id,'docs_requested','Documents requested');
logEmail($id,'docs_request','Documents Requested',$mail?'sent':'failed');

header("Location: ../view.php?id=".$id);