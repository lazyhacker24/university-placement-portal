<?php
require '../../../config/db.php';
$id = (int)$_GET['id'];

$conn->query("UPDATE companies SET status='blocked', is_active=0 WHERE id=$id");
header("Location: ../view.php?id=".$id);