UPDATE company_documents 
SET status='approved', verified_by_role='admin'
WHERE id=?