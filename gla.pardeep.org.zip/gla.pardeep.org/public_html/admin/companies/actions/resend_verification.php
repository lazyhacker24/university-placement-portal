<?php
require '_workflow.php';

$id = (int)($_GET['id'] ?? 0);

$c = getCompany($id);
$mail = sendVerificationMail($c['email'],$c['company_name']);

logHistory($id,'verification_resent','Verification mail resent');
logEmail($id,'verification','Verification Mail',$mail?'sent':'failed');

header("Location: ../view.php?id=".$id);