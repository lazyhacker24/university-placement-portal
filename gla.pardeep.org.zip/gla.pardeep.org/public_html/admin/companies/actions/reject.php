<?php
require '_workflow.php';

$id = (int)($_POST['company_id'] ?? 0);
$reason = $_POST['rejection_reason'] ?? 'Not specified';

$conn->query("UPDATE companies SET status='rejected' WHERE id=$id");

$c = getCompany($id);
$mail = sendCompanyRejectedMail($c['email'],$c['company_name'],$reason);

logHistory($id,'rejected',"Reason: $reason");
logEmail($id,'rejection','Company Rejected',$mail?'sent':'failed');

header("Location: ../view.php?id=".$id);