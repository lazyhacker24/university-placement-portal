UPDATE company_documents 
SET status='rejected', admin_note=?
WHERE id=?