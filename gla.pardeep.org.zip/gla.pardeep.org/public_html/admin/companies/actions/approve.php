<?php
require_once '../../includes/auth.php';
require_once '../../../config/db.php';
require_once '../../../api/mail/mailer.php';
require_once '../../../api/mail/company_mail.php';
sendCompanyApprovedMail($email,$hr_name,$company_name);

if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
    die("Invalid ID");
}

$id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT company_name,email FROM companies WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows==0) die("Company not found");

$company = $result->fetch_assoc();

// Update status
$conn->query("UPDATE companies SET status='approved' WHERE id=$id");

// Send mail
sendCompanyApprovedMail($company['email'], $company['company_name']);

header("Location: ../index.php?msg=approved");
exit;