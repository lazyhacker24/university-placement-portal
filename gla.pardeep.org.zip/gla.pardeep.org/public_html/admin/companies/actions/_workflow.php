<?php
require '../../_core.php';

/* ================= LOG HISTORY ================= */
function logHistory($company_id,$type,$details){
    global $conn;
    $admin = $_SESSION['admin_id'];
    $stmt = $conn->prepare("INSERT INTO company_history(company_id,action_type,details,action_by) VALUES(?,?,?,?)");
    $stmt->bind_param("isss",$company_id,$type,$details,$admin);
    $stmt->execute();
}

/* ================= LOG EMAIL ================= */
function logEmail($company_id,$type,$subject,$status){
    global $conn;
    $stmt = $conn->prepare("INSERT INTO email_logs(company_id,email_type,subject,status) VALUES(?,?,?,?)");
    $stmt->bind_param("isss",$company_id,$type,$subject,$status);
    $stmt->execute();
}

/* ================= GET COMPANY ================= */
function getCompany($id){
    global $conn;
    return $conn->query("SELECT * FROM companies WHERE id=$id")->fetch_assoc();
}