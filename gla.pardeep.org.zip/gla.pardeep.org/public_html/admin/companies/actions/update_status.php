<?php
session_start();
require '../../../config/db.php';
require '../../../api/mail/mailer.php';
require '../../../api/mail/company/welcomemail.php';
require '../../../api/mail/company/doc_request_mail.php';

$id = (int)$_POST['company_id'];
$action = $_POST['action'] ?? '';

$stmt = $conn->prepare("SELECT company_name, hr_name, email FROM companies WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();

if(!$company) die("Company not found");

$email = $company['email'];
$hr    = $company['hr_name'];
$cname = $company['company_name'];

switch($action){

    // ✅ EMAIL VERIFIED → SEND WELCOME MAIL
    case 'email_verified':
        $conn->query("UPDATE companies SET status='email_verified' WHERE id=$id");
        $body = welcomeTemplate($hr);
        sendMail($email, "Email Verified - GLA Placement Cell", $body);
    break;

    // ✅ REQUEST DOCUMENTS
    case 'request_docs':
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+3 days'));

        $conn->query("UPDATE companies 
            SET status='docs_requested',
                doc_token='$token',
                token_expiry='$expiry'
            WHERE id=$id");

        $link = "https://gla.pardeep.org/company/doc/upload.php?token=$token";
        $body = docRequestTemplate($hr,$cname,$link);
        sendMail($email, "Documents Required - GLA Placement Cell", $body);
    break;

    // ✅ RESEND DOC REQUEST
    case 'resend_docs':
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+3 days'));

        $conn->query("UPDATE companies 
            SET doc_token='$token',
                token_expiry='$expiry'
            WHERE id=$id");

        $link = "https://gla.pardeep.org/company/doc/upload.php?token=$token";
        $body = docRequestTemplate($hr,$cname,$link);
        sendMail($email, "Reminder: Upload Documents", $body);
    break;

    // ✅ APPROVE DOCUMENTS
    case 'approve_docs':
        $conn->query("UPDATE companies SET status='docs_approved' WHERE id=$id");
        sendMail($email,
            "Documents Approved",
            "<p>Dear $hr,<br>Your documents are approved.<br>Final approval within 24 hours.</p>"
        );
    break;

    // ❌ REJECT COMPANY
    case 'reject_company':
        $conn->query("UPDATE companies SET status='rejected' WHERE id=$id");
        sendMail($email,
            "Application Rejected",
            "<p>Dear $hr,<br>As per university policy, we cannot proceed with your application.</p>"
        );
    break;
}

header("Location: ../view.php?id=".$id);