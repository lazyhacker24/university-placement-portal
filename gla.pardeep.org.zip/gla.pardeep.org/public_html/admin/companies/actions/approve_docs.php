<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require '_workflow.php';

$id = (int)($_GET['id'] ?? 0);

$conn->query("UPDATE companies SET status='officer_approved' WHERE id=$id");

$c = getCompany($id);
$mail = sendDocsApprovedMail($c['email'],$c['company_name']);

logHistory($id,'docs_approved','Documents approved');
logEmail($id,'docs_approved','Documents Approved',$mail?'sent':'failed');

header("Location: ../view.php?id=".$id);