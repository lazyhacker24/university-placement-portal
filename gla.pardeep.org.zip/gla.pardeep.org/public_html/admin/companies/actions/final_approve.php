<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require '_workflow.php';

$id = (int)($_GET['id'] ?? 0);
if(!$id) die("Invalid ID");

$conn->query("UPDATE companies SET status='active', approved_at=NOW() WHERE id=$id");

$c = getCompany($id);

$mail = sendCompanyApprovedMail($c['email'],$c['company_name']);

logHistory($id,'final_approved','Company activated');
logEmail($id,'approval','Company Approved',$mail?'sent':'failed');

header("Location: ../view.php?id=".$id);