<?php
session_start();
require '../../../config/db.php';
require '../../../api/mail/mailer.php';

if(!isset($_SESSION['admin_id'])) exit("Unauthorized");

$company_id = (int)$_POST['company_id'];

// 1️⃣ Generate secure token
$token = bin2hex(random_bytes(32));
$expiry = date("Y-m-d H:i:s", strtotime("+48 hours"));

// 2️⃣ Save token in DB
$stmt = $conn->prepare("
UPDATE companies 
SET doc_token=?, token_expiry=?, status='docs_requested'
WHERE id=?
");
$stmt->bind_param("ssi", $token, $expiry, $company_id);
$stmt->execute();

// 3️⃣ Get company email
$res = $conn->query("SELECT email, company_name FROM companies WHERE id=$company_id");
$c = $res->fetch_assoc();

$link = "https://gla.pardeep.org/company/docs/upload.php?token=".$token;

// 4️⃣ Send email
sendMail(
    $c['email'],
    "Upload Required Documents",
    "Dear ".$c['company_name'].",<br><br>
    Please upload required documents:<br>
    <a href='$link'>$link</a><br><br>
    Link expires in 48 hours."
);

header("Location: ../view.php?id=".$company_id);