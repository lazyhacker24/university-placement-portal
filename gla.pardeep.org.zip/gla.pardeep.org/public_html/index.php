<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GLA University · Smart Placement System 2.0</title>
    <!-- Font Awesome 6 (free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts: Inter, Poppins, Plus Jakarta Sans -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Poppins:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap">
    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .logo-icon img{
        width:40px;
        height:40px;
        object-fit:contain;
        background:Transparent;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #f8faff 0%, #edf3fc 100%);
            min-height: 100vh;
            color: #1a2639;
            line-height: 1.5;
            overflow-x: hidden;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }

        ::-webkit-scrollbar-track {
            background: #e6edf6;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            border-radius: 10px;
        }

        /* Main Container */
        .page-wrap {
            max-width: 1440px;
            margin: 0 auto;
            padding: 0 40px;
            position: relative;
        }

        /* Floating Elements */
        .floating-shape {
            position: fixed;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle at 30% 50%, rgba(30, 60, 114, 0.03), transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: -1;
        }

        .shape-1 {
            top: -100px;
            right: -100px;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(42, 95, 138, 0.05), transparent);
        }

        .shape-2 {
            bottom: -50px;
            left: -50px;
            width: 350px;
            height: 350px;
            background: radial-gradient(circle, rgba(30, 60, 114, 0.04), transparent);
        }

        /* Navbar Enhancement */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 25px 0;
            position: relative;
            z-index: 100;
        }

        .navbar::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #1e3c72, #2a5f8a, #1e3c72, transparent);
        }

        .logo-area {
            display: flex;
            align-items: center;
            gap: 15px;
            position: relative;
        }

        .logo-icon {
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            box-shadow: 0 15px 25px -8px rgba(30, 60, 114, 0.3);
            transform: rotate(5deg);
            transition: transform 0.3s ease;
        }

        .logo-icon:hover {
            transform: rotate(0deg) scale(1.05);
        }

        .logo-text h1 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 800;
            font-size: 2rem;
            background: linear-gradient(145deg, #0a1f33, #1e3c72);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1.2;
            letter-spacing: -0.5px;
        }

        .logo-text span {
            font-size: 0.85rem;
            font-weight: 600;
            color: #2a5f8a;
            background: rgba(42, 95, 138, 0.1);
            padding: 4px 15px;
            border-radius: 40px;
            display: inline-block;
            margin-top: 5px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(42, 95, 138, 0.2);
            letter-spacing: 0.5px;
        }

        /* Enhanced Login Buttons */
        .login-group {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .login-btn {
            display: flex;
            align-items: center;
            gap: 12px;
            background: white;
            padding: 12px 28px;
            border-radius: 60px;
            font-weight: 600;
            font-size: 1rem;
            color: #1e3c72;
            border: 1px solid rgba(30, 60, 114, 0.15);
            box-shadow: 0 8px 20px -8px rgba(30, 60, 114, 0.15);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            cursor: pointer;
            text-decoration: none;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .login-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            z-index: -1;
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.4s ease;
        }

        .login-btn:hover::before {
            transform: scaleX(1);
            transform-origin: left;
        }

        .login-btn:hover {
            color: white;
            border-color: transparent;
            transform: translateY(-3px);
            box-shadow: 0 20px 30px -10px #1e3c72;
        }

        .login-btn i {
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }

        .login-btn:hover i {
            transform: rotate(10deg) scale(1.1);
        }

        .student-btn {
            background: linear-gradient(105deg, #ffffff, #f0f7ff);
        }

        .company-btn {
            background: linear-gradient(105deg, #ffffff, #eef2f9);
        }

        /* Hero Section Enhancement */
        .hero-section {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            margin: 60px 0 50px;
            gap: 50px;
            position: relative;
        }

        .hero-left {
            flex: 1 1 450px;
            animation: fadeInLeft 1s ease;
        }

        .hero-left h2 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 3.5rem;
            font-weight: 800;
            line-height: 1.2;
            background: linear-gradient(145deg, #0a1f33, #1e3c72, #2a5f8a);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 25px;
            letter-spacing: -1px;
        }

        .hero-left h2 i {
            background: linear-gradient(135deg, #f6b91e, #ff9800);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 3rem;
            margin-right: 5px;
            animation: bounce 2s infinite;
        }

        .highlight {
            background: linear-gradient(135deg, rgba(255, 217, 102, 0.2), rgba(255, 152, 0, 0.2));
            padding: 6px 18px;
            border-radius: 60px;
            font-weight: 600;
            font-size: 1rem;
            display: inline-block;
            backdrop-filter: blur(10px);
            margin-bottom: 25px;
            border: 1px solid rgba(255, 193, 7, 0.3);
            color: #b45f06;
            box-shadow: 0 5px 15px rgba(255, 152, 0, 0.1);
        }

        .hero-description {
            font-size: 1.2rem;
            color: #2c3e50;
            max-width: 600px;
            margin: 30px 0 40px;
            font-weight: 400;
            background: rgba(255, 255, 255, 0.7);
            padding: 25px 30px;
            border-radius: 30px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.9);
            box-shadow: 0 20px 30px -15px rgba(0, 0, 0, 0.05);
            line-height: 1.7;
            position: relative;
        }

        .hero-description::before {
            content: '"';
            position: absolute;
            top: -10px;
            left: 20px;
            font-size: 60px;
            color: #1e3c72;
            opacity: 0.1;
            font-family: serif;
        }

        .stats-mini {
            display: flex;
            gap: 30px;
            margin-top: 40px;
        }

        .stat-item {
            background: white;
            border-radius: 30px;
            padding: 18px 32px;
            font-weight: 600;
            box-shadow: 0 15px 25px -15px rgba(30, 60, 114, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(5px);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
            cursor: default;
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 30px -15px #1e3c72;
        }

        .stat-item i {
            font-size: 2.2rem;
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1;
        }

        /* Hero Right Enhancement */
        .hero-right {
            flex: 1 1 400px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(15px);
            border-radius: 50px;
            padding: 45px 35px;
            box-shadow: 0 40px 60px -25px rgba(30, 60, 114, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.8);
            text-align: center;
            animation: fadeInRight 1s ease;
            position: relative;
            overflow: hidden;
        }

        .hero-right::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.8), transparent 70%);
            opacity: 0.3;
            animation: rotate 20s linear infinite;
        }

        .hero-right img {
            width: 120px;
            margin-bottom: 20px;
            filter: drop-shadow(0 10px 15px rgba(30, 60, 114, 0.2));
            animation: float 6s ease-in-out infinite;
            position: relative;
            z-index: 2;
        }

        .hero-right h3 {
            font-size: 2rem;
            font-weight: 800;
            color: #1e3c72;
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
        }

        .badge-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 30px 0 20px;
            flex-wrap: wrap;
            position: relative;
            z-index: 2;
        }

        .badge {
            background: white;
            padding: 10px 28px;
            border-radius: 60px;
            font-weight: 600;
            box-shadow: 0 10px 15px -8px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(30, 60, 114, 0.1);
            color: #1e3c72;
            font-size: 1rem;
            transition: all 0.3s ease;
            cursor: default;
        }

        .badge:hover {
            background: #1e3c72;
            color: white;
            transform: scale(1.05);
        }

        .badge i {
            margin-right: 8px;
            color: #ff9800;
        }

        .badge:hover i {
            color: white;
        }

        /* Feature Section Enhancement */
        .feature-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin: 80px 0 30px;
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-align: center;
            position: relative;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .feature-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, #1e3c72, #2a5f8a, #1e3c72);
            border-radius: 2px;
        }

        .feature-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: center;
            margin: 50px 0 70px;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            padding: 35px 25px;
            border-radius: 40px;
            flex: 1 1 260px;
            max-width: 320px;
            border: 1px solid rgba(255, 255, 255, 0.9);
            box-shadow: 0 25px 35px -20px rgba(30, 60, 114, 0.15);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            text-align: center;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #1e3c72, #2a5f8a, #1e3c72);
            transform: scaleX(0);
            transition: transform 0.4s ease;
        }

        .feature-card:hover::before {
            transform: scaleX(1);
        }

        .feature-card:hover {
            transform: translateY(-15px) scale(1.02);
            background: white;
            box-shadow: 0 35px 45px -20px #1e3c72;
        }

        .feature-icon {
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            width: 80px;
            height: 80px;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            color: white;
            font-size: 35px;
            box-shadow: 0 20px 25px -10px #1e3c72;
            transition: all 0.3s ease;
            position: relative;
            z-index: 2;
        }

        .feature-card:hover .feature-icon {
            transform: rotate(10deg) scale(1.1);
            border-radius: 20px;
        }

        .feature-card h4 {
            font-size: 1.7rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: #1e3c72;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .feature-card p {
            color: #2c3e50;
            font-weight: 400;
            line-height: 1.7;
        }

        /* CTA Bar Enhancement */
        .cta-bar {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            margin: 40px 0;
            animation: fadeInUp 1s ease;
        }

        .cta-item {
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            color: white;
            padding: 12px 35px;
            border-radius: 60px;
            font-weight: 600;
            box-shadow: 0 15px 25px -10px #1e3c72;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
        }

        .cta-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 25px 30px -10px #1e3c72;
        }

        .cta-item i {
            font-size: 1.2rem;
            color: #ffd966;
        }

        .cta-item:nth-child(2) {
            background: white;
            color: #1e3c72;
            border: 2px solid #1e3c72;
        }

        .cta-item:nth-child(2) i {
            color: #ff9800;
        }

        /* Footer Enhancement */
        .footer {
            background: rgba(10, 30, 50, 0.05);
            backdrop-filter: blur(10px);
            border-radius: 60px 60px 30px 30px;
            padding: 50px 50px 30px;
            margin: 80px 0 20px;
            border: 1px solid rgba(255, 255, 255, 0.7);
            box-shadow: 0 -20px 40px -20px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }

        .footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #1e3c72, #2a5f8a, #1e3c72, transparent);
        }

        .footer-main {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 40px;
            margin-bottom: 40px;
            position: relative;
            z-index: 2;
        }

        .footer-col {
            flex: 1 1 200px;
            min-width: 180px;
        }

        .footer-col h5 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 1.2rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 25px;
            letter-spacing: -0.2px;
            border-left: 4px solid #2a5f8a;
            padding-left: 15px;
            position: relative;
        }

        .footer-col h5::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 15px;
            width: 30px;
            height: 2px;
            background: #2a5f8a;
            opacity: 0.3;
        }

        .footer-col ul {
            list-style: none;
        }

        .footer-col li {
            margin-bottom: 15px;
        }

        .footer-col a {
            text-decoration: none;
            color: #2c3e50;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
            font-size: 1rem;
            padding: 5px 0;
        }

        .footer-col a i {
            width: 24px;
            color: #2a5f8a;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }

        .footer-col a:hover {
            color: #1e3c72;
            transform: translateX(8px);
        }

        .footer-col a:hover i {
            transform: scale(1.2);
            color: #ff9800;
        }

        .footer-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, #1e3c72, #2a5f8a, #1e3c72, transparent);
            margin: 30px 0 25px;
            opacity: 0.3;
        }

        .footer-bottom {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            color: #1e3c72;
            font-weight: 500;
            font-size: 0.95rem;
            position: relative;
            z-index: 2;
        }

        .footer-bottom .gla-motto {
            background: rgba(30, 60, 114, 0.05);
            padding: 8px 30px;
            border-radius: 60px;
            font-style: italic;
            border: 1px solid rgba(30, 60, 114, 0.1);
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .footer-bottom .copyright {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            background: white;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e3c72;
            box-shadow: 0 8px 15px -5px rgba(0, 0, 0, 0.1);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(30, 60, 114, 0.1);
            font-size: 1.2rem;
        }

        .social-links a:hover {
            background: linear-gradient(135deg, #1e3c72, #2a5f8a);
            color: white;
            transform: translateY(-5px) rotate(360deg);
            box-shadow: 0 15px 20px -8px #1e3c72;
        }

        .footer-links-bottom {
            text-align: center;
            margin-top: 25px;
            font-size: 0.9rem;
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
            padding: 20px 0 0;
            border-top: 1px dashed rgba(30, 60, 114, 0.2);
        }

        .footer-links-bottom a {
            color: #1e3c72;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            padding: 5px 15px;
            border-radius: 40px;
            background: rgba(255, 255, 255, 0.5);
        }

        .footer-links-bottom a:hover {
            background: #1e3c72;
            color: white;
            transform: translateY(-2px);
        }

        .copyright-note {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            padding: 8px 25px;
            border-radius: 60px;
            font-size: 0.85rem;
            border: 1px solid rgba(30, 60, 114, 0.2);
            box-shadow: 0 10px 20px -8px rgba(0, 0, 0, 0.1);
            z-index: 999;
            backdrop-filter: blur(10px);
            font-weight: 500;
            color: #1e3c72;
        }

        /* Animations */
        @keyframes fadeInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        @keyframes bounce {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 991px) {
            .hero-left h2 {
                font-size: 2.8rem;
            }
            
            .hero-section {
                margin: 40px 0;
            }
            
            .feature-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .page-wrap {
                padding: 0 20px;
            }
            
            .navbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 20px;
            }
            
            .login-group {
                width: 100%;
                justify-content: flex-start;
            }
            
            .hero-left h2 {
                font-size: 2.2rem;
            }
            
            .hero-left h2 i {
                font-size: 2rem;
            }
            
            .stats-mini {
                flex-direction: column;
                gap: 15px;
            }
            
            .stat-item {
                width: 100%;
            }
            
            .footer-main {
                flex-direction: column;
                gap: 30px;
            }
            
            .footer-bottom {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
            
            .cta-bar {
                flex-direction: column;
                align-items: center;
            }
            
            .cta-item {
                width: 100%;
                justify-content: center;
            }
            
            .copyright-note {
                position: static;
                margin-top: 20px;
                text-align: center;
                width: fit-content;
                margin-left: auto;
                margin-right: auto;
            }
        }

        @media (max-width: 480px) {
            .hero-left h2 {
                font-size: 1.8rem;
            }
            
            .badge-container {
                flex-direction: column;
                align-items: center;
            }
            
            .badge {
                width: 100%;
                text-align: center;
            }
            
            .feature-card {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Floating Background Shapes -->
    <div class="floating-shape shape-1"></div>
    <div class="floating-shape shape-2"></div>

    <div class="page-wrap">
        <!-- Enhanced Header -->
        <header>
            <div class="navbar" data-aos="fade-down" data-aos-duration="1000">
                <div class="logo-area">
                    <div class="logo-icon">
                         <img src="/assets/img/gla-logo.png" alt="GLA Logo">
                    </div>
                    <div class="logo-text">
                        <h1>GLA University</h1>
                        <span>SPMS 2.0 · next-gen placement</span>
                    </div>
                </div>
                
                <div class="login-group">
                    <a href="https://www.gla.pardeep.org/student" class="login-btn student-btn" data-aos="fade-left" data-aos-delay="200">
                        <i class="fas fa-graduation-cap"></i> Student Login
                    </a>
                    <a href="company/" class="login-btn company-btn" data-aos="fade-left" data-aos-delay="400">
                        <i class="fas fa-briefcase"></i> Company Login
                    </a>
                </div>
            </div>
        </header>

        <!-- Enhanced Hero Section -->
        <main>
            <div class="hero-section">
                <div class="hero-left">
                    <div class="highlight" data-aos="fade-up" data-aos-delay="200">
                        <i class="fas fa-bolt"></i> GLA University 2026 · flagship placement portal
                    </div>
                    <h2 data-aos="fade-up" data-aos-delay="300">
                        <i class="fas fa-rocket"></i> Where talent<br>meets opportunity
                    </h2>
                    <p class="hero-description" data-aos="fade-up" data-aos-delay="400">
                        End-to-end placement automation — from student profiling to company drive management. Real-time analytics, dream offers, and seamless coordination.
                    </p>
                    
                    <div class="stats-mini" data-aos="fade-up" data-aos-delay="500">
                        <div class="stat-item">
                            <i class="fas fa-user-graduate"></i>
                            <div><span class="stat-number">25K+</span> <span style="color:#2c3e50;">students</span></div>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-building"></i>
                            <div><span class="stat-number">180+</span> <span style="color:#2c3e50;">recruiters</span></div>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-trophy"></i>
                            <div><span class="stat-number">92%</span> <span style="color:#2c3e50;">placed</span></div>
                        </div>
                    </div>
                </div>
                
                <div class="hero-right" data-aos="fade-left" data-aos-duration="1000">
                    <img src="/assets/img/gla-logo.png" alt="GLA Placement">
                    <h3>GLA Placement Portal</h3>
                    <p style="margin-bottom: 20px; color: #2c3e50;">student · company · admin · unified</p>
                    <div class="badge-container">
                        <span class="badge"><i class="fas fa-calendar-check"></i> 45+ drives</span>
                        <span class="badge"><i class="fas fa-chart-line"></i> 92% placed</span>
                        <span class="badge"><i class="fas fa-star"></i> 25LPA highest</span>
                    </div>
                    <p style="font-size: 1rem; background: white; padding: 15px; border-radius: 60px; border: 1px solid rgba(30,60,114,0.1); margin-top: 20px;">
                        <i class="fas fa-bell" style="color:#ff9800;"></i> upcoming: Adobe, Microsoft, Deloitte
                    </p>
                </div>
            </div>

            <!-- Enhanced Feature Section -->
            <h3 class="feature-title" data-aos="fade-up">Designed for seamless placement</h3>
            <div class="feature-grid">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-icon"><i class="fas fa-user-tie"></i></div>
                    <h4>Student Zone</h4>
                    <p>Build profile, upload resume, track applications, get training material & drive notifications.</p>
                </div>
                <div class="feature-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-icon"><i class="fas fa-bullhorn"></i></div>
                    <h4>Company Corner</h4>
                    <p>Post job descriptions, shortlist, schedule interviews, and communicate with TPO.</p>
                </div>
                <div class="feature-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-icon"><i class="fas fa-chart-pie"></i></div>
                    <h4>Analytics</h4>
                    <p>Real-time placement stats, branch-wise progress, company wise offers dashboard.</p>
                </div>
                <div class="feature-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-icon"><i class="fas fa-calendar-alt"></i></div>
                    <h4>Drive Management</h4>
                    <p>Eligibility criteria, slot booking, venue details, and automated email alerts.</p>
                </div>
            </div>

            <!-- Enhanced CTA Bar -->
            <div class="cta-bar" data-aos="fade-up" data-aos-delay="200">
                <span class="cta-item"><i class="fas fa-lock-open"></i> Secure 2FA Authentication</span>
                <span class="cta-item"><i class="fas fa-phone-alt"></i> TPO Helpline: +91 98765 43210</span>
                <span class="cta-item"><i class="fas fa-video"></i> Virtual Interviews</span>
            </div>
        </main>

        <!-- Enhanced Footer -->
        <footer class="footer">
            <div class="footer-main">
                <div class="footer-col" data-aos="fade-up" data-aos-delay="100">
                    <h5>STUDENT PORTAL</h5>
                    <ul>
                        <li><a href="https://www.gla.pardeep.org/student/"><i class="fas fa-user-circle"></i> Student Login</a></li>
                        <li><a href="https://www.gla.pardeep.org/student/"><i class="fas fa-file-alt"></i> Resume Builder</a></li>
                        <li><a href="https://www.gla.pardeep.org//student/"><i class="fas fa-calendar-check"></i> Upcoming Drives</a></li>
                        <li><a href="#"><i class="fas fa-chart-bar"></i> Placement Stats</a></li>
                        <li><a href="#"><i class="fas fa-question-circle"></i> Training & Support</a></li>
                    </ul>
                </div>

                <div class="footer-col" data-aos="fade-up" data-aos-delay="200">
                    <h5>UNIVERSITY</h5>
                    <ul>
                        <li><a href="https://www.gla.ac.in" target="_blank"><i class="fas fa-university"></i> GLA Official</a></li>
                        <li><a href="https://www.gla.pardeep.org/privacy-policy.php"><i class="fas fa-shield-alt"></i> Privacy Policy</a></li>
                        <li><a href="https://www.gla.pardeep.org/terms-of-use.php"><i class="fas fa-gavel"></i> Terms of Use</a></li>
                        <li><a href="https://www.gla.pardeep.org/cookie-policy.php"><i class="fas fa-cookie-bite"></i> Cookie Policy</a></li>
                        <li><a href="https://www.gla.pardeep.org/"><i class="fas fa-sitemap"></i> Sitemap</a></li>
                    </ul>
                </div>

                <div class="footer-col" data-aos="fade-up" data-aos-delay="300">
                    <h5>IMPORTANT</h5>
                    <ul>
                        <li><a href="https://www.gla.pardeep.org/student/"><i class="fas fa-graduation-cap"></i> Student Portal (SSO)</a></li>
                        <li><a href="https://www.gla.pardeep.org/company/"><i class="fas fa-user-tie"></i> Company Portal</a></li>
                        <li><a href="https://www.gla.pardeep.org/privacy-security.php"><i class="fas fa-lock"></i> Privacy & Security</a></li>
                        <li><a href="https://www.gla.pardeep.org/data-protection.php"><i class="fas fa-file-contract"></i> Data Protection</a></li>
                        <li><a href="https://gla.ac.in"><i class="fas fa-globe"></i> GLA University</a></li>
                    </ul>
                </div>

                <div class="footer-col" data-aos="fade-up" data-aos-delay="400">
                    <h5>CONTACT</h5>
                    <ul>
                        <li><i class="fas fa-map-pin"></i> NH-2, Mathura, UP</li>
                        <li><i class="fas fa-phone-alt"></i> +91 566 234 7890</li>
                        <li><i class="fas fa-envelope"></i> placement@gla.ac.in</li>
                        <li><i class="fas fa-clock"></i> Mon-Fri 9am - 5pm</li>
                    </ul>
                </div>
            </div>

            <div class="footer-divider"></div>

            <div class="footer-bottom">
                <div class="copyright">
                    <i class="far fa-copyright"></i> 2026 GLA University, Mathura. All rights reserved.
                </div>
                <div class="gla-motto">
                    <i class="fas fa-om"></i> तमसो मा ज्योतिर्गमय
                </div>
                <div class="social-links">
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <div class="footer-links-bottom">
                <a href="https://www.gla.pardeep.org/student/"><i class="fas fa-external-link-alt"></i> Student Portal</a>
                <a href="https://www.gla.pardeep.org/privacy-policy.php"><i class="fas fa-lock"></i> Privacy</a>
                <a href="https://www.gla.ac.in"><i class="fas fa-university"></i> GLA University Website</a>
                <a href="https://www.gla.pardeep.org/data-protection"><i class="fas fa-shield"></i> SPMS v2.0</a>
                <a href="https://www.gla.pardeep.org/data-protection"><i class="fas fa-newspaper"></i> News & Updates</a>
            </div>
        </footer>
    </div>

    <!-- Copyright Note -->
    <div class="copyright-note">
        <i class="fas fa-crown" style="color: #ff9800;"></i> Pardeep Kumar · GLA University 2023-2026
    </div>

    <!-- Scripts -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 1200,
            once: true,
            offset: 100,
            easing: 'ease-in-out'
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Parallax effect for floating shapes
        document.addEventListener('mousemove', (e) => {
            const shapes = document.querySelectorAll('.floating-shape');
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / window.innerHeight;
            
            shapes.forEach((shape, index) => {
                const speed = index + 1;
                shape.style.transform = `translate(${x * speed * 10}px, ${y * speed * 10}px)`;
            });
        });

        // Counter animation for stats
        const stats = document.querySelectorAll('.stat-number');
        const observerOptions = {
            threshold: 0.5,
            rootMargin: '0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const stat = entry.target;
                    const targetValue = parseInt(stat.innerText);
                    let currentValue = 0;
                    const increment = targetValue / 50;
                    
                    const updateCounter = setInterval(() => {
                        currentValue += increment;
                        if (currentValue >= targetValue) {
                            stat.innerText = targetValue + '+';
                            clearInterval(updateCounter);
                        } else {
                            stat.innerText = Math.floor(currentValue) + '+';
                        }
                    }, 30);
                    
                    observer.unobserve(stat);
                }
            });
        }, observerOptions);

        stats.forEach(stat => observer.observe(stat));

        // Dynamic year in copyright
        document.querySelector('.copyright').innerHTML = 
            `<i class="far fa-copyright"></i> ${new Date().getFullYear()} GLA University, Mathura. All rights reserved.`;
    </script>
</body>
</html>